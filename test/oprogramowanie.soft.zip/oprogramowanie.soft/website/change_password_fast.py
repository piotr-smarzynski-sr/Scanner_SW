import argparse

from db_communication import changeUserPassword, checkUserExistence, addNewUser

parser = argparse.ArgumentParser()
parser.add_argument('username', help='User to change password. If not exists, adding new user',
                    type=str)
parser.add_argument('password', help='Save password into db', type=str)
args = parser.parse_args()

credentials = {'USER': 'piotr',
               'PASSWORD': 'admin',
               'HOST': '127.0.0.1',
               'PORT': '5432',
               'DATABASE': 'rollercoaster'
}

db_ok, user_exists = checkUserExistence(args.username, credentials='DEFAULT')
print('User', args.username, 'exists: ', user_exists)
if user_exists:
    print('Changing password for user', args.username)
    changeUserPassword(args.username, args.password, credentials='DEFAULT')
else:
    print('Creating user', args.username, 'with 0 security level')
    addNewUser(args.username, args.password, 0, credentials='DEFAULT')
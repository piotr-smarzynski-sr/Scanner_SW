from flask import Blueprint, request, render_template, flash, redirect, url_for, session
from flask_wtf import FlaskForm
from wtforms.validators import DataRequired

import secure

users_page = Blueprint('users', __name__)

@users_page.route("/users", methods=['GET', 'POST'])
@secure.minPermissionLevel(secure.Permissions.ADV_USER)
def users():
    return "Users[]"

@users_page.route("/users/user/<user_username>", methods=['GET', 'POST'])
@secure.minPermissionLevel(secure.Permissions.ADV_USER)
def user_modify(user_username):
    return "User: " + user_username 
from flask import Blueprint, request, render_template, flash, redirect, url_for, session

from db_communication import getCartsStatus, getCart
import secure
import enums

manual_page = Blueprint('manual_control', __name__)

@manual_page.route("/manual")
@secure.minPermissionLevel(secure.Permissions.ADV_USER)
def manual():
    db_ok, cart_statuses = getCartsStatus()
    carts=[]
    if db_ok:
        for cart in cart_statuses:
            carts.append({"status": enums.CartStatus(cart['status']).name,
                          "id": cart['cart_no'],
                          "action":"More"})
    stations=[]
    stations.append({"status":"Manual", "id":35, "action":"Control"})
    stations.append({"status":"Disabled", "id":5, "action":"Control"})
    stations.append({"status":"Waiting for cart", "id":4, "action":"Control"})
    junctions=[]
    junctions.append({"status":"Idle", "id":8, "action":"Control"})
    junctions.append({"status":"Idle", "id":12, "action":"Control"})
    junctions.append({"status":"Preparing", "id":7, "action":"Control"})

    return render_template("manual_control.html",
                           carts=carts,
                           stations=stations,
                           junctions=junctions)

@manual_page.route("/manual/cart/<cart_id>")
@secure.minPermissionLevel(secure.Permissions.ADV_USER)
def manual_cart(cart_id):
    db_ok, cart_info = getCart(int(cart_id))
    assert db_ok == True, 'Cannot communicate with DB during retrieving cart info'
    return render_template("manual_control_cart.html",
                           cart_id=cart_id,
                           cart_info=cart_info)

@manual_page.route("/manual/station/<station_id>")
@secure.minPermissionLevel(secure.Permissions.ADV_USER)
def manual_station(station_id):
    return render_template("manual_control_station.html", station_id=station_id)

@manual_page.route("/manual/junction/<junction_id>")
@secure.minPermissionLevel(secure.Permissions.ADV_USER)
def manual_junction(junction_id):
    return render_template("manual_control_junction.html", junction_id=junction_id)
import secure

def getPermittedNavContent():
    links = [("Main page", "/")]
    if secure.securityLevel() >= secure.Permissions.USER:
        links.append(("Current alarms", "/alarms_current"))
    if secure.securityLevel() >= secure.Permissions.USER:
        links.append(("Historic alarms", "/alarms_history"))

    if secure.securityLevel() >= secure.Permissions.ADV_USER:
        links.append(("Manual mode", "/manual"))
    elif secure.securityLevel() >= secure.Permissions.USER:
        links.append(("Manual mode(Basic)", "/manual"))

    if secure.securityLevel() >= secure.Permissions.ADMIN:
        links.append(("Users", "/admin/users"))
    return links
import argparse

from secure import Permissions
from db_communication import setUserSecurityLvl, checkUserExistence

parser = argparse.ArgumentParser()
parser.add_argument('db_ip', help='Database IP address', type=str)
parser.add_argument('db_port', help='Database port', type=str)
parser.add_argument('db_name', help='Database name', type=str)
parser.add_argument('db_login', help='Database login', type=str)
parser.add_argument('db_password', help='Database password', type=str)
parser.add_argument('username', 
                    help='User to change security level. If not exists, adding new user',
                    type=str)
parser.add_argument('--setLvlName',
                    help='Save security level into db by name',
                    type=str,
                    choices=list(Permissions.__members__))
parser.add_argument('--setLvlNo', help='Save security level into db by number', type=int)

args = parser.parse_args()

credentials = {'USER': args.db_login,
               'PASSWORD': args.db_password,
               'HOST': args.db_ip,
               'PORT': args.db_port,
               'DATABASE': args.db_name}

db_ok, user_exists = checkUserExistence(args.username, credentials='DEFAULT')
if user_exists is True:
    if args.setLvlNo:
        print('Changing security level for user', args.username, 'to', args.setLvlNo)
        setUserSecurityLvl(args.username, args.setLvlNo, credentials='DEFAULT')
    if args.setLvlName:
        print('Changing security level for user',
              args.username,
              'to',
              args.setLvlName,
              ':',
              Permissions[args.setLvlName].value)
        setUserSecurityLvl(args.username,
                           Permissions[args.setLvlName].value,
                           credentials='DEFAULT')
else:
    print('User', args.username, 'does not exists')
    exit()



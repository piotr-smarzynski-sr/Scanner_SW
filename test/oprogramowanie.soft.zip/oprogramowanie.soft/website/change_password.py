import argparse

from db_communication import changeUserPassword, checkUserExistence, addNewUser

parser = argparse.ArgumentParser()
parser.add_argument('db_ip', help='Database IP address', type=str)
parser.add_argument('db_port', help='Database port', type=str)
parser.add_argument('db_name', help='Database name', type=str)
parser.add_argument('db_login', help='Database login', type=str)
parser.add_argument('db_password', help='Database password', type=str)
parser.add_argument('username', help='User to change password. If not exists, adding new user',
                    type=str)
parser.add_argument('password', help='Save password into db', type=str)
args = parser.parse_args()
credentials = {'USER': args.db_login,
               'PASSWORD': args.db_password,
               'HOST': args.db_ip,
               'PORT': args.db_port,
               'DATABASE': args.db_name
}

db_ok, user_exists = checkUserExistence(args.username, credentials='DEFAULT')
print('User', args.username, 'exists: ', user_exists)
if user_exists:
    print('Changing password for user', args.username)
    changeUserPassword(args.username, args.password, credentials='DEFAULT')
else:
    print('Creating user', args.username, 'with 0 security level')
    addNewUser(args.username, args.password, 0, credentials='DEFAULT')
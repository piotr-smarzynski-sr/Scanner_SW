from flask import Blueprint, request, render_template, flash, redirect, url_for, session
import secure
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField
from wtforms.validators import DataRequired

login_page = Blueprint('login_page', __name__)

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])

@login_page.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if request.method == 'POST':
        if form.validate_on_submit():
            username = request.form['username']
            password = request.form['password']
            good = secure.authenticateUser(username, password)
            if good:
                session['username'] = request.form['username']
                flash('You were successfully logged in')
                return redirect(url_for('index'))
            else:
                flash('Wrong password or user does not exist')
                return redirect(url_for('login_page.login'))
        else:
            return "err"
    else:
        return render_template('login.html', username=session.get('username'), form = form)

@login_page.route('/logout', methods=['GET', 'POST'])
def logout():
    if request.method == 'POST':
        session['username'] = None
        flash('Logged out!')
        return redirect(url_for('login_page.login'))
    else:
        return render_template('login.html', username=session.get('username'))

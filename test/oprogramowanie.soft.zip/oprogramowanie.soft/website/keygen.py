import secrets
import sys

"""
Utility script for generating secret key that is used by Flask
"""

key = secrets.token_bytes(64)

if len(sys.argv) == 1:
    print(key)
    exit()

if len(sys.argv) == 2:
    fname = sys.argv[1]
    if fname == '-h' or fname == '--help':
        print("Usage: {} [filename]".format(sys.argv[0]))
        print("OR {} > filename.key".format(sys.argv[0]))
    else:
        with open(fname, 'wb') as fil:
            fil.write(key)

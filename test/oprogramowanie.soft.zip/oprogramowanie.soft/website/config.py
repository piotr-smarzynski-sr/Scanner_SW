class Config(object):
    def __init__(self):
        secret_path = "secret.key"
        with open(secret_path, 'rb') as fil:
            self.SECRET_KEY = fil.read(64)

    DEBUG = False
    TESTING = False
    #STATIC_FOLDER = 'static'
    DATABASE_URI = 'sqlite:///:memory:'

class ProductionConfig(Config):
    def __init__(self):
        super().__init__()
    DATABASE_URI = 'mysql://user@localhost/foo'

class DevelopmentConfig(Config):
    def __init__(self):
        super().__init__()
    DEBUG = True

class TestingConfig(Config):
    def __init__(self):
        super().__init__()
    TESTING = True
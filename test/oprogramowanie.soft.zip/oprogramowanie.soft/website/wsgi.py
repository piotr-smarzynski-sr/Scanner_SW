from flask import Flask, request, session, render_template
from markupsafe import escape
import config
import login
import secure
import api
import api.cart_params
import api.users
from admin import users_page
from alarms_current import alarms_current_page
from alarms_history import alarms_history_page
from alarms_current_dynamic import alarms_current__dynamic_page
import nav
import manual_control
import users_list
from threading import Thread, Lock
from multiprocessing.connection import Client
from queue import Queue

from time import time as now

from flask_wtf.csrf import CSRFProtect

from db_communication import countAvailableOrders, countActiveCarts, countAvailableCarts
from db_communication import countAllCarts

app = Flask(__name__)
app.config.from_object(config.DevelopmentConfig())
app.register_blueprint(login.login_page)
app.register_blueprint(manual_control.manual_page)
app.register_blueprint(users_list.users_page)
app.register_blueprint(api.cart_params.cart_params_api)
app.register_blueprint(api.users.user_api)
app.register_blueprint(users_page)
app.register_blueprint(alarms_current_page)
app.register_blueprint(alarms_history_page)
app.register_blueprint(alarms_current__dynamic_page)

csrf = CSRFProtect(app)

# req, connect, send, receive

class AppConnector(object):
    def __init__(self):
        self.address = ('localhost', 6000)
        self.conn = None
    def __enter__(self):
        self.connect()
        return self
    def __exit__(self, type, value, traceback):
        self.close()
    def connect(self):
        self.conn = Client(self.address, authkey=b'secret password')
    def close(self):
        self.conn.close()
        self.conn = None

    def send(self, data):
        self.conn.send(data)
    def recv(self):
        return self.conn.recv()
    def request(self, req):
        self.conn.send(req)
        return self.conn.recv()


@app.context_processor
def inject_data():
    return {'links':nav.getPermittedNavContent()}

@app.route('/not_secret')
@secure.minPermissionLevel(secure.Permissions.NONE)
def not_secret():
    return "A camel usually has up to 4 legs"

@app.route('/little_secret')
@secure.minPermissionLevel(secure.Permissions.USER)
def little_secret():
    return "Michael Dawson is Kevin Johnson"

@app.route('/top_secret')
@secure.minPermissionLevel(secure.Permissions.ADMIN)
def top_secret():
    return "Password to my account is [REDACTED]"

@app.route('/')
def index():
    db_ok, orders_count = countAvailableOrders()
    assert db_ok == True, 'Cannot communicate with DB during counting orders'
    db_ok, carts_all = countAllCarts()
    assert db_ok == True, 'Cannot communicate with DB during counting all carts'
    db_ok, carts_active = countActiveCarts()
    assert db_ok == True, 'Cannot communicate with DB during counting active carts'
    db_ok, carts_available = countAvailableCarts()
    assert db_ok == True, 'Cannot communicate with DB during counting available carts'
    return render_template('index.html',
                           username=session.get('username'),
                           orders_count=orders_count,
                           carts_all=carts_all,
                           carts_active=carts_active,
                           carts_available=carts_available)

import json
@app.route('/xd/<cart_id>')
def xd(cart_id):
    #Validate, Authenticate
    # lock request, response queue, to keep sequential 
    print('xd?')

    resp = None
    start1 = now()
    with AppConnector() as ac:
        pre_send = now()
        ac.send({'command':"ReadVar",'varName':'Speed', 'target':'cart/{}'.format(cart_id)})
        post_send = now()
        resp = ac.recv()
        post_resp = now()
        print('Total:', (post_resp-start1)*1000, 'req:', (post_send-start1)*1000, 'resp:', (post_resp-post_send)*1000,'conn:',(pre_send-start1)*1000)
    return resp

print(app.url_map)


from passlib.hash import pbkdf2_sha256
import psycopg2

db_conn = {'USER': "piotr",
           'PASSWORD': "admin",
           'HOST': "127.0.0.1",
           'PORT': "5432",
           'DATABASE': "rollercoaster"}

def dbConnection(credentials):
    """
    Make connection to database

    Args:
        credentials: dict or 'DEFAULT' on None
            {'USER': str,
             'PASSWORD': str,
             'HOST': str,
             'PORT': str,
             'DATABASE': str
             }

    Returns:
        connection: psycopg2.connect

    Raises:
        Bad input parameter type
    """
    if credentials is not None and credentials != 'DEFAULT':
        assert isinstance(credentials, dict), 'Bad credentials type!'
        connection = psycopg2.connect(user=credentials['USER'],
                                      password=credentials['PASSWORD'],
                                      host=credentials['HOST'],
                                      port=credentials['PORT'],
                                      database=credentials['DATABASE'])
    else:
        connection = psycopg2.connect(user=db_conn['USER'],
                                      password=db_conn['PASSWORD'],
                                      host=db_conn['HOST'],
                                      port=db_conn['PORT'],
                                      database=db_conn['DATABASE'])

    return connection


def acknowledgeAllAlarms(credentials=None):
    """
    Delete alarms with cause gone from alarms_current and update them in alarms_history

    Args:
        None

    Returns:
        None

    Raises:
        Assertion error: bad data type or out of range
    """
    # usunięcie wszystkich rekordów z tabeli alarms_current, które mają wartość cause_active == false
    # aktualizacja wszystkich rekordów, które mają uzupełnioną kolumnę cause_gone_time i nieuzupełnioną ack_time na ack_time = now()
    connection = dbConnection(credentials)
    dbCoursor = connection.cursor()
    sql_query = """DELETE FROM alarms_current WHERE cause_active IS false;"""
    dbCoursor.execute(sql_query)
    connection.commit()
    sql_query = """UPDATE alarms_history SET ack_time = now() WHERE cause_gone_time IS NOT NULL AND ack_time IS NULL;"""
    dbCoursor.execute(sql_query)
    connection.commit()
    dbCoursor.close()
    return True


def addNewUser(username, password, security_lvl, credentials=None):
    """
    add new user in database

    Args:
        username: str
        password: str
        security_lvl: int
        credentials: dict or 'DEFAULT' on None
            {'USER': str,
             'PASSWORD': str,
             'HOST': str,
             'PORT': str,
             'DATABASE': str
             }

    Returns:
        True

    Raises:
        Bad input parameter type
    """
    assert isinstance(password, str), 'Bad password type!'
    assert (isinstance(security_lvl, int) and security_lvl >= 0), 'Bad security_lvl type or value below 0!'
    assert isinstance(username, str), 'Bad username type!'
    connection = dbConnection(credentials)
    hashed = pbkdf2_sha256.hash(password, rounds=8000, salt_size=10)
    dbCoursor = connection.cursor()
    sql_query = "INSERT INTO users(username, password, security_lvl) VALUES(%s, %s, %s)"
    params = (username, hashed, security_lvl)
    dbCoursor.execute(sql_query, params)
    connection.commit()
    dbCoursor.close()
    connection.close()
    return True

def countActiveCarts(credentials=None):
    """
    Count available orders in DB

    Args:
        credentials: dict or 'DEFAULT' or None
            {'USER': str,
             'PASSWORD': str,
             'HOST': str,
             'PORT': str,
             'DATABASE': str
             }

    Returns:
        db_ok: bool
        carts_active_count: int

    Raises:
        None
    """
    connection = dbConnection(credentials)
    dbCoursor = connection.cursor()
    sql_query = "SELECT COUNT (*) FROM carts WHERE active = true"
    dbCoursor.execute(sql_query)
    connection.commit()
    count = dbCoursor.fetchone()
    dbCoursor.close()
    connection.close()
    return True, count[0]

def countAvailableCarts(credentials=None):
    """
    Count available orders in DB

    Args:
        credentials: dict or 'DEFAULT' or None
            {'USER': str,
             'PASSWORD': str,
             'HOST': str,
             'PORT': str,
             'DATABASE': str
             }

    Returns:
        db_ok: bool
        carts_available_count: int

    Raises:
        None
    """
    connection = dbConnection(credentials)
    dbCoursor = connection.cursor()
    sql_query = "SELECT COUNT (*) FROM carts WHERE active = true AND order_no = 0"
    dbCoursor.execute(sql_query)
    connection.commit()
    count = dbCoursor.fetchone()
    dbCoursor.close()
    connection.close()
    return True, count[0]

def countAllCarts(credentials=None):
    """
    Count available orders in DB

    Args:
        credentials: dict or 'DEFAULT' or None
            {'USER': str,
             'PASSWORD': str,
             'HOST': str,
             'PORT': str,
             'DATABASE': str
             }

    Returns:
        db_ok: bool
        carts_available_count: int

    Raises:
        None
    """
    connection = dbConnection(credentials)
    dbCoursor = connection.cursor()
    sql_query = "SELECT COUNT (*) FROM carts"
    dbCoursor.execute(sql_query)
    connection.commit()
    count = dbCoursor.fetchone()
    dbCoursor.close()
    connection.close()
    return True, count[0]


def displayAlarmsCurrent(lang='EN', credentials=None):
    """
    Print alarms from alarms_current table

    Args:
        None

    Returns:
        alarms: list
            [ {subsystem: int, code: int, raise_time: time, PL/EN/DE:str, ...}, {...}]

    Raises:
        Assertion error: bad data type or out of range
    """
    assert isinstance(lang, str), "Bad lang type"
    assert lang == 'EN' or lang == 'PL' or lang == 'DE', "Bad lang value"
    if lang != 'EN' and lang != 'PL' and lang != 'DE':
        raise ValueError('Unhandled language: '+lang+'. Accepted: EN DE PL')
    connection = dbConnection(credentials)
    dbCoursor = connection.cursor()
    sql_query = """SELECT alarms_current.subsystem,
                          alarms_current.device_no,
                          alarms_current.code,
                          alarms_description.\""""+lang+"""\",
                          alarms_current.cause_active,
                          alarms_current.raise_time,
                          alarms_current.cause_gone_time
                   FROM alarms_current
                   INNER JOIN alarms_description
                   ON alarms_description.subsystem=alarms_current.subsystem and
                      alarms_description.code=alarms_current.code
                   ORDER BY alarms_current.raise_time DESC;"""

    dbCoursor.execute(sql_query)
    connection.commit()
    select_output = dbCoursor.fetchall()
    dbCoursor.close()
    return True, select_output

def displayAlarmsHistory(lang='EN', credentials=None):
    """
    Print alarms from alarms_history table

    Args:
        None

    Returns:
        alarms: list
            [ {subsystem: int, code: int, raise_time: time, PL/EN/DE:str, ...}, {...}]

    Raises:
        Assertion error: bad data type or out of range
    """
    assert isinstance(lang, str), "Bad lang type: "+str(type(str))
    assert lang == 'EN' or lang == 'PL' or lang == 'DE', "Bad lang value"
    if lang != 'EN' and lang != 'PL' and lang != 'DE':
        raise ValueError('Unhandled language: '+lang+'. Accepted: EN DE PL')
    connection = dbConnection(credentials)
    dbCoursor = connection.cursor()
    sql_query = """SELECT alarms_history.subsystem,
                        alarms_history.device_no,
                        alarms_history.code,
                        alarms_description.\""""+lang+"""\",
                        alarms_history.raise_time,
                        alarms_history.cause_gone_time,
                        alarms_history.ack_time

                   FROM alarms_history
                   INNER JOIN alarms_description
                   ON alarms_description.subsystem=alarms_history.subsystem and
                      alarms_description.code=alarms_history.code
                   ORDER BY alarms_history.raise_time DESC; """

    # params = (lang,)
    dbCoursor.execute(sql_query)
    connection.commit()
    select_output = dbCoursor.fetchall()
    dbCoursor.close()
    return True, select_output

def getCart(cart_no, credentials=None):
    """
    Get cart info from database

    Args:
        cart_no: int
            number of cart
        credentials: dict or 'DEFAULT' on None
            {'USER': str,
             'PASSWORD': str,
             'HOST': str,
             'PORT': str,
             'DATABASE': str
             }

    Returns:
        db_ok: bool
        output: list [no: int, 'status': int, ...]


    Raises:
        Bad input parameter type
    """
    assert isinstance(cart_no, int), "Bad type of cart_no: "+str(type(cart_no))
    output = []
    connection = dbConnection(credentials)
    dbCoursor = connection.cursor()
    sql_query = "SELECT no, status, order_no, speed, ip_address, track_actual, track_position, direction, active FROM carts where no = %s"
    params = (cart_no,)
    dbCoursor.execute(sql_query, params)
    connection.commit()
    sql_output = dbCoursor.fetchone()
    dbCoursor.close()
    connection.close()
    return True, sql_output

def getUserPswdHash(username, credentials=None):
    """
    Get user hashed password from database

    Args:
        username: str
        credentials: dict or 'DEFAULT' or None
            {'USER': str,
             'PASSWORD': str,
             'HOST': str,
             'PORT': str,
             'DATABASE': str
             }

    Returns:
        db_ok: bool
        hashed: str
            hashed password

    Raises:
        Bad input parameter type
    """
    output = ''
    assert isinstance(username, str), 'Bad username type!'
    connection = dbConnection(credentials)
    dbCoursor = connection.cursor()
    sql_query = "SELECT password FROM users WHERE username = %s"
    params = (username,)
    dbCoursor.execute(sql_query, params)
    connection.commit()
    output = dbCoursor.fetchone()

    dbCoursor.close()
    connection.close()
    if output is None:
        return False, None
    return True, output[0]

def getCartsStatus(credentials=None):
    """
    Get all carts statuses from database

    Args:
        credentials: dict or 'DEFAULT' on None
            {'USER': str,
             'PASSWORD': str,
             'HOST': str,
             'PORT': str,
             'DATABASE': str
             }

    Returns:
        db_ok: bool
        output: list [{'cart_no': int, 'status': int}, ...]


    Raises:
        Bad input parameter type
    """
    output = []
    connection = dbConnection(credentials)
    dbCoursor = connection.cursor()
    sql_query = "SELECT no, status FROM carts ORDER BY no ASC"
    dbCoursor.execute(sql_query)
    connection.commit()
    sql_output = dbCoursor.fetchall()
    for data in sql_output:
        output.append({'cart_no': data[0], 'status': data[1]})

    dbCoursor.close()
    connection.close()
    return True, output

def getUsersList(credentials=None):
    """
    Get security level from user in database

    Args:
        username: str
        credentials: dict or 'DEFAULT' or None
            {'USER': str,
             'PASSWORD': str,
             'HOST': str,
             'PORT': str,
             'DATABASE': str
             }

    Returns:
        db_ok: bool
        security_lvl: int

    Raises:
        Bad input parameter type
    """
    output = ''
    connection = dbConnection(credentials)
    dbCoursor = connection.cursor()
    sql_query = "SELECT username, security_lvl FROM users ORDER BY username ASC"
    dbCoursor.execute(sql_query,)
    connection.commit()
    output = dbCoursor.fetchall()
    dbCoursor.close()
    connection.close()
    if output is None:
        return False, None
    return True, output

def getUserSecurityLvl(username, credentials=None):
    """
    Get security level from user in database

    Args:
        username: str
        credentials: dict or 'DEFAULT' or None
            {'USER': str,
             'PASSWORD': str,
             'HOST': str,
             'PORT': str,
             'DATABASE': str
             }

    Returns:
        db_ok: bool
        security_lvl: int

    Raises:
        Bad input parameter type
    """
    output = ''
    assert isinstance(username, str), 'Bad username type!'
    connection = dbConnection(credentials)
    dbCoursor = connection.cursor()
    sql_query = "SELECT security_lvl FROM users WHERE username = '" + username +"'"
    dbCoursor.execute(sql_query,)
    connection.commit()
    output = dbCoursor.fetchone()
    dbCoursor.close()
    connection.close()
    print(output)
    if output is None:
        return False, None
    return True, output[0]

def setUserSecurityLvl(username, security_lvl, credentials=None):
    """
    Set security level for user in database

    Args:
        username: str
        password: str
        security_lvl: int
        credentials: dict or 'DEFAULT' or None
            {'USER': str,
             'PASSWORD': str,
             'HOST': str,
             'PORT': str,
             'DATABASE': str
             }

    Returns:
        db_ok: bool

    Raises:
        Bad input parameter type or value
    """
    assert (isinstance(security_lvl, int) and security_lvl >= 0), 'Bad security_lvl type or value below 0!'
    assert isinstance(username, str), 'Bad username type!'
    connection = dbConnection(credentials)
    dbCoursor = connection.cursor()
    sql_query = "Update users SET security_lvl = %s WHERE username = %s"
    params = (security_lvl, username)
    dbCoursor.execute(sql_query, params)
    connection.commit()
    dbCoursor.close()
    connection.close()
    return True

def changeUserPassword(username, password, credentials=None):
    """
    Change user password in database

    Args:
        username: str
        password: str
        credentials: dict or 'DEFAULT' or None
            {'USER': str,
             'PASSWORD': str,
             'HOST': str,
             'PORT': str,
             'DATABASE': str
             }

    Returns:
        db_ok: bool

    Raises:
        Bad input parameter type
    """
    assert isinstance(password, str), 'Bad password type!'
    assert isinstance(username, str), 'Bad username type!'
    connection = dbConnection(credentials)
    hashed = pbkdf2_sha256.hash(password, rounds=8000, salt_size=10)
    dbCoursor = connection.cursor()
    sql_query = "UPDATE users SET password=%s WHERE username = %s"
    params = (hashed, username)
    dbCoursor.execute(sql_query, params)
    connection.commit()
    dbCoursor.close()
    connection.close()
    return True

def checkUserExistence(username, credentials=None):
    """
    Check if user exists in DB

    Args:
        username : str
        credentials: dict or 'DEFAULT' or None
            {'USER': str,
             'PASSWORD': str,
             'HOST': str,
             'PORT': str,
             'DATABASE': str
             }

    Returns:
        db_ok: bool
        user_exists: bool

    Raises:
        Bad input parameter type
    """
    assert isinstance(username, str), 'Bad username type!'
    connection = dbConnection(credentials)
    dbCoursor = connection.cursor()
    sql_query = "SELECT 1 FROM users WHERE username = %s"
    params = (username,)
    dbCoursor.execute(sql_query, params)
    select_output = dbCoursor.fetchone()
    if select_output is None:
        exists = False
    else:
        exists = True
    connection.commit()
    dbCoursor.close()
    connection.close()
    return True, exists

def countAvailableOrders(credentials=None):
    """
    Count available orders in DB

    Args:
        credentials: dict or 'DEFAULT' or None
            {'USER': str,
             'PASSWORD': str,
             'HOST': str,
             'PORT': str,
             'DATABASE': str
             }

    Returns:
        db_ok: bool
        orders_count: int

    Raises:
        None
    """
    connection = dbConnection(credentials)
    dbCoursor = connection.cursor()
    sql_query = "SELECT COUNT (*) FROM orders WHERE status = 1"
    dbCoursor.execute(sql_query)
    connection.commit()
    count = dbCoursor.fetchone()
    dbCoursor.close()
    connection.close()
    return True, count[0]

def createUser(username, password, credentials=None):
    """
    Create user password in database

    Args:
        username: str
        password: str
        credentials: dict or 'DEFAULT' or None
            {'USER': str,
             'PASSWORD': str,
             'HOST': str,
             'PORT': str,
             'DATABASE': str
             }

    Returns:
        db_ok: bool

    Raises:
        Bad input parameter type
    """
    assert isinstance(password, str), 'Bad password type!'
    assert isinstance(username, str), 'Bad username type!'
    connection = dbConnection(credentials)
    hashed = pbkdf2_sha256.hash(password, rounds=8000, salt_size=10)
    dbCoursor = connection.cursor()
    sql_query = "INSERT INTO users(username, password, security_lvl) VALUES(%s, %s, 0)"
    params = (username, hashed)
    dbCoursor.execute(sql_query, params)
    connection.commit()
    dbCoursor.close()
    connection.close()
    return True


def testCode():
    # db_ok, count = countAvailableOrders()
    # print('count: ', count)
    db_ok, cart_info = getCart(96)
    print('cart_info: ', cart_info)

# testCode()
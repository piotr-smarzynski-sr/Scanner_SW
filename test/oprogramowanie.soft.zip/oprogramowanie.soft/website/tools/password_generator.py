from passlib.hash import pbkdf2_sha256
import argparse

parser = argparse.ArgumentParser()

parser.add_argument('password', help='User password to hash', type=str)
args = parser.parse_args()

hashed = pbkdf2_sha256.hash(args.password)
print('hash: ', hashed)

pswd_ok = pbkdf2_sha256.verify(args.password, hashed)
print('password_ok: ', pswd_ok)

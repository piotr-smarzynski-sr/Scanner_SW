from enum import Enum

class CartStatus(Enum):
    NG = 0
    STOPPED = 1
    MOVING = 2
    ON_STATION = 3
    MANUAL = 4

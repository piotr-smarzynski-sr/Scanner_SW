#Module that mocks main_app's responses to requests

from multiprocessing.connection import Listener
from queue import Queue, Empty
from threading import Thread, Lock
import time

address = ('localhost', 6000)     # family is deduced to be 'AF_INET'

def getQ(q):
    try:
        data = q.get_nowait()
        return data
    except Empty:
        return None


class RouterConnector(object):
    def __init__(self, name, router):
        self.name = name
        self.router = router
        self.commands = Queue()
        self.results = Queue()
    def sendCommand(self, cmd):
        self.commands.put(cmd)
    def getResult(self):
        return self.results.get()
    def getCommand(self):
        return getQ(self.commands)
    def sendResult(self, result):
        self.results.put(result)
    

class CommandRouter(object):
    def __init__(self):
        self.targets = []
        self.lock = Lock()
        self.rx_thread = Thread(target=self.receiveThread, daemon=True)
        self.rx_thread.start()
    def getConnector(self, target_name):
        with self.lock:
            for t in self.targets:
                if t.name == target_name:
                    return t
            # Not found
            connector = RouterConnector(target_name, self)
            self.targets.append(connector)
            return connector


    def receiveThread(self):
        with Listener(address, authkey=b'secret password') as listener:
            while True:
                with listener.accept() as conn:
                    try:
                        print('connection accepted from', listener.last_accepted)
                        while True:
                            req = conn.recv()
                            resp = self.processCommand(req)
                            conn.send(resp)
                    except EOFError as e:
                        conn.close()
    
    def processCommand(self, command):
        resp = None
        with self.lock:
            for target in self.targets:
                if target.name == command['target']:
                    target.sendCommand(command)
                    resp = target.getResult()  # We lock target until it has responded
                    break
        if resp is None:
            resp = {"status":"Error", "info":"Target not found"}
        return resp

    
cr = CommandRouter()
cart1_conn = cr.getConnector("cart/1")

def cart_thread(conn, speed):
    while True:
        cmd = conn.getCommand()
        #time.sleep(0.2) # simulate processing
        if cmd != None:
            if cmd['command'] == 'ReadVar' and cmd['varName'] == 'Speed':
                resp = {'status':"OK", "speed":speed}
                conn.sendResult(resp)
            else:
                conn.sendResult({'status':'Error', 'info':'Unknown command'})
        
t1 = Thread(target=cart_thread, args=(cr.getConnector("cart/1"), 45), daemon=True)
t2 = Thread(target=cart_thread, args=(cr.getConnector("cart/4"), 123), daemon=True)
t3 = Thread(target=cart_thread, args=(cr.getConnector("cart/7"), 62), daemon=True)

t1.start()
t2.start()
t3.start()

while True:
    pass
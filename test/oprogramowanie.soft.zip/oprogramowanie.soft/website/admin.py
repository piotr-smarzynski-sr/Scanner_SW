from flask import Blueprint, request, render_template, flash, redirect, url_for, session
import secure
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, IntegerField, validators
from wtforms.validators import DataRequired
from db_communication import getUsersList, checkUserExistence, changeUserPassword, createUser
from db_communication import setUserSecurityLvl, getUserSecurityLvl

class PasswordChangeForm(FlaskForm):
    password = PasswordField('Password', [validators.DataRequired()])
    confirm = PasswordField('Confirm Password', [validators.DataRequired(),
                                          validators.EqualTo(password, message='Passwords must match')])
    session_password = PasswordField('Session Password', validators=[DataRequired()])

class SecurityLevelChangeForm(FlaskForm):
    security = IntegerField('Security', validators=[DataRequired()])
    session_password = PasswordField('Session Password', validators=[DataRequired()])

class RegisterForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', [validators.DataRequired(),
                                          validators.EqualTo('confirm', message='Passwords must match')])
    confirm = PasswordField('Confirm Password', validators=[DataRequired()])

users_page = Blueprint('users_page', __name__)


@users_page.route('/admin/users/', methods=['GET', 'POST'])
@secure.minPermissionLevel(secure.Permissions.ADMIN)
def users():
    form = RegisterForm()
    if request.method == 'POST':
        if form.validate_on_submit():
            username = request.form['username']
            confirm = request.form['confirm']
            password = request.form['password']
            db_ok, user_exists = checkUserExistence(username)
            if user_exists is False and db_ok is True:
                createUser(username, password)
                flash('User '+username+' created!')
                return redirect(url_for('index'))

            if user_exists is True and db_ok is True:
                flash('User already exists!')
                return redirect(url_for('login_page.login'))
        else:
            return "err"
    else:
        db_ok, users_list = getUsersList()
        users=[]
        if db_ok:
            for index, user in enumerate(users_list):
                print('user: ', user)
                users.append({"id": index+1,
                                "username": user[0],
                                "security": user[1],
                                "modify": "Modify",
                                "remove": "Remove"})

        return render_template("users_list.html",
                                users=users,
                                form=form)
    # return "Users[]"
    
@users_page.route('/admin/users/<username>', methods=['GET', 'POST'])
@secure.minPermissionLevel(secure.Permissions.ADMIN)
def user(username):
    form = PasswordChangeForm()
    form1 = SecurityLevelChangeForm()
    if request.method == 'POST':
        if form.validate_on_submit():
            password = request.form['password']
            confirm = request.form['confirm']
            session_password = request.form['session_password']
            db_ok = checkUserExistence(username)
            authenticated = secure.authenticateUser(session.get('username'), session_password)
            if authenticated:
                if db_ok:
                    db_ok = changeUserPassword(username, password)
                    flash('User '+username+' has new password!')
                    return redirect(url_for("users_page.user", username=username))

                else:
                    flash('User '+username+' does not exists!')
                    return redirect(url_for("users_page.users"))

            else:
                flash('User '+session.get('username')+' not authenticated!')
                return redirect(url_for("users_page.user", username=username))

        # if 'confirm' in form.errors:
        #     flash('Passwords were different!')
        #     return redirect(url_for("users_page.user", username=username))

        elif form1.validate_on_submit():
            security = request.form['security']
            session_password = request.form['session_password']
            authenticated = secure.authenticateUser(session.get('username'), session_password)
            if authenticated:
                db_ok = setUserSecurityLvl(username, int(security))
                if db_ok:
                    flash('User '+username+' has new security level!')
                    return redirect(url_for("users_page.user", username=username))
                else:
                    flash('User '+username+' does not exists!')
                    return redirect(url_for("users_page.users"))

            else:
                flash('User '+session.get('username')+' not authenticated!')
                return redirect(url_for("users_page.user", username=username))
        else:
            flash('Passwords not matched') # TODO przenieść ten błąd w sensowniejsze miejsce
            return redirect(url_for("users_page.user", username=username))
    else:
        db_ok, security = getUserSecurityLvl(username)
        return render_template('user_modify.html',
                               username=session.get('username'),
                               form=form,
                               form1=form1,
                               user_username=username,
                               security=security)
    # return "User: " + username 
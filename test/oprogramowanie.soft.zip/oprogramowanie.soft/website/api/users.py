from flask import Blueprint, request, render_template, flash, redirect, url_for, session, jsonify
from flask.views import MethodView
import secure

user_api = Blueprint('user_api', __name__)

@secure.minPermissionLevel(secure.Permissions.ADMIN)
def getAllUsers():
    resp = []
    for username, passwd, level in secure.USERS:
        usr = {}
        usr['username'] = username
        usr['security'] = level
        resp.append(usr)
    return jsonify(resp)


def getUser(user_id):
    # Allow acces only by admin and user with matching id
    if secure.userMatches(user_id) or secure.securityLevel() >= secure.Permissions.ADMIN:
        return jsonify({'username':'user', 'security':0}) # TODO
    else:
        return secure.permissionDenied()

class UserAPI(MethodView):
    def get(self, user_id):
        if user_id is None:
            return getAllUsers()
        else:
            return getUser(user_id)

    def post(self):
        # create a new user
        pass

    def delete(self, user_id):
        # delete a single user
        pass

    def put(self, user_id):
        # update a single user
        pass


user_view = UserAPI.as_view('user_api')
user_api.add_url_rule('/api/users/', defaults={'user_id': None},
                 view_func=user_view, methods=['GET',])
user_api.add_url_rule('/api/users/', view_func=user_view, methods=['POST',])
user_api.add_url_rule('/api/users/<user_id>', view_func=user_view,
                 methods=['GET', 'PUT', 'DELETE'])
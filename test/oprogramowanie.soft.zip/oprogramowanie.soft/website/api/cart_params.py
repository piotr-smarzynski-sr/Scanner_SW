from flask import Blueprint, request, render_template, flash, redirect, url_for, session
import secure

cart_params_api = Blueprint('cart_params_api', __name__)

@cart_params_api.route('/api/cart/<cart_id>/parameter/fw_version', methods=['GET'])
@secure.minPermissionLevel(secure.Permissions.GUEST)
def cart_fw_version(cart_id):
    return {'fw_version':0.1}


from functools import wraps
from passlib.hash import pbkdf2_sha256
from enum import IntEnum
from flask import redirect, url_for, request, flash, session
import copy

from db_communication import getUserPswdHash, getUserSecurityLvl

class Permissions(IntEnum):
    NONE = 0
    GUEST = 100
    USER = 200
    ADV_USER = 300
    ADMIN = 1000
    DEV = 2000


def authenticateUser(username, password):
    db_ok, hashed = getUserPswdHash(username)
    if db_ok is True:
        if pbkdf2_sha256.verify(password, hashed):
            return True
    return False

def permissionDenied():
    flash("Insufficient permissions!")
    return redirect(url_for('login_page.login', next=request.url))


def securityLevel():
    user = session.get('username', None)
    if user == None:
        return Permissions.NONE

    ok, level = getUserSecurityLvl(user)
    if ok:
        return level
    else:
        return Permissions.NONE
    

def userMatches(user_id):
    user = session.get('username', None)
    if user == None:
        return False
    if user == user_id:
        return True
    else:
        return False

def minPermissionLevel(level):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if securityLevel() < level:
                
                flash("Insufficient permissions!")
                return redirect(url_for('login_page.login', next=request.url))
            else:
                return f(*args, **kwargs)
        return decorated
    return decorator
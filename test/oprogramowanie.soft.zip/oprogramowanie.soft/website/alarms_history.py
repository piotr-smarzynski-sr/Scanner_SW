from flask import Blueprint, request, render_template, flash, redirect, url_for, session
from flask_wtf import FlaskForm

from db_communication import displayAlarmsHistory, acknowledgeAllAlarms
import secure

class AcknowledgeAllAlarmsForm(FlaskForm):
    pass

alarms_history_page = Blueprint('alarms_history', __name__)

@alarms_history_page.route("/alarms_history", methods=['GET', 'POST'])
@secure.minPermissionLevel(secure.Permissions.ADV_USER)
def alarms_history():
    form = AcknowledgeAllAlarmsForm()
    if request.method == 'POST':
        if form.validate_on_submit():
            db_ok = acknowledgeAllAlarms()
            if db_ok is True:
                flash('Alarms acknowledged!')
                return redirect(url_for('alarms_history.alarms_history'))
        else:
            return "err"
    else:
        db_ok, alarms_get = displayAlarmsHistory()
        alarms = []
        if db_ok:
            for alarm in alarms_get:
                code = alarm[0] + str(alarm[1]) + '.' + str(alarm[2])
                description = alarm[3]
                if alarm[4] is not None:
                    raise_time = alarm[4].strftime("%m/%d/%Y, %H:%M:%S")
                else:
                    raise_time = 'None'

                if alarm[5] is not None:
                    cause_gone_time = alarm[5].strftime("%m/%d/%Y, %H:%M:%S")
                else:
                    cause_gone_time = 'None'

                if alarm[6] is not None:
                    ack_time = alarm[6].strftime("%m/%d/%Y, %H:%M:%S")
                else:
                    ack_time = 'None'

                alarms.append({"code": code,
                            "description": description,
                            "raise_time": raise_time,
                            "cause_gone_time": cause_gone_time,
                            "ack_time": ack_time})

        return render_template("alarms_history.html",
                            alarms=alarms,
                            form=form)

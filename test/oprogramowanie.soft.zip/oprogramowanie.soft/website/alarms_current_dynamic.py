from flask import Blueprint, request, render_template, flash, redirect, url_for, session
from flask_wtf import FlaskForm
from flask import jsonify

from db_communication import displayAlarmsCurrent, acknowledgeAllAlarms
import secure

class AcknowledgeAllAlarmsForm(FlaskForm):
    pass

alarms_current__dynamic_page = Blueprint('alarms_current_dynamic', __name__)

@alarms_current__dynamic_page.route('/more/', methods=['POST'])
def _more():
    db_ok, alarms_get = displayAlarmsCurrent()
    print('alarms_get: ', alarms_get)
    alarms = []
    if db_ok:
        for alarm in alarms_get:
            code = alarm[0] + str(alarm[1]) + '.' + str(alarm[2])
            description = alarm[3]
            cause_active = alarm[4]
            if alarm[5] is not None:
                raise_time = alarm[5].strftime("%m/%d/%Y, %H:%M:%S")
            else:
                raise_time = 'None'

            if alarm[6] is not None:
                cause_gone_time = alarm[6].strftime("%m/%d/%Y, %H:%M:%S")
            else:
                cause_gone_time = 'None'

            alarms.append({"code": code,
                        "description": description,
                        "cause_active": cause_active,
                        "raise_time": raise_time,
                        "cause_gone_time": cause_gone_time})

    return jsonify(alarms)

from functools import partial
import tkinter as tk
import time
from queue import Queue

FWD = 1
BWD = -1
STOP = 0

queue_input = Queue()
queue_output = Queue()

class SampleApp(tk.Tk):

    def __init__(self, *args, **kwargs):
        tk.Tk.__init__(self, *args, **kwargs)
        self.title('Cart simulator GUI')
        self.geometry('800x320')
        # self.grid_columnconfigure(0, minsize=80)
        # self.grid_columnconfigure(1, minsize=40)
        # self.grid_columnconfigure(2, minsize=40)
        # self.grid_columnconfigure(3, minsize=80)
        # self.grid_columnconfigure(4, minsize=80)
        # self.grid_columnconfigure(5, minsize=80)
        self.queue_input = queue_input
        self.queue_output = queue_output
        self.velocity = 0
        self.direction = 0
        self.on_route = 0

        def velo_minus():
            velo = self.velocity - 1
            if velo < 0:
                velo = 0

            queue_output.put({'velo': velo})

        def velo_plus():
            velo = self.velocity + 1
            if velo > 3:
                velo = 3

            queue_output.put({'velo': velo})

        def velo_set(velo):
            if velo > 3:
                velo = 3
            if velo < 0:
                velo = 0

            queue_output.put({'velo': velo})

        def dir_set(dir):
            queue_output.put({'dir': dir})

        def route_done():
            queue_output.put({'route done': 1})

        def track_set(track):
            queue_output.put({'track_set': track})

        def set_alarm(alarm_index):
            queue_output.put({'alarm_set': alarm_index})

        def reset_alarm(alarm_index):
            queue_output.put({'alarm_reset': alarm_index})

        row = 0
        self.label_cart_no_name = tk.Label(self, text="Cart ID")
        self.label_cart_no_name.grid(column=0, row=row)


        self.label_cart_no = tk.Label(self, text="", justify='right')
        self.label_cart_no.grid(column=1, row=0)

        row += 1
        self.label_velo_name = tk.Label(self, text="Speed")
        self.label_velo_name.grid(column=0, row=row)

        self.label_velo = tk.Label(self, text="", justify='right')
        self.label_velo.grid(column=1, row=row)

        self.button_velo_plus = tk.Button(self, text=" + ", command=velo_plus)
        self.button_velo_plus.grid(column=2, row=row)

        self.button_velo_minus = tk.Button(self, text=" - ", command=velo_minus)
        self.button_velo_minus.grid(column=3, row=row)

        self.button_velo_stop = tk.Button(self, text=" STOP ", command=partial(velo_set, velo=0))
        self.button_velo_stop.grid(column=4, row=row)

        self.button_velo_1 = tk.Button(self, text=" 1 ", command=partial(velo_set, velo=1))
        self.button_velo_1.grid(column=5, row=row)

        self.button_velo_2 = tk.Button(self, text=" 2 ", command=partial(velo_set, velo=2))
        self.button_velo_2.grid(column=6, row=row)

        self.button_velo_3 = tk.Button(self, text=" 3 ", command=partial(velo_set, velo=3))
        self.button_velo_3.grid(column=7, row=row)

        row += 1
        self.label_dir_name = tk.Label(self, text="Direction")
        self.label_dir_name.grid(column=0, row=row)

        self.label_dir = tk.Label(self, text="", justify='right')
        self.label_dir.grid(column=1, row=row)

        self.button_dir_bwd = tk.Button(self, text="BWD", command=partial(dir_set, dir=BWD))
        self.button_dir_bwd.grid(column=2, row=row)

        self.button_dir_stop = tk.Button(self, text="STOP", command=partial(dir_set, dir=STOP))
        self.button_dir_stop.grid(column=3, row=row)

        self.button_dir_fwd = tk.Button(self, text="FWD", command=partial(dir_set, dir=FWD))
        self.button_dir_fwd.grid(column=4, row=row)

        row += 1
        self.label_track_name = tk.Label(self, text="Track")
        self.label_track_name.grid(column=0, row=row)

        self.label_track = tk.Label(self, text="", justify='right')
        self.label_track.grid(column=1, row=row)

        row += 1
        self.label_position_name = tk.Label(self, text="Position")
        self.label_position_name.grid(column=0, row=row)

        self.label_position = tk.Label(self, text="", justify='right')
        self.label_position.grid(column=1, row=row)

        row += 1
        self.label_on_route_name = tk.Label(self, text="On route")
        self.label_on_route_name.grid(column=0, row=row)

        self.label_on_route = tk.Label(self, text="", justify='right')
        self.label_on_route.grid(column=1, row=row)

        self.button_route_done = tk.Button(self, text="Route done", command=route_done)
        self.button_route_done.grid(column=2, row=row)

        row += 1
        self.label_destination_name = tk.Label(self, text="Destination")
        self.label_destination_name.grid(column=0, row=row)

        self.label_destination = tk.Label(self, text="None", justify='right')
        self.label_destination.grid(column=1, row=row)

        row += 1
        self.label_collision_name = tk.Label(self, text="Collisions")
        self.label_collision_name.grid(column=0, row=row)

        self.label_collision_bwd = tk.Label(self, text="None", justify='right')
        self.label_collision_bwd.grid(column=1, row=row)

        self.label_collision_fwd = tk.Label(self, text="None", justify='right')
        self.label_collision_fwd.grid(column=2, row=row)

        row += 1
        column = 0
        self.label_track_set_name = tk.Label(self, text="Track set")
        self.label_track_set_name.grid(column=0, row=row)

        column += 2
        for x in range(6):
            self.label_track_set0 = tk.Button(self, text="T"+str(x), command=partial(track_set, track="T"+str(x)))
            self.label_track_set0.grid(column=column, row=row)
            column += 1 

        row += 1
        column = 0
        self.label_alarm_set_name = tk.Label(self, text="Alarm set")
        self.label_alarm_set_name.grid(column=0, row=row)

        column += 2
        for x in range(8):
            self.label_alarm_set0 = tk.Button(self, text="Set alarm "+str(x), command=partial(set_alarm, alarm_index=x))
            self.label_alarm_set0.grid(column=column, row=row)
            column += 1 

        row += 1
        column = 0
        self.label_alarm_reset_name = tk.Label(self, text="Alarm reset")
        self.label_alarm_reset_name.grid(column=0, row=row)

        column += 2
        for x in range(8):
            self.label_alarm_set0 = tk.Button(self, text="Reset alarm "+str(x), command=partial(reset_alarm, alarm_index=x))
            self.label_alarm_set0.grid(column=column, row=row)
            column += 1 

        row += 1
        self.label_alarms_state_name = tk.Label(self, text="Alarms state")
        self.label_alarms_state_name.grid(column=0, row=row)

        self.label_alarms_state = tk.Label(self, text="None", justify='right')
        self.label_alarms_state.grid(column=1, row=row)

        col_count, row_count = self.grid_size()

        for col in range(col_count):
            self.grid_columnconfigure(col, minsize=60)

        for row in range(row_count):
            self.grid_rowconfigure(row, minsize=25)

        self.update_labels()

    def update_labels(self):
        if self.queue_input.empty() == False:
            queue_element = self.queue_input.get()
            # print('queue_element: ', queue_element)
            if 'cart_no' in queue_element:
                self.label_cart_no.configure(text=queue_element['cart_no'])

            if 'velo' in queue_element:
                self.velocity = queue_element['velo']
                self.label_velo.configure(text=self.velocity)

            if 'dir' in queue_element:
                self.direction = queue_element['dir']
                self.label_dir.configure(text=self.direction)

            if 'track' in queue_element:
                self.label_track.configure(text=queue_element['track'])

            if 'position' in queue_element:
                self.label_position.configure(text=queue_element['position'])

            if 'on_route' in queue_element:
                self.on_route = queue_element['on_route']
                self.label_on_route.configure(text=self.on_route)
                if self.on_route == 0:
                    self.label_destination.configure(text='None')

            if 'destination' in queue_element:
                self.label_destination.configure(text=queue_element['destination'])

            if 'collision fwd' in queue_element:
                self.label_collision_fwd.configure(text=queue_element['collision fwd'])

            if 'collision bwd' in queue_element:
                self.label_collision_bwd.configure(text=queue_element['collision bwd'])

            if 'alarms' in queue_element:
                alarms_output =''
                for x in range(8):
                    alarms_output += str(queue_element['alarms'].getAlarm(x))
                
                self.label_alarms_state.configure(text=alarms_output)

        # call this function again in one second
        self.after(1, self.update_labels)

def gui():
    app = SampleApp()
    app.mainloop()
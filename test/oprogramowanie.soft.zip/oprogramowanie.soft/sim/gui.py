from tkinter import *
from time import time as now
from time import sleep
from other import getFromQueue
from colorama import init, Fore
from thread_print import s_print
# from queue import Queue()

init(convert=True) #COLORAMA

def gui(running, queue_input, cart_name):
    function_name = Fore.LIGHTCYAN_EX+'gui: '+Fore.RESET
    window = Tk()
    break_flag = False
    velocity = 0
    on_route = False
    track = ''
    position = 0
    destination = -1

    lbl_velo_textvar = "Speed: "+ str(velocity)

    def clicked():
        res = "Welcome to " + txt.get()
        lbl.configure(text= res)
    
    def on_closing():
        global break_flag
        window.destroy()
        break_flag = True

    timer_counter = now()    
    window.geometry('350x200')
    window.protocol("WM_DELETE_WINDOW", on_closing)
    window.title("Cart Simulator GUI")
    lbl = Label(window, text="Hello", font=("Arial Bold", 10))
    lbl.grid(column=0, row=0)

    lbl_cart_no = Label(window, text="Cart: "+ str(cart_name), font=("Arial Bold", 10))
    lbl_cart_no.grid(column=0, row=2)

    lbl_velo = Label(window, textvariable=lbl_velo_textvar, font=("Arial Bold", 10))
    lbl_velo.grid(column=0, row=3)

    lbl_track = Label(window, text="Track: "+ str(track), font=("Arial Bold", 10))
    lbl_track.grid(column=0, row=4)

    lbl_position = Label(window, text="Position: "+ str(position), font=("Arial Bold", 10))
    lbl_position.grid(column=0, row=5)

    lbl_on_route = Label(window, text="On route: "+ str(on_route), font=("Arial Bold", 10))
    lbl_on_route.grid(column=0, row=6)

    lbl_destination = Label(window, text="Destination: "+ str(destination), font=("Arial Bold", 10))
    lbl_destination.grid(column=0, row=7)

    txt = Entry(window,width=10)
    txt.grid(column=0, row=1)

    btn = Button(window, text="Click Me", command=clicked)
    btn.grid(column=1, row=0)

    counter = 0
    while(running):
        if queue_input.empty() == False:
            queue_ok, queue_element = getFromQueue(queue_input)            
            if queue_ok == False:
                s_print((function_name, Fore.LIGHTRED_EX+'Cannot get queue element!'+Fore.RESET))
            if queue_ok == True:
                print('queue_element: ', queue_element)
                if 'velocity' in queue_element:
                    velocity = queue_element['velocity']
                    lbl_velo_textvar = "Speed: "+ str(velocity)
                    # lbl_velo = Label(window, text="V: "+ str(velocity), font=("Arial Bold", 10))
                    window.update()
                    # s_print("GUI updated")

                if 'ON_ROUTE' in queue_element:
                    on_route = queue_element['ON_ROUTE']
                    # lbl_on_route = Label(window, text="On route: "+ str(on_route), font=("Arial Bold", 10))
                    # lbl_on_route.update(text="On route: "+ str(on_route))
                    window.update()

                if 'DESTINATION' in queue_element:
                    destination = queue_element['DESTINATION']
                    lbl_destination = Label(window, text="Destination: "+ str(destination), font=("Arial Bold", 10))
                    window.update()

                if 'track' in queue_element:
                    track = queue_element['track']
                    lbl_track = Label(window, text="Track: "+ str(track), font=("Arial Bold", 10))
                    window.update()

                if 'position' in queue_element:
                    position = queue_element['position']
                    lbl_position = Label(window, text="Position: "+ str(position), font=("Arial Bold", 10))
                    window.update()

            window.update()
        # if now() - timer_counter > 1:
        #     timer_counter = now()
        #     counter += 1
        #     window.title("Welcome to LikeGeeks app " + str(counter))

        if break_flag == True:
            break


        window.update()
        sleep(0.1)
    
    on_closing()


from thread_print import s_print

def obstacle_set(cart, obstacle, side):
    obstacle = True
    s_print('Obstacle for ', cart.get_name(), 'in', side, 'set to', obstacle)
    

def obstacle_reset(cart, obstacle, side):
    obstacle = False
    s_print('Obstacle for ', cart.get_name(), 'in', side, 'set to', obstacle)
    
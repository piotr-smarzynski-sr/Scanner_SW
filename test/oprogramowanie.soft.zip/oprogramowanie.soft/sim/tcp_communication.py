from colorama import init, Fore
import struct
from thread_print import s_print
from thread_print import getHour

from msg.communication_payloads import CartConnStatus, CartConnStatusResp, CartHello, CartHelloResp, GetIP, GetIPResp
from msg.travel_payloads import GoTo, GoToResp, GoDist, GoDistResp, RouteDone, RouteDoneResp, CollisionAhead, CollisionAheadResp
from msg.messages import buildMessage

from gui2 import queue_input as gui_queue

FWD = 1
BWD = -1
STOP = 0

init(convert=True) #COLORAMA

def tcpReceiveHeader(function_name, socket, header, header_buffer, message_buffer, header_ok, HEADERSIZE=7):
    function_name += Fore.YELLOW+' tcpReceiveHeader: '+Fore.RESET
    try:
        header = socket.recv(HEADERSIZE)
        if len(header) == HEADERSIZE:
            header_ok = True
        else:
            s_print(function_name, Fore.LIGHTRED_EX, 'Bad header size:', Fore.RESET, len(header))
            header_buffer += header
            if len(header_buffer) >=  HEADERSIZE:
                header = header_buffer[:HEADERSIZE]
                message_buffer = header_buffer[HEADERSIZE:]
                header_buffer = b''
                header_ok = True
    except:
        pass

    return header, header_buffer, message_buffer, header_ok

def tcpReceiveMessage(function_name, cart, cart_name, socket, header, header_ok, message_buffer, rx_port_tcp=12345, HEADERSIZE=6):
    function_name += Fore.YELLOW+' tcpReceiveMessage: '+Fore.RESET
    if len(header) == HEADERSIZE:
        msg_len, msg_type, cart_id = headerParser(function_name, header)
        # s_print(function_name, getHour(), 'Received header: [msg_len, msg_type, cart_id]= [',msg_len, hex(msg_type), cart_id,']')

        msg_receive_ok = False
        try:
            msg = socket.recv(msg_len)
            msg_receive_ok = True
        except:
            s_print(function_name, Fore.LIGHTRED_EX, "Connection was broken during receiving", Fore.RESET)

        if msg_receive_ok:
            if len(message_buffer) > 0:
                msg = message_buffer + msg
                message_buffer = b''

            socket.setblocking(False)
            if msg_type == CartConnStatus.MSG_TYPE:
                # message_rx = CartConnStatus.Deserialize(msg)
                # # if message_rx.status != 1:
                # #     s_print(function_name, 'Connection error, status:', message_rx.status)

                # # message_tx = CartConnStatusResp(1)
                # message_tx = CartConnStatusResp(1)
                # message_tx_bytes = buildMessage(message_tx, cart_name)
                # socket.send(message_tx_bytes)
                pass

            if msg_type == GoTo.MSG_TYPE:
                message_rx = GoTo.Deserialize(msg)                
                cart.ON_ROUTE = True
                print(function_name, 'cart.ON_ROUTE: ', cart.ON_ROUTE)
                cart.DESTINATION = message_rx.stop_track_num
                s_print(function_name, 'GoTo:\n', message_rx, '\nAnswering status 1')
                message_tx = GoToResp(1)
                message_tx_bytes = buildMessage(message_tx, cart_name)
                socket.send(message_tx_bytes)

            if msg_type == GetIP.MSG_TYPE:
                message_rx = GetIP.Deserialize(msg)
                s_print(function_name, 'GetIP, answering', getIP())
                message_tx = GetIPResp(getIP())
                message_tx_bytes = buildMessage(message_tx, cart_name)
                socket.send(message_tx_bytes)

            if msg_type == RouteDoneResp.MSG_TYPE:
                cart.ON_ROUTE = False
                print(function_name, 'cart.ON_ROUTE: ', cart.ON_ROUTE)
                message_rx = RouteDoneResp.Deserialize(msg)
                s_print(function_name, getHour(), 'RouteDoneResp status:', message_rx.status)

            if msg_type == CartHelloResp.MSG_TYPE:
                message_rx = CartHelloResp.Deserialize(msg)
                s_print(function_name, 'CartHelloResp cart_no:', message_rx.cart_no)

            if msg_type == CollisionAhead.MSG_TYPE:
                message_rx = CollisionAhead.Deserialize(msg)
                if message_rx.status == 1:
                    s_print(function_name, 'Collision FWD present')
                    cart.collision_fwd = True
                    if cart.get_dir() == FWD and cart.get_velo() > 0:
                        cart.set_velo(0)
                    gui_queue.put({'collision fwd': 'present'})

                elif message_rx.status == 2:
                    s_print(function_name, 'Collision FWD cleared')
                    cart.collision_fwd = False
                    if cart.get_dir() == FWD and cart.get_velo() == 0 and cart.ON_ROUTE == True:
                        cart.set_velo(1)
                    gui_queue.put({'collision fwd': 'clear'})

                elif message_rx.status == 3:
                    s_print(function_name, 'Collision BWD present')
                    if cart.get_dir() == BWD and cart.get_velo() > 0:
                        cart.set_velo(0)
                    cart.collision_bwd = True
                    gui_queue.put({'collision bwd': 'present'})

                elif message_rx.status == 4:
                    s_print(function_name, 'Collision BWD cleared')
                    cart.collision_bwd = False
                    if cart.get_dir() == BWD and cart.get_velo() == 0 and cart.ON_ROUTE == True:
                        cart.set_velo(1)
                    gui_queue.put({'collision bwd': 'clear'})

                message_tx = CollisionAheadResp(1)
                message_tx_bytes = buildMessage(message_tx, cart_name)
                socket.send(message_tx_bytes)

            header = None
            msg_port = 0
            msg_type = 0
            msg_len = 0
            msg = None
            header_ok = False

    return header_ok, header

def headerParser(function_name, header_bytes):
    function_name = Fore.LIGHTCYAN_EX+"headerParser:"+Fore.RESET
    length, payload_type, cart_id = struct.unpack('>BIH', header_bytes)
    length -= 7
    return length, payload_type, cart_id

def getIP():
    import socket
    hostname = socket.gethostname()
    ip_address = socket.gethostbyname(hostname)
    ip_address_array = ip_address.split('.')
    ip_address_array_int = []
    for i, value in enumerate(ip_address_array):
        ip_address_array_int.append(int(value))
    
    return tuple(ip_address_array_int)
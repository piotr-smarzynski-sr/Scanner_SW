#------------------ IMPORTS BEGIN -----------------------------
import socket
from threading import Thread
import struct
import sys
from sys import argv

# local imports
from time import sleep
#------------------ IMPORTS END-- -----------------------------
SERVER_IP_ADDRESS = '192.168.130.51'

if '-t' in argv:
    i = argv.index('-t')
    THREADS_COUNT = argv[i+1]
    print('THREADS_COUNT: ', THREADS_COUNT)
else:
    THREADS_COUNT = 25
THREADS_COUNT = int(THREADS_COUNT)

class Timer(object):
    """
    class with simple timer functionality

    Methods:
        fromStart: Time in seconds from object creation or from last reset
        reset: set timer start from now
        waitFor: block execution for specified anmount of seconds
    """
    def __init__(self):
        from time import time as now
        self.start_time = now()

    def fromStart(self):
        """
        Returns time in seconds from start or last reset.

        Args:
            None

        Returns:
            time_from_start: float

        Raises:
            None
        """
        from time import time as now
        return now() - self.start_time

    def reset(self):
        """
        Set timer start to now.

        Args:
            None

        Returns:
            None

        Raises:
            None
        """
        from time import time as now
        self.start_time = now()

    def waitFor(self, time_wait):
        """
        Block code execution for specified time.

        Args:
            time_wait: float
                Time in seconds to wait

        Returns:
            None

        Raises:
            None
        """
        wait_end = self.fromStart() + time_wait
        while self.fromStart() < wait_end:
            pass

class cartInfoUDP(object):
    def __init__(self, cart_id, direction, speed, track_num, track_offset, status, alarm):
        self.MSG_TYPE = 0
        self.cart_id = cart_id
        self.direction = direction
        self.speed = speed
        self.track_num = track_num
        self.track_offset = track_offset
        self.status = status
        self.alarm = alarm

    def __str__(self):
        output = 'MSG_TYPE: '
        output += str(self.MSG_TYPE)
        output += '\ncart_id: '
        output += str(self.cart_id)
        output += '\ndirection: '
        output += str(self.direction)
        output += '\nspeed: '
        output += str(self.speed)
        output += '\ntrack_num: '
        output += str(self.track_num)
        output += '\ntrack_offset: '
        output += str(self.track_offset)
        output += '\nstatus: '
        output += str(self.status)
        output += '\nalarm: '
        output += str(self.alarm)
        return output

    def serialize(self):
        return struct.pack('>BHBBHHHI', self.MSG_TYPE, self.cart_id, self.direction, self.speed, self.track_num, self.track_offset, self.status, self.alarm)

    @staticmethod
    def Deserialize(payload_bytes):
        MSG_TYPE, cart_id, direction, speed, track_num, track_offset, status, alarm = struct.unpack('>BHBBHHHI', payload_bytes)
        return cartInfoUDP(cart_id, direction, speed, track_num, track_offset, status, alarm)

def transmit_data2(IP_ADDRESS, TX_PORT, payload):
    socket_transmit = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    socket_transmit.sendto(payload, (IP_ADDRESS, TX_PORT))
    socket_transmit.close()

def udpSender():
    t1 = Timer()
    while True:
        if t1.fromStart() > 0.1:
            t1.reset()
            message_tx = cartInfoUDP(15, 1, 12, 0, 36, 1, 0)
            message_tx_bytes = message_tx.serialize()
            transmit_data2(SERVER_IP_ADDRESS, 60000, message_tx_bytes)

threads = []

for _ in range(THREADS_COUNT):
    threads.append(Thread(target=udpSender,
                        name='udpSender',
                        kwargs={},
                        daemon=True))

for thread in threads:
    thread.start()

print(THREADS_COUNT, 'threads started')

t2 = Timer()
try:
# --------------- MAIN LOOP -------------------
    while True:
        print("I'm alive,", round(t2.fromStart(), 2))
        sleep(5)

# ------------- CLOSING APP AND WRAPUP
except KeyboardInterrupt:
    running = False
    print("\n"+ "Exiting via CTRL + C")
    print('Program end.')
    sys.exit(0)
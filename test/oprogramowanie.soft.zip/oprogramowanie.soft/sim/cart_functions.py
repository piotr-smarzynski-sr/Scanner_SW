from classes import Cart, Track
from thread_print import s_print

STP_END_ON = True
STP_END_OFF = False
STP_BEGIN_ON = True
STP_BEGIN_OFF = False
PRV_CONN_BEGIN = True
PRV_CONN_END = False
NEXT_CONN_BEGIN = True
NEXT_CONN_END = False
IS_STATION = True
NOT_STATION = False
IS_CROSSROAD = True
NOT_CROSSROAD = False

FWD = 1
BWD = -1

def move_cart(track_system_actual, cart_system, cart_no, now):
    #TODO:
    # rozróżnienie kierunku jazdy wózka z kierunkiem jazdy po torze
    # if cart_system[cart_no].track_actual.name in cart_system[cart_no].route:
    #     find_track(future_track, track_system_actual)

    # if track is not station and not crossroad
    if cart_system[cart_no].track_actual != None:
        if cart_system[cart_no].track_actual.is_station == NOT_STATION and cart_system[cart_no].track_actual.is_crossroad == NOT_CROSSROAD:
            # if cart reached begin or end of track
            if cart_system[cart_no].get_pos_mm() > cart_system[cart_no].track_actual.length_mm or cart_system[cart_no].get_pos_mm() < 0:
                future_dir = 0
                future_track = None
                future_track_index = None
                start_pos = None
                # if cart reached end of track
                if cart_system[cart_no].get_pos_mm() > cart_system[cart_no].track_actual.length_mm:
                    # if there are stopper at end
                    if cart_system[cart_no].track_actual.stopper_end == True:
                        # reverse direction
                        if cart_system[cart_no].direction == FWD:
                            future_dir = BWD
                        elif cart_system[cart_no].direction == BWD:
                            future_dir = FWD
                        # future_dir = cart_system[cart_no].get_dir()*(-1)
                        # track remains the same
                        future_track = cart_system[cart_no].track_actual_no
                        # starting from end of track
                        start_pos = cart_system[cart_no].track_actual.length_mm
                    # if there are no stopper at end
                    if cart_system[cart_no].track_actual.stopper_end == False:
                        # track set to next according to map
                        future_track = cart_system[cart_no].track_actual.next_track
                        future_track_index = cart_system[cart_no].track_actual.next_track_all.index(cart_system[cart_no].track_actual.next_track)
                        # if next track connects with begin
                        if cart_system[cart_no].track_actual.next_track_connects_with_start[future_track_index] == True:
                            # set direction to forward
                            future_dir =  FWD
                            # starting from begin of track
                            start_pos = 0
                        # if next track connects with end    
                        if cart_system[cart_no].track_actual.next_track_connects_with_start[future_track_index] == False:
                            # set direction to backward
                            future_dir =  BWD
                            # starting from end of track
                            start_pos = track_system_actual[future_track].length_mm

                # if cart reached begin of track
                if cart_system[cart_no].get_pos_mm() < 0:
                    # if there are stopper at begin
                    if cart_system[cart_no].track_actual.stopper_start == True:
                        # reverse direction
                        if cart_system[cart_no].direction == FWD:
                            future_dir = BWD
                        elif cart_system[cart_no].direction == BWD:
                            future_dir = FWD
                        # future_dir = cart_system[cart_no].get_dir()*(-1)
                        # track remains the same
                        future_track = cart_system[cart_no].track_actual_no
                        # starting from begin of track
                        start_pos = 0
                    # if there are no stopper at begin
                    if cart_system[cart_no].track_actual.stopper_start == False:
                        # track set to previous according to map
                        future_track = cart_system[cart_no].track_actual.prev_track
                        future_track_index = cart_system[cart_no].track_actual.prev_track_all.index(cart_system[cart_no].track_actual.prev_track)
                        # if previous track connects with start 
                        if cart_system[cart_no].track_actual.prev_track_connects_with_start[future_track_index] == True:
                            # set direction to forward
                            future_dir =  FWD
                            # starting from begin of track
                            start_pos = 0
                        # if previous track connects with end
                        if cart_system[cart_no].track_actual.prev_track_connects_with_start[future_track_index] == False:
                            # set direction to backward
                            future_dir =  BWD
                            # starting from end of track
                            start_pos = track_system_actual[find_track(future_track, track_system_actual)].length_mm

                # remove cart from track info
                track_system_actual[find_track(cart_system[cart_no].track_actual_no, track_system_actual)].delete_cart(cart_system[cart_no].get_name())
                # save last track in cart info
                cart_system[cart_no].track_last_no = cart_system[cart_no].track_actual_no
                # set new track in cart
                # cart_system[cart_no].track_actual_no = future_track
                if len(cart_system[cart_no].route_prev) > 9:
                    cart_system[cart_no].route_prev.pop(0)
                cart_system[cart_no].route_prev.append(cart_system[cart_no].track_actual_no)
                # cart_system[cart_no].track_actual = track_system_actual[future_track]

                # if track changes
                if cart_system[cart_no].track_actual.name != future_track:
                    #set cart to new track
                    cart_system[cart_no].track_actual = track_system_actual[find_track(future_track, track_system_actual)]
                    cart_system[cart_no].track_actual_no = track_system_actual[find_track(future_track, track_system_actual)].name
                    # cart_system[cart_no].track_actual_no = track_system_actual[find_track(future_track, track_system_actual)].no
                    if len(track_system_actual[find_track(future_track, track_system_actual)].carts) >= track_system_actual[find_track(future_track, track_system_actual)].max_carts and cart_system[cart_no].get_name():
                        cart_system[cart_no].set_velo(0)
                    else:
                        if cart_system[cart_no].get_velo() > cart_system[cart_no].track_actual.max_speed:
                            s_print('limit to track max speed')
                            cart_system[cart_no].set_velo(cart_system[cart_no].track_actual.max_speed)

                cart_system[cart_no].pos_branch_mm = start_pos
                cart_system[cart_no].set_dir(future_dir)
                cart_system[cart_no].direction_last = cart_system[cart_no].get_dir()

                #--------------------- CROSSROADS -------------------------
                # if cart_no == 0 and cart_system[cart_no].track_actual_no == "T2" and cart_system[cart_no].direction == FWD and cart_system[cart_no].track_actual.next_track != "T3":
                #     track_system_actual[find_track("T2", track_system_actual)].update_crossroad("T3", 0)
                # if cart_no == 0 and cart_system[cart_no].track_actual_no == "T4" and cart_system[cart_no].direction == FWD and cart_system[cart_no].track_actual.next_track != "T9":
                #     track_system_actual[find_track("T4", track_system_actual)].update_crossroad("T9", 0)
                # if cart_no == 0 and cart_system[cart_no].track_actual_no == "T10" and cart_system[cart_no].direction == FWD and cart_system[cart_no].track_actual.prev_track != "T11":
                #     track_system_actual[find_track("T10", track_system_actual)].update_crossroad("T11", 0)


        if cart_system[cart_no].track_actual.is_station == IS_STATION and cart_system[cart_no].track_actual.is_crossroad == NOT_CROSSROAD:
            s_print("TODO")

        if cart_system[cart_no].track_actual.is_station == NOT_STATION and cart_system[cart_no].track_actual.is_crossroad == IS_CROSSROAD:
            if cart_system[cart_no].track_actual.get_crossroad_setting() != 0:
                s_print("TODO")

def find_track(track_name, track_set):
    for index, item in enumerate(track_set):
        if item.name == track_name:
            return index
    return 9999
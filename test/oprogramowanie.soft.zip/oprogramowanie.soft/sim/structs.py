import struct
from msg.messages import buildMessage
from thread_print import s_print

class cartInfoUDP(object):
    def __init__(self, cart_id, direction, speed, track_num, track_offset, status, alarm):
        self.MSG_TYPE = 0
        self.cart_id = cart_id
        self.direction = direction
        self.speed = speed
        self.track_num = track_num
        self.track_offset = track_offset
        self.status = status
        self.alarm = alarm

    def __str__(self):
        output = 'MSG_TYPE: '
        output += str(self.MSG_TYPE)
        output += '\ncart_id: '
        output += str(self.cart_id)
        output += '\ndirection: '
        output += str(self.direction)
        output += '\nspeed: '
        output += str(self.speed)
        output += '\ntrack_num: '
        output += str(self.track_num)
        output += '\ntrack_offset: '
        output += str(self.track_offset)
        output += '\nstatus: '
        output += str(self.status)
        output += '\nalarm: '
        output += str(self.alarm)
        return output

    def serialize(self):
        if self.track_offset < 0:
            self.track_offset = 0
        return struct.pack('>BHBBHHHI', self.MSG_TYPE, self.cart_id, self.direction, self.speed, self.track_num, self.track_offset, self.status, self.alarm)

    @staticmethod
    def Deserialize(payload_bytes):
        MSG_TYPE, cart_id, direction, speed, track_num, track_offset, status, alarm = struct.unpack('>BHBBHHHI', payload_bytes)
        return cartInfoUDP(cart_id, direction, speed, track_num, track_offset, status, alarm)

def testCode():
    message_tx = cartInfoUDP(96, 2, 7, 3, 25, 7, 0)
    s_print('message_tx: ', message_tx)
    message_tx_bytes = message_tx.serialize()

    s_print()
    message_rx_bytes = message_tx_bytes
    message_rx = cartInfoUDP.Deserialize(message_rx_bytes)
    s_print('message_rx: ', message_rx)

# testCode()
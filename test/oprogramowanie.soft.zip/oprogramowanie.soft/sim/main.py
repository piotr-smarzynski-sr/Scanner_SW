#------------------ EXTERNAL IMPORTS BEGIN --------------------
#------------------ EXTERNAL IMPORTS END ----------------------
#------------------ IMPORTS BEGIN -----------------------------
import argparse
import keyboard
from sys import exit
from time import time as now
from time import sleep as sleep
from threading import Thread
import socket
from queue import Queue
from colorama import init, Fore
from uuid import getnode as get_mac

# local imports
# from alarms import Alarms
from thread_print import s_print
from thread_print import getHour
import struct
import mqtt_communication
import other
from other import Timer
import gui2
from classes import Track, Cart, Graph
from cart_functions import move_cart, find_track
import hotkeys_functions
import structs
import udp_communication
from tcp_communication import tcpReceiveHeader, tcpReceiveMessage
from msg.communication_payloads import CartConnStatus, CartConnStatusResp, CartHello, CartHelloResp, GetIP, GetIPResp
from msg.travel_payloads import GoTo, GoToResp, RouteDone, RouteDoneResp
from msg.messages import buildMessage, parseMessage
#------------------ IMPORTS END-- -----------------------------

#------------------ RUN ARGUMENTS HANDLE BEGIN ----------------
parser = argparse.ArgumentParser()
parser.add_argument("-c", "--cart",
                    help='Set cart ID. If not exists, cart ID is 96',
                    type=int)

parser.add_argument("-p", "--port",
                    help='Set cart UDP receiving port. If not exists, port is 60001',
                    type=int)

parser.add_argument('-u' ,"--udp_refresh_time",
                    help='Time in seconds between refreshing cyclic UDP data. If not exists, time is 0.1s',
                    type=float)

parser.add_argument('-s' ,"--server_ip",
                    help="Server IP address. If not exists, ip is 'localhost'")

parser.add_argument("-ml", "--mqtt_log", # no need to give short name, full is not optional
                    help='Set MQTT logging. (not used)',
                    action="store_true")

parser.add_argument("-md", "--mqtt_debug",
                    help='Set MQTT debug printing. (not used)',
                    action="store_true")

args = parser.parse_args()
if args.cart:       # name corresponds full name given in string argument
    Cart_name = args.cart
else:
    Cart_name = 96

if args.port:
    RX_PORT = args.port
else:
    RX_PORT = 60001

if args.server_ip:
    SERVER_IP = args.server_ip
else:
    SERVER_IP = 'localhost'

if args.udp_refresh_time:
    data_refresh_time = args.udp_refresh_time
else:
    data_refresh_time = 0.1

if args.mqtt_log:
    s_print('MQTT logging:', args.mqtt_log)
else:
    pass

if args.mqtt_debug:
    s_print('MQTT debug:', args.mqtt_debug)
else:
    pass

#------------------ RUN ARGUMENTS HANDLE END ------------------

#------------------ FUNCTION DEFINITION BEGIN -----------------
# def print_cart_pos(cart_no):
    # s_print("Pos ",
    #         cart_system[cart_no].get_name(),
    #         cart_system[cart_no].track_actual.name,
    #         '{0:.2f}'.format(cart_system[cart_no].get_pos_mm()),
    #         '{0:.2f}'.format(cart_system[cart_no].get_velo()) )

#------------------ FUNCTION DEFINITION END -------------------
#------------------ CLASS DEFINITIONS -------------------


#------------------ GLOBAL VARIABLES BEGIN --------------------

init(convert=True) #COLORAMA
'''
allowed colors:
YELLOW
LIGHTCYAN_EX
LIGHTRED_EX
LIGHTGREEN_EX
'''

UDP_ENABLED = True
SOFTWARE_VERSION = '1.02'
HEADERSIZE = 7

OBSTACLE_FRONT = False
OBSTACLE_BACK = False
EMERGENCY_STOP = False
SAFETY_OK = True
running = True

TX_PORT = 60000
FWD = 1
BWD = -1

FLAG_ON_ROUTE = False
DESTINATION = -1
# ALARMS = 0x0
# alarms = Alarms('C', Cart_name)

mac_address = get_mac()
mac_address_packed = struct.pack('6s', mac_address.to_bytes(6, 'little'))


socket_udp_receive = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
while (1):
    try:
        socket_udp_receive.bind((SERVER_IP, RX_PORT))
        s_print("UDP port receive", RX_PORT)
        break
    except:
        s_print("UDP port", RX_PORT, 'occupied, trying next one')
        RX_PORT += 1
        sleep(0.1)

timer_last_pos_update = 0.0
timer_last_pos_print = 0.0
timer_last_station_wait = 0.0

# if zero then code not works
CART_INFO_DELAY_FROM_START = 2.0

# Track(name, length_mm, stopper_start, stopper_end, prev_track, next_track, prev_track_connects_with_start, next_track_connects_with_start):
STP_END_ON = True
STP_END_OFF = False
STP_BEGIN_ON = True
STP_BEGIN_OFF = False
PRV_CONN_BEGIN = True
PRV_CONN_END = False
NEXT_CONN_BEGIN = True
NEXT_CONN_END = False
IS_STATION = True
NOT_STATION = False
IS_CROSSROAD = True
NOT_CROSSROAD = False

cart_system = []
track_system = []
track_system_actual = []
time_program_start = now()
tcp_queue = Queue()
gui_queue = Queue()


hotkeys_dict = {
    'set obstacle in back'      : 'shift+b+1',
    'set obstacle in front'     : 'shift+b+2',
    'reset obstacle in back'    : 'shift+b+3',
    'reset obstacle in front'   : 'shift+b+4',
    'print cart_pos'            : 'shift+c+1',
    'Set velo to 1'             : 'shift+v+1',
    'Set velo to 10'            : 'shift+v+2',
    'Set velo to 0'             : 'shift+v+0',
    'Q route done'              : 'shift+q+1',
    'hotkey_list'               : 'shift+h',
    'set alarm 0'               : 'shift+a+0',
    'set alarm 1'               : 'shift+a+1',
    'set alarm 2'               : 'shift+a+2',
    'set alarm 3'               : 'shift+a+3',
    'set alarm 4'               : 'shift+a+4',
    'set alarm 5'               : 'shift+a+5',
    'set alarm 6'               : 'shift+a+6',
    'set alarm 7'               : 'shift+a+7'
}

#------------------ GLOBAL VARIABLES END ----------------------
#------------------ FUNCTIONS BEGIN ---------------------------

# def headerParser(header):
#     function_name = Fore.LIGHTCYAN_EX+"headerParser:"+Fore.RESET
#     msg_port = int.from_bytes(header[:2], 'big')
#     msg_type = int.from_bytes(header[2:4], 'big')
#     msg_len = int.from_bytes(header[4:], 'big')
#     return msg_port, msg_type, msg_len

def headerParser(function_name, header_bytes):
    function_name = Fore.LIGHTCYAN_EX+"headerParser:"+Fore.RESET
    length, payload_type, cart_id = struct.unpack('>BIH', header_bytes)
    length -= 7
    return length, payload_type, cart_id

def macAddress():
    mac_address_list = struct.unpack("8B", struct.pack("Q", get_mac()))
    mac_address_list = mac_address_list[:6]
    mac_address_list = mac_address_list[::-1]
    return tuple(mac_address_list)

def macAddress2():
    if Cart_name > 1 and Cart_name < 255:
        return (252, 119, 116, 101, 200, Cart_name)

def subCartControllerHello(socket, cart_no):
    # message_tx = CartConnStatus(1)
    message_tx = CartConnStatusResp(1)
    message_tx_bytes = buildMessage(message_tx, cart_no)
    socket.send(message_tx_bytes)

#------------------ THREAD DEFINITION BEGIN -------------------
def safety_thread(running, carts):
    sleep(1)
    while running == True:
        global SAFETY_OK
        global EMERGENCY_STOP
        global OBSTACLE_BACK
        global OBSTACLE_FRONT
        obstacles = [OBSTACLE_BACK, OBSTACLE_FRONT]
        safety_last = SAFETY_OK
        emg_stop_last = EMERGENCY_STOP
        obstacles_safety = False
        for obstacle in obstacles:
            if obstacle == False:
                obstacles_safety = True
            else:
                obstacles_safety = False
                break

        # SAFETY_OK = not OBSTACLE_BACK and not OBSTACLE_FRONT
        SAFETY_OK = obstacles_safety
        EMERGENCY_STOP = not SAFETY_OK
        if safety_last != SAFETY_OK:
            if SAFETY_OK:
                s_print(Fore.LIGHTGREEN_EX, 'SAFETY CIRCUIT OK', Fore.RESET)
            else:
                s_print(Fore.RED, 'SAFETY CIRCUIT NG', Fore.RESET)

        if emg_stop_last != EMERGENCY_STOP:
            if EMERGENCY_STOP:
                s_print(Fore.RED, 'EMERGENCY STOP', Fore.RESET)

        if EMERGENCY_STOP:
            carts[0].set_velo(0)

        sleep(0.01)

def time_thread_print_pos():
    global print_cart_pos
    loop_counter = 0
    while running == True:
        sleep(1)
        if print_cart_pos:
            if now() - time_program_start > CART_INFO_DELAY_FROM_START:
                for cart in cart_system:
                    s_print(loop_counter,'.', Fore.YELLOW, cart.print_info(), OBSTACLE_BACK, OBSTACLE_FRONT, Fore.RESET)
        loop_counter += 1

def time_thread_carts_on_tracks():
    while running == True:
        sleep(0.1)
        if now() - time_program_start > CART_INFO_DELAY_FROM_START:
            move_cart(track_system_actual, cart_system, 0, now())

def time_thread_update_position():
    while running == True:
        sleep(0.1)
        for cart in cart_system:
            cart.update_pos_branch_mm()
            cart.update_total_distance_mm()
            track_index = find_track(cart.track_actual_no, track_system_actual)
            track_system_actual[track_index].update_cart(cart.name)
            track = track_system_actual[track_index]
            cart.update_track(track)

def speedMonitor(running, carts):
    function_name = Fore.YELLOW+' speedMonitor: '+Fore.RESET
    sleep(3)
    cart = carts[0]
    velocity_last = 0
    velocity_actual = 0
    while running == True:
        velocity_actual = cart.get_velo()
        gui2.queue_input.put({
                    'cart_no': cart.name,
                    'dir': cart.get_dir(),
                    'velo': velocity_actual,
                    'on_route': cart.ON_ROUTE,
                    'destination': cart.DESTINATION,
                    'track': cart.track_actual_no,
                    'position': cart.get_pos_mm(),
                    'alarms': cart.alarms
        })

        if velocity_actual == 0 and velocity_last != 0 and cart.ON_ROUTE == True:
            s_print(function_name, 'Cart ', cart.name, 'stopped on route to', cart.DESTINATION)

        if velocity_actual != 0 and velocity_last == 0 and cart.ON_ROUTE == True:
            s_print(function_name, 'Cart ', cart.name, 'started on route to', cart.DESTINATION)

        velocity_last = velocity_actual
        if gui2.queue_output.empty() == False:
            queue_element = gui2.queue_output.get()
            if 'velo' in queue_element:
                cart.set_velo(queue_element['velo'])

            if 'dir' in queue_element:
                cart.set_dir(queue_element['dir'])

            if 'track_set' in queue_element:
                cart_system[0].track_actual_no = queue_element['track_set']

            if 'route done' in queue_element:
                tcp_queue.put('Route done')

            if 'alarm_set' in queue_element:
                cart_system[0].alarms.setAlarm(queue_element['alarm_set'])
                s_print('Alarm', queue_element['alarm_set'], ':', cart_system[0].alarms.getAlarm(queue_element['alarm_set']))

            if 'alarm_reset' in queue_element:
                cart_system[0].alarms.resetAlarm(queue_element['alarm_reset'])
                s_print('Alarm', queue_element['alarm_reset'], ':', cart_system[0].alarms.getAlarm(queue_element['alarm_reset']))

        sleep(0.3)



def TCPCommunication(cart_name, queue_input):
    function_name = Fore.LIGHTCYAN_EX+"TCPCommunication:"+Fore.RESET
    '''
    message types:
    99: server->cart con?
    0: server->cart move command
    1: server->cart "Connected to server"
    2: server<-cart "Got route"
    3: server<-cart "Route done"
    4: server<-cart "Obstacle"
    5: server->cart "STOP"
    '''
    port = 50000
    header = b''
    header_buffer = b''
    message_buffer = b''
    time_tcp_start = now()
    ROUTE_DONE_FLAG = False

    while(1):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        while (1):
            try:
                s.connect((SERVER_IP, port))
                # s.connect(('192.168.130.46', port))
                s_print(function_name, Fore.LIGHTGREEN_EX, "TCP port", port, 'conected!', Fore.RESET)
                break
            except:
                s_print(function_name, Fore.YELLOW, "TCP port", port, 'not available, next try', Fore.RESET)
                sleep(2)

        # s_print(Fore.LIGHTGREEN_EX,'mac_address: ', macAddress(), Fore.RESET)
        s_print(Fore.LIGHTGREEN_EX,'mac_address: ', macAddress2(), Fore.RESET)
        s.setblocking(True)
        rx_port_tcp = 54321
        header_ok = False
        delayed_answer = False
        timer_route_acquired = now()
        timer_cyclic_msg = now()
        counter_cyclic_msg = 0
        message_prepared = False

        msg_type = CartHello.MSG_TYPE
        # command_to_server = CartHello(macAddress())
        command_to_server = CartHello(macAddress2())
        s_print(function_name, 'Init MAC message:: ', command_to_server.mac_address)
        msg = buildMessage(command_to_server, cart_name)
        # s.send(msg)
        # header = s.recv(7)
        # length, payload_type, cart_id = headerParser(function_name, header)
        # if payload_type == CartHelloResp.MSG_TYPE:
        #     message_rx_bytes = s.recv(length)
        #     message_rx = CartHelloResp.Deserialize(message_rx_bytes)
        message_prepared = True
        s.setblocking(False)
        while True:
            if queue_input.empty() == False:
                queue_element = queue_input.get()
                if 'Route done' in queue_element:
                    ROUTE_DONE_FLAG = True
                    msg_type = RouteDone.MSG_TYPE
                    message_tx = RouteDone(1)
                    msg = buildMessage(message_tx, cart_name)
                    s_print(function_name, getHour(), 'Route done: ', message_tx.status)
                    message_prepared = True

            #-------------- TCP SEND ---------------
            if message_prepared:
                try:
                    if ROUTE_DONE_FLAG == True:
                        print(function_name, getHour(),  'Route done sending')
                    s.send(msg)
                    if ROUTE_DONE_FLAG == True:
                        print(function_name, getHour(),  'Route done sent')
                        ROUTE_DONE_FLAG = False
                    message_prepared = False
                except:
                    s_print(function_name, 'TCP send failed, type ', msg_type)
                    break

            #-------------- TCP RECEIVE & HANDLE---------------
            if header_ok == False:
                header, header_buffer, message_buffer, header_ok = tcpReceiveHeader(function_name, s, header, header_buffer, message_buffer, header_ok, HEADERSIZE)

            if header_ok:
                try:
                    s.setblocking(True)
                    header_ok, header = tcpReceiveMessage(function_name, cart_system[0], cart_name, s, header, header_ok, message_buffer, rx_port_tcp, HEADERSIZE)
                except:
                    break

            if now() - timer_cyclic_msg > 5:
                timer_cyclic_msg = now()
                try:
                    subCartControllerHello(s, cart_name)
                except:
                    break

        s_print(function_name, Fore.RED, 'Loop break!', Fore.RESET)
        s.close()

# -------------- THREAD DEFINITION END ---------------------

# -------------- MQTT ------------------------
mqtt_clients = []
# # DO NOT CREATE CLIENTS WITH NAMES : sub_00
# mqtt_clients.append(
#     (mqtt_communication.createClient('sub_cart_C0', sub_topic='cart_C1', DEBUG=True), 'sub_cart_C0'))
# mqtt_clients.append(
#     (mqtt_communication.createClient('carts2main', DEBUG=True), 'pub_cart_00'))

# subscribe_topic = 'cart_'+Cart_name
# s_print('subscribe_topic: ', subscribe_topic)
# mqtt_clients.append(mqtt_communication.createClient('sub_cart_'+Cart_name, sub_topic= subscribe_topic, DEBUG = False))
# mqtt_clients.append(mqtt_communication.createClient('pub', DEBUG = False))


#------------------ THREADS ENABLE BEGIN ----------------------
threads = []
threads.append(Thread(target=safety_thread,
                        name="safety_thread",
                        kwargs={'running':running,
                                'carts':cart_system},
                        daemon=True))

threads.append(Thread(target=gui2.gui,
                        name="gui",
                        kwargs={},
                        daemon=True))

threads.append(Thread(target=time_thread_update_position,
                        name="time_thread_update_position",
                        kwargs={},
                        daemon=True))

threads.append(Thread(target=speedMonitor,
                        name="speedMonitor",
                        kwargs={'running':running,
                                'carts':cart_system},
                        daemon=True))

threads.append(Thread(target=time_thread_print_pos,
                        name="time_thread_print_pos",
                        kwargs={},
                        daemon=True))

threads.append(Thread(target=time_thread_carts_on_tracks,
                        name="time_thread_carts_on_tracks",
                        kwargs={},
                        daemon=True))

threads.append(Thread(target=TCPCommunication,
                        name="TCPCommunication",
                        kwargs={'cart_name':Cart_name,
                        'queue_input': tcp_queue},
                        daemon=True))

if len(threads) > 0:
    for thread in threads:
        thread.start()
        s_print("Starting thread ", thread.getName())
        s_print('Thread ', thread.getName(), ' is alive: ', thread.is_alive())
#------------------ THREADS ENABLE END -------------------------

#------------------ SINGLE RUN BEGIN ---------------------------
track_system.append(Track("T0", 0, 40, STP_BEGIN_ON, STP_END_OFF, "T5", ["T5"], "T1", ["T1"], [PRV_CONN_END], [NEXT_CONN_BEGIN], NOT_STATION, NOT_CROSSROAD, 3, 1))
track_system.append(Track("T1", 1, 40, STP_BEGIN_OFF, STP_END_OFF, "T0", ["T0"], "T2", ["T2"], [PRV_CONN_END], [NEXT_CONN_BEGIN], NOT_STATION, NOT_CROSSROAD, 3, 1))
track_system.append(Track("T2", 2, 30, STP_BEGIN_OFF, STP_END_OFF, "T1", ["T1"], "T3", ["T3"], [PRV_CONN_END], [NEXT_CONN_BEGIN], NOT_STATION, NOT_CROSSROAD, 3, 1))
track_system.append(Track("T3", 3, 30, STP_BEGIN_OFF, STP_END_OFF, "T2", ["T2"], "T4", ["T4"], [PRV_CONN_END], [NEXT_CONN_BEGIN], NOT_STATION, NOT_CROSSROAD, 3, 1))
track_system.append(Track("T4", 4, 40, STP_BEGIN_OFF, STP_END_OFF, "T3", ["T3"],  "T5", ["T5"], [PRV_CONN_END], [NEXT_CONN_BEGIN], NOT_STATION, NOT_CROSSROAD, 3, 1))
track_system.append(Track("T5", 5, 50, STP_BEGIN_OFF, STP_END_ON, "T4", ["T4"], "T0", ["T0"], [PRV_CONN_END], [NEXT_CONN_BEGIN], NOT_STATION, NOT_CROSSROAD, 3, 1))
track_system_actual = track_system
# ONLY ONE CART
cart_system.append(Cart(Cart_name))
cart_system[0].set_velo(0)
cart_system[0].track_actual_no = "T0"
# data_rx = structs.Frame_to_Cart('F1')
# data_tx = structs.Frame_to_Cart('F2')
s_print("Simulation start")
keyboard_check_time = now()
mqtt_parse_time = now()
sleep(0.2)
data_send_time = now()
timer_data_refresh = Timer()
timer1 = Timer()
outcoming_messages_speed = 0
mqtt_send_counter = 0
mqtt_communication.MQTT_DEBUG = True
print_cart_pos = False
other.print_dict(hotkeys_dict, prefix = '# HOTKEYS #', suffix  = '-----------------')
#------------------ SINGLE RUN END -----------------------------

#------------------ MAIN LOOP ----------------------------------
DEBUG = False
try:
    while True:
        if timer_data_refresh.fromStart() > data_refresh_time:
            timer_data_refresh.reset()
            outcoming_messages_speed += 1
            if timer1.fromStart() > 1:
                timer1.reset()
                # s_print('outcoming_messages_speed: ', outcoming_messages_speed)
                outcoming_messages_speed = 0

            data_send_time = now()
            dir_actual = cart_system[0].get_dir()
            dir_to_send = 0
            if dir_actual == -1:
                dir_to_send = 2
            else:
                dir_to_send = dir_actual

            message_tx = structs.cartInfoUDP(Cart_name,
                                            dir_to_send,
                                            int(cart_system[0].get_velo()*10),
                                            cart_system[0].track_actual.no,
                                            cart_system[0].get_pos_mm(),
                                            1,
                                            cart_system[0].alarms.alarms)

            message_tx_bytes = message_tx.serialize()
            udp_communication.transmit_data2('localhost', 60000, message_tx_bytes)

#------------------- END OPERATIONS BEGIN ----------------------
except KeyboardInterrupt:
    running = False
    s_print("Exiting via CTRL + C")
    s_print(Fore.RESET + 'Program end.')
    exit(0)
#------------------- END OPERATIONS END ------------------------
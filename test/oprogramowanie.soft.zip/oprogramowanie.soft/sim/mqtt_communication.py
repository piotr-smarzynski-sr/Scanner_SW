import paho.mqtt.client as paho
import random as r
import string
import base64
from time import sleep
from time import time as now
from struct import pack
from thread_print import s_print

import other
import structs

"""
TODO
Same encryption and usage as in db_communication
add user and password in MQTT
poszukać komend sterujących do MQTT
"""
# BROKER = "192.168.130.43"
# BROKER = 'test.mosquitto.org'

class MQTTConnect():
    def __init__(self):
        self.BROKER = 'localhost'
        self.PORT = 1883


LOGGING = False
MQTT_DEBUG = False
MQTT_DEBUG_LEVEL = 0

class newClient(paho.Client):
    def __init__(self, name):
        paho.Client.__init__(self, client_id =name)
        self.ACTUAL_MESSAGE = ''
        self.LAST_MESSAGE = ''
        self.connection = MQTTConnect()


def on_message_subscribed(client, userdata, message):

    RECEIVED_RAW = message.payload
    message_b85_decoded = base64.b85decode(message.payload)
    # message_b85_decoded = base64.b64decode(RECEIVED_RAW)
    client.LAST_MESSAGE = client.ACTUAL_MESSAGE
    client.ACTUAL_MESSAGE = message_b85_decoded

    if MQTT_DEBUG and False:
        s_print('RECEIVED_RAW: ', RECEIVED_RAW,
         '\tLength(raw): ', len(RECEIVED_RAW),
         '\tLength(decoded): ', len(message_b85_decoded),
         '\tOverhead: ', round((len(RECEIVED_RAW)/len(message_b85_decoded)), 2))
        s_print('message_b85_decoded: ', message_b85_decoded)

    # split_message(message_b85_decoded, DEBUG=MQTT_DEBUG)



def on_log(client, userdata, level, buf):
    if LOGGING and MQTT_DEBUG_LEVEL >= 1:
        s_print("log: ",buf, userdata, level)

def on_connect(client, userdata, flags, rc):
    if rc != 0:
        s_print("Bad connection Returned code=",rc)
    else:
        # s_print('connected', userdata, flags, rc)
        pass


# def createClient(name=''):
#     if name == '':
#         name = other.randomString(5)
    
#     client.on_message = on_message_subscribed
#     client.on_log=on_log
#     client.on_connect = on_connect
#     client.connect(host=client.connection.BROKER, port=client.connection.PORT) 
#     sleep(2)
#     # client.loop_start()
#     # client.on_subscribe = on_message_subscribed
#     # client.connect_async(host=BROKER, port=PORT)
#     return client

def createClient(name_input, sub_topic='', DEBUG = False):
    
    if name_input == '':
        name_input = other.randomString(5)        
    client = newClient(name_input)
    client.on_message = on_message_subscribed
    client.on_log = on_log
    client.on_connect = on_connect
    # client.connect(BROKER, port=PORT)
    client.connect(host=client.connection.BROKER, port=client.connection.PORT)
    client.loop_start()
    if sub_topic != '':
        if DEBUG:
            s_print('Subscribed topic: ', sub_topic)
        subscribe(client, sub_topic, QoS=0, DEBUG = MQTT_DEBUG)
    if DEBUG:
        s_print('Created client: ', name_input)

    return client


def clientStop(client):
    client.disconnect()  # disconnect
    client.loop_stop()  # stop loop


def subscribe(client, topic, QoS=0, DEBUG = MQTT_DEBUG):
    # client.on_message = on_message_subscribed
    # # client.connect(host=BROKER, port=PORT)  # connect
    # client.connect(host=client.connection.BROKER, port=client.connection.PORT)  # connect
    # sleep(0.2)
    if DEBUG:
        s_print(client.is_connected)
    client.loop_start()
    sleep(0.2)
    client.subscribe(topic, qos=QoS)
    #     return True
    # else:
    #     return False

# def subscribe_loop(client):
#     while(1):
#         # client.connect(host=BROKER, port=PORT)  # connect
#         client.connect(host=client.connection.BROKER, port=client.connection.PORT)
#         client.on_message = on_message_subscribed
#         if client.is_connected:
#             client.loop_start()
#             ret = client.subscribe("#", qos=0)
#             sleep(0.00000001)
#             client.disconnect()  # disconnect
#             client.loop_stop()  # stop loop
#         else:
#             s_print("Client not connected")
#             sleep(1)


def unsubscribe(client, topic):
    client.unsubscribe(topic)


def publish(client, topic, message, QoS=0, DEBUG=MQTT_DEBUG):

    # client.connect(host=BROKER, port=PORT)  # connect
    client.connect(host=client.connection.BROKER, port=client.connection.PORT)
    if client.is_connected:
        client.loop_start()
        message_encoded = base64.b85encode(message)
        not_published_counter = 0
        loop_start_time = now()
        stucked = False
        while (1):
            ret = client.publish(topic=topic, payload=message_encoded, qos=QoS)
            sleep(0.00000001)
            if ret.is_published() == True:
                if not_published_counter > 0 and DEBUG:
                    s_print('Not published: ', not_published_counter)
                break
            else:
                not_published_counter += 1
                break
            if now() - loop_start_time > 1:
                s_print('Stuck in sending, not published ', not_published_counter)
                stucked = True
                # break
            ret = None

        client.disconnect()  # disconnect
        client.loop_stop()  # stop loop
        if DEBUG:
            s_print('MQTT Publish message encoded: ', message_encoded)
    else:
        s_print('Client not connected to broker')

    if ret.is_published() == True:
        client.LAST_MESSAGE = client.ACTUAL_MESSAGE
        client.ACTUAL_MESSAGE = message
        return True
    else:
        return False


def split_message(message, DEBUG = False):  
    if message[:4].decode().startswith('FR01'):
        save_message_to_frame(message, structs.frame_01, DEBUG)

    elif message[:4].decode().startswith('FR02'):
        save_message_to_frame(message, structs.frame_02, DEBUG)

    elif message[:4].decode().startswith('FR03'):
        save_message_to_frame(message, structs.frame_03, DEBUG)


def save_message_to_frame(message, frame, DEBUG = False):
    coursor_recv_mgs = 0
    splitted = []
    for localdict in frame:
        if localdict['type'] == 'h':
            converted = int.from_bytes(message[coursor_recv_mgs:coursor_recv_mgs+1], byteorder='big')
            splitted.append(converted)
            localdict['value'] = converted
            coursor_recv_mgs += 2
            
        if localdict['type'][-1] == 's':
            length = int(localdict['type'][: -1])
            converted = message[coursor_recv_mgs:coursor_recv_mgs+length]
            splitted.append(converted)
            coursor_recv_mgs += length

    localdict['value'] = converted

    if DEBUG == True and MQTT_DEBUG_LEVEL >= 0:
        s_print('splitted: ', splitted)


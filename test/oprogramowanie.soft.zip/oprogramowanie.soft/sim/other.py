from string import ascii_lowercase
import random as r
from thread_print import s_print

class Timer(object):
    """
    class with simple timer functionality

    Methods:
        fromStart: Time in seconds from object creation or from last reset
        reset: set timer start from now
        waitFor: block execution for specified anmount of seconds
    """
    def __init__(self):
        from time import time as now
        self.start_time = now()

    def fromStart(self):
        """
        Returns time in seconds from start or last reset.

        Args:
            None

        Returns:
            time_from_start: float

        Raises:
            None
        """
        from time import time as now
        return now() - self.start_time

    def reset(self):
        """
        Set timer start to now.

        Args:
            None

        Returns:
            None

        Raises:
            None
        """
        from time import time as now
        self.start_time = now()

    def waitFor(self, time_wait):
        """
        Block code execution for specified time.

        Args:
            time_wait: float
                Time in seconds to wait

        Returns:
            None

        Raises:
            None
        """
        wait_end = self.fromStart() + time_wait
        while self.fromStart() < wait_end:
            pass


def getFromQueue(queue_input):
    try:
        data = queue_input.get(False) # False jako argment: zamiast blokować, wywalamy wyjątek jak nie ma wiadomości w kolejce
        return True, data
    except: #except queue_input.Empty
        # print('EXCEPTION: Cannot get item from queue')
        return False, None

def print_dict(dictionary, prefix = None, suffix = None):
    longest = 0
    if len(dictionary) > 0:
        for key in dictionary:
            if len(key) > longest:
                longest = len(key)
        if prefix != None and isinstance(prefix, str):
            s_print(prefix)
        for key in dictionary:
            s_print(key, end='')
            for x in range(longest+5-len(key)):
                s_print(" ", end='')
            s_print(dictionary[key], "\n", end='')
        if suffix != None and isinstance(suffix, str):
            s_print(suffix)
    else:
        if prefix != None and isinstance(prefix, str):
            s_print(prefix, 'EMPTY DICT')
        else: 
            s_print('-------EMPTY DICT-------')
        s_print("{}")
        if suffix != None and isinstance(suffix, str):
            s_print(suffix)
        else: 
            s_print('-------EMPTY DICT-------')

def randomString(stringLength=10):
    """Generate a random string of fixed length """
    letters = ascii_lowercase
    return ''.join(r.choice(letters) for i in range(stringLength))

def str_list(list_input):
    """
    converts all elements from list to strings
    """
    list_output = []
    for element in list_input:
        if not isinstance(element, str):
            element = str(element)
        list_output.append(element)
    return list_output
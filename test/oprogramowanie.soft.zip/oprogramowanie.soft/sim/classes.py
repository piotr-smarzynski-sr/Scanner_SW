from collections import deque, namedtuple

from alarms import Alarms

FWD = 1
BWD = -1
inf = float('inf')
Edge = namedtuple('Edge', 'start, end, cost')

class Track:
    def __init__(self, name_input, no_input, length_mm_input, stopper_start_input, stopper_end_input, prev_track_input, prev_track_all_input, next_track_input, next_track_all_input, prev_track_connects_with_start_input, next_track_connects_with_start_input, is_station_input, is_crossroad_input, max_speed_input, max_carts_input):
        self.name = name_input
        self.no = no_input
        self.length_mm = length_mm_input
        self.stopper_start = stopper_start_input
        self.stopper_end = stopper_end_input
        self.prev_track = prev_track_input
        self.prev_track_all = prev_track_all_input
        self.next_track = next_track_input
        self.next_track_all = next_track_all_input
        self.prev_track_connects_with_start = prev_track_connects_with_start_input
        self.next_track_connects_with_start = next_track_connects_with_start_input
        self.is_station = is_station_input
        self.is_crossroad = is_crossroad_input
        self.max_speed = max_speed_input
        self.max_carts = max_carts_input
        self.carts = []
        self.collision_bwd = False
        self.collision_fwd = False

    def get_length(self):
        return self.length_mm

    def update_cart(self, cart_input):
        if not cart_input in self.carts:
            self.carts.append(cart_input)

    def delete_cart(self, cart_input):
        if cart_input in self.carts:
            self.carts.remove(cart_input)

    def update_crossroad(self, track_input, start_input):
        if start_input == True and track_input in self.prev_track_all:
            # track_index = self.prev_track_all.index(track_input)
            self.prev_track = track_input
            # self.prev_track_connects_with_start = prev_track_connects_with_start

        if start_input == False and track_input in self.next_track_all:
            self.next_track = track_input
            # self.next_track_connects_with_start = next_track_connects_with_start
    
      

    # def init_crossroad(self, length_mm_crossroad_input, left_track_input, right_track_input, stopper_left_input, stopper_right_input, left_track_connects_with_start_input, right_track_connects_with_start_input):
    #    self.length_mm_crossroad = length_mm_crossroad_input
    #    self.left_track = left_track_input
    #    self.right_track = right_track_input
    #    self.stopper_left = stopper_left_input
    #    self.stopper_right = stopper_right_input
    #    self.left_track_connects_with_start = left_track_connects_with_start_input
    #    self.right_track_connects_with_start = right_track_connects_with_start_input

    # def switch_crossroad(self, setting_input):
    # #0- none, 1- start-stop, 2- left_right, 3- start-left, 4- start-right, 5- end-left, 6- end-right
    #     self.crossroad_setting = setting_input
    
    # def get_crossroad_setting(self):
    #     return self.crossroad_setting
    


class Cart:
    def __init__(self, name_input):
        self.name = name_input
        self.route = []
        self.route_prev = []
        self.velocity_max = 10
        self.alarms = Alarms('C', self.name)
        
    def get_velo(self):
       return self.velocity
   
    def get_pos_mm(self):
       return self.pos_branch_mm
    
    def set_velo(self, velo_in):
        if velo_in < self.velocity_max:
            self.velocity = velo_in
        else: 
            self.velocity = self.velocity_max
        
    def get_name(self):
        return self.name
    
    def update_total_distance_mm(self):
        self.total_distance_mm = self.total_distance_mm + self.velocity

    def update_pos_branch_mm(self):
        self.pos_branch_mm = self.pos_branch_mm + self.velocity * self.direction
        
    def set_dir(self, dir_in):
        self.direction = dir_in

    def flip_dir(self):
        # self.direction = self.direction*(-1)
        if self.direction == FWD:
            self.direction = BWD
        elif self.direction == BWD:
            self.direction = FWD

    def get_dir(self):
        return self.direction

    def update_track(self, track_input):
        self.track_actual = track_input

    def print_info(self):
        output = {
        "name" :    self.get_name(), 
        "track" :   self.track_actual_no,
        "position": round(self.get_pos_mm(),2),
        "velocity": self.get_velo(),
        "direction":self.get_dir()
        }

        # return ""+ self.get_name() +" "+ self.track_actual_no +" "+ '{0:.2f}'.format(self.get_pos_mm()) +" "+ '{0:.2f}'.format(self.get_velo()) + self.get_dir() 
        return output

    def print_info_string(self):
        output = ""
        output = "name="
        output += self.get_name()
        output += " "
        output += "track="
        output += self.track_actual_no
        output += " "
        output += "position="
        output += str(self.get_pos_mm())
        output += " "
        output += "velocity="
        output += str(self.get_velo())
        output += " "
        output += "direction="
        output += str(self.get_dir())
        
        return output


    direction = FWD
    direction_last = FWD
    direction_branch = FWD
    direction_branch_last = FWD
    velocity = 0
    velocity_max = 4
    pos_branch_mm = 0
    total_distance_mm = 0
    track_actual = None
    track_actual_no = None
    track_last_no = None
    ON_ROUTE = False
    DESTINATION = -1

def make_edge(start, end, cost=1):
  return Edge(start, end, cost)


class Graph:
    def __init__(self, edges):
        # let's check that the data is right
        wrong_edges = [i for i in edges if len(i) not in [2, 3]]
        if wrong_edges:
            raise ValueError('Wrong edges data: {}'.format(wrong_edges))

        self.edges = [make_edge(*edge) for edge in edges]

    @property
    def vertices(self):
        return set(
            sum(
                ([edge.start, edge.end] for edge in self.edges), []
            )
        )

    def get_node_pairs(self, n1, n2, both_ends=True):
        if both_ends:
            node_pairs = [[n1, n2], [n2, n1]]
        else:
            node_pairs = [[n1, n2]]
        return node_pairs

    def remove_edge(self, n1, n2, both_ends=True):
        node_pairs = self.get_node_pairs(n1, n2, both_ends)
        edges = self.edges[:]
        for edge in edges:
            if [edge.start, edge.end] in node_pairs:
                self.edges.remove(edge)

    def add_edge(self, n1, n2, cost=1, both_ends=True):
        node_pairs = self.get_node_pairs(n1, n2, both_ends)
        for edge in self.edges:
            if [edge.start, edge.end] in node_pairs:
                return ValueError('Edge {} {} already exists'.format(n1, n2))

        self.edges.append(Edge(start=n1, end=n2, cost=cost))
        if both_ends:
            self.edges.append(Edge(start=n2, end=n1, cost=cost))

    @property
    def neighbours(self):
        neighbours = {vertex: set() for vertex in self.vertices}
        for edge in self.edges:
            neighbours[edge.start].add((edge.end, edge.cost))

        return neighbours

    def dijkstra(self, source, dest):
        assert source in self.vertices, 'Such source node doesn\'t exist'
        distances = {vertex: inf for vertex in self.vertices}
        previous_vertices = {
            vertex: None for vertex in self.vertices
        }
        distances[source] = 0
        vertices = self.vertices.copy()

        while vertices:
            current_vertex = min(
                vertices, key=lambda vertex: distances[vertex])
            vertices.remove(current_vertex)
            if distances[current_vertex] == inf:
                break
            for neighbour, cost in self.neighbours[current_vertex]:
                alternative_route = distances[current_vertex] + cost
                if alternative_route < distances[neighbour]:
                    distances[neighbour] = alternative_route
                    previous_vertices[neighbour] = current_vertex

        path, current_vertex = deque(), dest
        while previous_vertices[current_vertex] is not None:
            path.appendleft(current_vertex)
            current_vertex = previous_vertices[current_vertex]
        if path:
            path.appendleft(current_vertex)
        return path
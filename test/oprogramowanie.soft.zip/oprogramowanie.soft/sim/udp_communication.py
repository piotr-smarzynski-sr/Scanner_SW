from time import time as now
from time import sleep
import socket
import base64
import structs


from structs import cartInfoUDP
from thread_print import s_print

USE_STRUCT_MODULE = False

# TODO: use the same anmount of factors encoding on both transmit and receive
def transmit_data2(IP_ADDRESS, TX_PORT, payload):
    socket_transmit = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    socket_transmit.sendto(payload, (IP_ADDRESS, TX_PORT))
    socket_transmit.close()

def receive_data2(socket_receive, running):
    message_rx_bytes, addr = socket_receive.recvfrom(15)
    message_rx = cartInfoUDP.Deserialize(message_rx_bytes)
    return message_rx

# def transmit_data(IP_ADDRESS, TX_PORT, Cart_name, MESSAGE, MESSAGE_TYPE = 0, USE_B85=True, DEBUG=False):
#     RX_PORT = 0
#     if len(MESSAGE) > 0:
#         socket_transmit = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

#         if DEBUG:
#             s_print("UDP target IP:", IP_ADDRESS)
#             s_print("UDP target port:", TX_PORT)
#         if DEBUG:
#             s_print("TX to :  ", (IP_ADDRESS, TX_PORT), ':', MESSAGE)

#         HEADER = Cart_name.to_bytes(2, 'big') + MESSAGE_TYPE.to_bytes(1, 'big')
#         if MESSAGE_TYPE != 0:
#             MESSAGE = MESSAGE.encode()
        
#         MESSAGE = HEADER + MESSAGE

#         if USE_B85 == True:
#             MESSAGE_READY = base64.b85encode(MESSAGE)
#         elif USE_B85 == False:
#             MESSAGE_READY = MESSAGE
    
#         socket_transmit.sendto(MESSAGE_READY, (IP_ADDRESS, TX_PORT))
#         if DEBUG:
#             s_print('MESSAGE_READY: ', MESSAGE_READY)
#         socket_transmit.close()

# def receive_data(socket_receive, running, RX_PORT, clients=None, loop_infinite=True, USE_STRUCT_MODULE=True, USE_B85=True, DEBUG=False):
#     while (1):
#         data_not_empty = False
#         data, addr = socket_receive.recvfrom(1024) # buffer size is 1024 bytes
#         # if data != '':
#         data_not_empty = True
#         if USE_B85 == True:
#             HEADER_AND_MESSAGE = base64.b85decode(data)
#         elif USE_B85 == False:
#             HEADER_AND_MESSAGE = data

#         HEADER = HEADER_AND_MESSAGE[:3]
#         HEADERSIZE = len(HEADER)
#         client_port = 0
#         data_size = 0
#         message_type = 0
#         client_port = int.from_bytes(HEADER[:2], 'big')
#         message_type = int.from_bytes(HEADER[2:], 'big')

#         header_dict = {
#             'client_address' : addr[0],
#             'client_port' : client_port,
#             'data_size' : data_size,
#             'message_type' : message_type
#         }
#         MESSAGE_READY = HEADER_AND_MESSAGE[HEADERSIZE:]
#         if message_type == 0:
#             message_to_client = structs.Frame_to_Cart("message_to_client")
#             message_to_client.unpack(MESSAGE_READY, USE_STRUCT_MODULE)
#             if DEBUG:
#                 s_print("RX (", data_size, ',', message_type, ") from :", addr, ':\n', message_to_client)
#         elif message_type >= 1:
#             message_to_client = MESSAGE_READY.decode()
#             if DEBUG:
#                 s_print("RX (", data_size, ',', message_type, ") from :", addr, ':\n', MESSAGE_READY)
#         else:                
#             message_to_client = MESSAGE_READY
#             if DEBUG:
#                 s_print("RX (", data_size, ',', message_type, ") from :", addr, ':\n', MESSAGE_READY)

#         if isinstance(clients, list):
#             client_updated = False
#             for client in clients:
#                 if client[0] == addr[0] and client[1] == client_port:
#                     client[2] = now()
#                     client_updated = True

#             if client_updated == False:
#                 clients.append([addr[0], client_port, now()])
#                 if client_port != RX_PORT:
#                     s_print('New client: ', addr[0], client_port, 'Clients: ', len(clients))        
#         if loop_infinite == False:
#             break
#     # if data_not_empty:
#     return message_to_client, header_dict

def client_timeout(clients, running, CLIENT_TIMEOUT=3, DB_UPDATE=False):
    while (running == True):
        time_now = now()
        client_no = 0
        client_delete = False
        for client in clients:
            if time_now - client[2] > CLIENT_TIMEOUT:
                s_print("Client (" ,client[0], client[1],') timeout! ', end='') 
                if DB_UPDATE:
                    import db_communication
                    db_ok = db_communication.update('carts',
                                                    ['active'],
                                                    [False],
                                                    ['ip_address', 'port'],
                                                    [client[0], str(client[1])],
                                                    DEBUG=False)

                client_delete = True
                break
            client_no +=1
        if client_delete == True:
            del clients[client_no]
            s_print('Clients: ', len(clients))
        else:
            sleep(1)
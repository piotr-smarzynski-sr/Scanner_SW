from flask import Flask

def thread_webAPP():
    # global counter
    app = Flask(__name__)

    @app.route("/")
    def nothing():
        output =  "<head>  <meta http-equiv='refresh' content='2'></head>"
        output += "<title>Flask app</title>"
        output += "<b><h2>"
        # if time.time() - time_program_start > CART_INFO_DELAY_FROM_START:
        #     for cart in cart_system:
        #         output += cart.print_info()["name"]
        #         output += " "
        #         output += cart.print_info()["track"]
        #         output += " "
        #         output += str(cart.print_info()["position"])
        #         output += " "
        #         output += str(cart.print_info()["velocity"])
        #         output += " "
        #         output += str(cart.print_info()["direction"])
        #         output += " "
        #         output += "<br>"
        #     # output += cart_system[1].print_info()
        #     # output += "<br>"
        # else:
        #     output += "Hello World!\t"# + str(round(counter, 3))
        output += "</b></h2>"
        return output

    app.run(debug=True, use_reloader=False)

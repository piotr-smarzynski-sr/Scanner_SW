from threading import Lock
import logging
from datetime import datetime
from colorama import init, Fore

init(convert=True) #COLORAMA

s_print_lock = Lock()

def getDate():
    now = datetime.now() # current date and time
    return now.strftime("%Y%m%d_%H%M%S")

def getHour():
    now = datetime.now() # current date and time
    return now.strftime("%H:%M:%S")

def s_print(*a, **b):
    global s_print_lock
    """Thread safe print function"""
    with s_print_lock:
        print(*a, **b)
        output = ''
        for argument in a:
            output += str(argument)
            output += ' '
            # output = output.strip(Fore.RESET + Fore.LIGHTBLUE_EX + Fore.LIGHTRED_EX + Fore.LIGHTGREEN_EX)
        if not output.strip() == '':
            # logging.info(getDate() +' '+ output)
            pass


# logging.basicConfig(filename='logs/simulator_'+getDate()+'.log',level=logging.DEBUG)

def testCode():
    function_name = Fore.YELLOW+' testCode: '+Fore.RESET
    s_print(function_name, "Hello")
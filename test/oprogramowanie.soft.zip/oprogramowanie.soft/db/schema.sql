--
-- PostgreSQL database dump
--

-- Dumped from database version 10.11
-- Dumped by pg_dump version 10.11

-- Started on 2020-07-10 12:18:44

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 1 (class 3079 OID 12924)
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- TOC entry 2837 (class 0 OID 0)
-- Dependencies: 1
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 197 (class 1259 OID 16437)
-- Name: carts; Type: TABLE; Schema: public; Owner: piotr
--

CREATE TABLE public.carts (
    "ID" integer NOT NULL,
    name character varying(10),
    description character varying(32),
    order_no integer,
    order_type integer,
    order_task integer,
    track_actual_old character varying(10),
    track_position integer,
    type integer,
    direction integer,
    facing integer,
    max_speed integer,
    speed integer,
    active boolean,
    updated timestamp with time zone,
    ip_address character varying(15),
    port integer,
    no integer,
    track_no integer,
    track_actual integer
);


ALTER TABLE public.carts OWNER TO piotr;

--
-- TOC entry 196 (class 1259 OID 16435)
-- Name: carts_ID_seq; Type: SEQUENCE; Schema: public; Owner: piotr
--

CREATE SEQUENCE public."carts_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."carts_ID_seq" OWNER TO piotr;

--
-- TOC entry 2839 (class 0 OID 0)
-- Dependencies: 196
-- Name: carts_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: piotr
--

ALTER SEQUENCE public."carts_ID_seq" OWNED BY public.carts."ID";


--
-- TOC entry 199 (class 1259 OID 16446)
-- Name: orders; Type: TABLE; Schema: public; Owner: piotr
--

CREATE TABLE public.orders (
    "ID" integer NOT NULL,
    type integer,
    "time" timestamp with time zone,
    cargo integer,
    status integer,
    status_text character varying(64),
    cart_type integer,
    cart_no integer,
    updated timestamp with time zone,
    start_point integer,
    end_point integer,
    max_speed integer
);


ALTER TABLE public.orders OWNER TO piotr;

--
-- TOC entry 198 (class 1259 OID 16444)
-- Name: orders_ID_seq; Type: SEQUENCE; Schema: public; Owner: piotr
--

CREATE SEQUENCE public."orders_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."orders_ID_seq" OWNER TO piotr;

--
-- TOC entry 2841 (class 0 OID 0)
-- Dependencies: 198
-- Name: orders_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: piotr
--

ALTER SEQUENCE public."orders_ID_seq" OWNED BY public.orders."ID";


--
-- TOC entry 201 (class 1259 OID 16462)
-- Name: tracks_map; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tracks_map (
    "ID" integer NOT NULL,
    no integer,
    prev_no integer,
    next_no integer,
    prev_no_all integer[],
    next_no_all integer[],
    length_mm integer
);


ALTER TABLE public.tracks_map OWNER TO postgres;

--
-- TOC entry 200 (class 1259 OID 16460)
-- Name: tracks_map_ID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."tracks_map_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."tracks_map_ID_seq" OWNER TO postgres;

--
-- TOC entry 2843 (class 0 OID 0)
-- Dependencies: 200
-- Name: tracks_map_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."tracks_map_ID_seq" OWNED BY public.tracks_map."ID";


--
-- TOC entry 202 (class 1259 OID 16468)
-- Name: tracks_properties; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tracks_properties (
    "ID" integer NOT NULL,
    length integer
);


ALTER TABLE public.tracks_properties OWNER TO postgres;

--
-- TOC entry 204 (class 1259 OID 16483)
-- Name: users; Type: TABLE; Schema: public; Owner: piotr
--

CREATE TABLE public.users (
    "ID" integer NOT NULL,
    username character varying(20) NOT NULL,
    password character varying(128) NOT NULL,
    security_lvl integer
);


ALTER TABLE public.users OWNER TO piotr;

--
-- TOC entry 203 (class 1259 OID 16481)
-- Name: users_ID_seq; Type: SEQUENCE; Schema: public; Owner: piotr
--

CREATE SEQUENCE public."users_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."users_ID_seq" OWNER TO piotr;

--
-- TOC entry 2846 (class 0 OID 0)
-- Dependencies: 203
-- Name: users_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: piotr
--

ALTER SEQUENCE public."users_ID_seq" OWNED BY public.users."ID";


--
-- TOC entry 2694 (class 2604 OID 16440)
-- Name: carts ID; Type: DEFAULT; Schema: public; Owner: piotr
--

ALTER TABLE ONLY public.carts ALTER COLUMN "ID" SET DEFAULT nextval('public."carts_ID_seq"'::regclass);


--
-- TOC entry 2695 (class 2604 OID 16449)
-- Name: orders ID; Type: DEFAULT; Schema: public; Owner: piotr
--

ALTER TABLE ONLY public.orders ALTER COLUMN "ID" SET DEFAULT nextval('public."orders_ID_seq"'::regclass);


--
-- TOC entry 2696 (class 2604 OID 16465)
-- Name: tracks_map ID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tracks_map ALTER COLUMN "ID" SET DEFAULT nextval('public."tracks_map_ID_seq"'::regclass);


--
-- TOC entry 2697 (class 2604 OID 16486)
-- Name: users ID; Type: DEFAULT; Schema: public; Owner: piotr
--

ALTER TABLE ONLY public.users ALTER COLUMN "ID" SET DEFAULT nextval('public."users_ID_seq"'::regclass);


--
-- TOC entry 2699 (class 2606 OID 16442)
-- Name: carts carts_pkey; Type: CONSTRAINT; Schema: public; Owner: piotr
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT carts_pkey PRIMARY KEY ("ID");


--
-- TOC entry 2701 (class 2606 OID 16451)
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: piotr
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY ("ID");


--
-- TOC entry 2703 (class 2606 OID 16467)
-- Name: tracks_map tracks_map_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tracks_map
    ADD CONSTRAINT tracks_map_pkey PRIMARY KEY ("ID");


--
-- TOC entry 2705 (class 2606 OID 16472)
-- Name: tracks_properties tracks_properties_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tracks_properties
    ADD CONSTRAINT tracks_properties_pkey PRIMARY KEY ("ID");


--
-- TOC entry 2707 (class 2606 OID 16488)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: piotr
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY ("ID");


--
-- TOC entry 2708 (class 2606 OID 16473)
-- Name: tracks_properties foreign_track_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tracks_properties
    ADD CONSTRAINT foreign_track_id FOREIGN KEY ("ID") REFERENCES public.tracks_map("ID") NOT VALID;


--
-- TOC entry 2838 (class 0 OID 0)
-- Dependencies: 197
-- Name: TABLE carts; Type: ACL; Schema: public; Owner: piotr
--

REVOKE ALL ON TABLE public.carts FROM piotr;
GRANT ALL ON TABLE public.carts TO piotr WITH GRANT OPTION;


--
-- TOC entry 2840 (class 0 OID 0)
-- Dependencies: 199
-- Name: TABLE orders; Type: ACL; Schema: public; Owner: piotr
--

REVOKE ALL ON TABLE public.orders FROM piotr;
GRANT ALL ON TABLE public.orders TO piotr WITH GRANT OPTION;


--
-- TOC entry 2842 (class 0 OID 0)
-- Dependencies: 201
-- Name: TABLE tracks_map; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.tracks_map TO piotr WITH GRANT OPTION;


--
-- TOC entry 2844 (class 0 OID 0)
-- Dependencies: 202
-- Name: TABLE tracks_properties; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.tracks_properties TO piotr WITH GRANT OPTION;


--
-- TOC entry 2845 (class 0 OID 0)
-- Dependencies: 204
-- Name: TABLE users; Type: ACL; Schema: public; Owner: piotr
--

REVOKE ALL ON TABLE public.users FROM piotr;
GRANT ALL ON TABLE public.users TO piotr WITH GRANT OPTION;


--
-- TOC entry 1692 (class 826 OID 16443)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: -; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres GRANT ALL ON TABLES  TO piotr WITH GRANT OPTION;


-- Completed on 2020-07-10 12:18:45

--
-- PostgreSQL database dump complete
--


"""
Module udp_communication - interface with UDP sockets

Functions:
    transmitDataUDP: Send data over UDP
    receiveDataUDP2: Receive data via UDP
    clientTimeoutUDP: Thread for removing non alive clients
"""
import base64
import socket
from time import time as now
from time import sleep

from colorama import init, Fore

from udp_payloads import cartInfoUDP
import db_communication
from thread_print import s_print

init(convert=True) # COLORAMA
USE_STRUCT_MODULE = False

def transmitDataUDP(IP_ADDRESS, TX_PORT, RX_PORT, MESSAGE, MESSAGE_TYPE=0, USE_B85=True, DEBUG=False):
    """
    Send data over UDP

    Args:
        IP_ADDRESS: str
            IP address od sending destination e.g. '192.168.2.45'
        TX_PORT: int
            UDP port of sending destination
        RX_PORT: int
            UDP port of this server
        MESSAGE: str
            Message to send
        MESSAGE_TYPE: int
            Type of sended message
        USE_B85: bool
            Enable Base85 encoding
        DEBUG: bool
            Default: False, enable additional debug printing

    Returns:
        None

    Raises:
        None
    """
    function_name = Fore.LIGHTCYAN_EX+"transmitDataUDP:"+Fore.RESET
    if len(MESSAGE) > 0:
        socket_transmit = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        if DEBUG:
            s_print(function_name, "UDP target IP:", IP_ADDRESS)
            s_print(function_name, "UDP target port:", TX_PORT)
        if DEBUG:
            s_print("TX to :  ", (IP_ADDRESS, TX_PORT), ':', MESSAGE)

        HEADER = RX_PORT.to_bytes(2, 'big') + MESSAGE_TYPE.to_bytes(1, 'big')
        if MESSAGE_TYPE != 0:
            MESSAGE = MESSAGE.encode()

        MESSAGE = HEADER + MESSAGE

        if USE_B85 is True:
            MESSAGE_READY = base64.b85encode(MESSAGE)
        elif USE_B85 is False:
            MESSAGE_READY = MESSAGE

        socket_transmit.sendto(MESSAGE_READY, (IP_ADDRESS, TX_PORT))
        if DEBUG:
            s_print(function_name, 'MESSAGE_READY: ', MESSAGE_READY)
        socket_transmit.close()

def receiveDataUDP2(socket_receive):
    """
    Receive data via UDP

    Args:
        socket_receive: socket
            UDP receiving socket

    Returns:
        message_rx: cartInfoUDP
            received message in object format
        ip_address: str
            IP address of transmitter

    Raises:
        None
    """
    message_rx_bytes, addr = socket_receive.recvfrom(15)
    message_rx = cartInfoUDP.Deserialize(message_rx_bytes)
    return message_rx, addr[0], addr[1]# addr = [ip_address, port]

def clientTimeoutUDP(clients, running, CLIENT_TIMEOUT=3, DB_UPDATE=False):
    """
    Thread for removing non alive clients

    Args:
        clients: list
            List of UDP clients
        running: bool
            pointer to flag for killing thread
        CLIENT_TIMEOUT: int
            Default: 3, anmount of seconds after client is deleted from list
        DB_UPDATE: bool
            Enable updating database

    Returns:
        None

    Raises:
        None
    """
    function_name = Fore.LIGHTCYAN_EX+"clientTimeoutUDP:"+Fore.RESET
    while running is True:
        client_no = 0
        client_delete = False
        for client in clients:
            # client[ip, port, last_active]
            # if lient was updated more than timeout ago
            if now() - client[2] > CLIENT_TIMEOUT:
                s_print(function_name, "Client (", client[0], client[1], ') timeout! ')
                if DB_UPDATE:
                    # zmiana wyszukiwania po cart id nie wchodzi w grę
                    # przy tej strukturze listy clients
                    db_communication.cartSetInactive(client[0], client[1])

                client_delete = True
                break
            client_no += 1
        if client_delete is True:
            del clients[client_no] # Z tej tabeli usuwa wyłącznie ten wątek
            s_print(function_name, 'Clients: ', len(clients))
        else:
            sleep(1)

import struct

class GetIP(object):
    MSG_TYPE = 0x00000000
    def __init__(self):
        pass

    def __str__(self):
        return ''

    def serialize(self):
        return b''

    @staticmethod
    def Deserialize(payload_bytes):
        return GetIP()

class GetIPResp(object):
    MSG_TYPE = 0x40000000
    def __init__(self, ip_address):
        self.ip_address = ip_address # uint8[4]

    def __str__(self):
        output = 'ip_address: '
        output += str(self.ip_address)
        return output

    def serialize(self):
        serialized = b''
        for i, byte in enumerate(self.ip_address):
            serialized += struct.pack('>B', byte)

        return serialized

    @staticmethod
    def Deserialize(payload_bytes):
        ip_address = struct.unpack('>4B', payload_bytes)
        return GetIPResp(ip_address)

class GetSSID(object):
    MSG_TYPE = 0x00000001
    def __init__(self):
        pass

    def __str__(self):
        return ''

    def serialize(self):
        return b''

    @staticmethod
    def Deserialize(payload_bytes):
        return GetSSID()

class GetSSIDResp(object):
    MSG_TYPE = 0x40000001
    def __init__(self, ssid):
        self.ssid = ssid

    def __str__(self):
        output = 'ssid: '
        output += str(self.ssid)
        return output

    def serialize(self):
        return struct.pack('32s', self.ssid)

    @staticmethod
    def Deserialize(payload_bytes):
        ssid = struct.unpack('32s', payload_bytes)
        return GetSSIDResp(ssid)

class GetRSSI(object):
    MSG_TYPE = 0x00000002
    def __init__(self):
        pass

    def __str__(self):
        return ''

    def serialize(self):
        return b''

    @staticmethod
    def Deserialize(payload_bytes):
        return GetRSSI()

class GetRSSIResp(object):
    MSG_TYPE = 0x40000002
    def __init__(self, rssi):
        self.rssi = rssi

    def __str__(self):
        output = 'rssi: '
        output += str(self.rssi)
        return output

    def serialize(self):
        return struct.pack('>b', self.rssi)

    @staticmethod
    def Deserialize(payload_bytes):
        rssi = struct.unpack('>b', payload_bytes)
        return GetRSSIResp(rssi)

class GetWiFiChannel(object):
    MSG_TYPE = 0x00000003
    def __init__(self):
        pass

    def __str__(self):
        return ''

    def serialize(self):
        return b''

    @staticmethod
    def Deserialize(payload_bytes):
        return GetWiFiChannel()

class GetWiFiChannelResp(object):
    MSG_TYPE = 0x40000003
    def __init__(self, channel):
        self.channel = channel

    def __str__(self):
        output = 'channel: '
        output += str(self.channel)
        return output

    def serialize(self):
        return struct.pack('>B', self.channel)

    @staticmethod
    def Deserialize(payload_bytes):
        channel = struct.unpack('>B', payload_bytes)
        return GetWiFiChannelResp(channel)

class GetBSSID(object):
    MSG_TYPE = 0x00000004
    def __init__(self):
        pass

    def __str__(self):
        return ''

    def serialize(self):
        return b''

    @staticmethod
    def Deserialize(payload_bytes):
        return GetBSSID()

class GetBSSIDResp(object):
    MSG_TYPE = 0x40000004
    def __init__(self, bssid):
        self.bssid = bssid # uint8[6]

    def __str__(self):
        output = 'bssid: '
        output += str(self.bssid)
        return output

    def serialize(self):
        serialized = b''
        for i, byte in enumerate(self.bssid):
            serialized += struct.pack('>B', byte)

        return serialized

    @staticmethod
    def Deserialize(payload_bytes):
        bssid = struct.unpack('6B', payload_bytes)
        return GetBSSIDResp(bssid)

class GetWiFiStatus(object):
    MSG_TYPE = 0x0000000F
    def __init__(self):
        pass

    def __str__(self):
        return ''

    def serialize(self):
        return b''

    @staticmethod
    def Deserialize(payload_bytes):
        return GetWiFiStatus()

class GetWiFiStatusResp(object):
    MSG_TYPE = 0x4000000F
    def __init__(self, ip_addr, ssid, bssid, rssi, channel):
        self.ip_addr = ip_addr
        self.ssid = ssid
        self.bssid = bssid
        self.rssi = rssi
        self.channel = channel

    def __str__(self):
        output = 'ip_addr: '
        output += str(self.ip_addr)
        output += '\nssid: '
        output += str(self.ssid)
        output += '\nbssid: '
        output += str(self.bssid)
        output += '\nrssi: '
        output += str(self.rssi)
        output += '\nchannel: '
        output += str(self.channel)
        return output

    def serialize(self):
        serialized = b''

        for i, byte in enumerate(self.ip_addr):
            serialized += struct.pack('>B', byte)

        serialized += struct.pack('32s', self.ssid.encode())

        for i, byte in enumerate(self.bssid):
            serialized += struct.pack('>B', byte)

        serialized += struct.pack('>b', self.rssi)
        serialized += struct.pack('>B', self.channel)
        return serialized

    @staticmethod
    def Deserialize(payload_bytes):
        ip_addr = struct.unpack('4B', payload_bytes[:4])
        payload_bytes = payload_bytes[4:]
        ssid = struct.unpack('32s', payload_bytes[:32])
        payload_bytes = payload_bytes[32:]
        bssid = struct.unpack('6B', payload_bytes[:6])
        payload_bytes = payload_bytes[6:]
        rssi = struct.unpack('b', payload_bytes[:1])
        payload_bytes = payload_bytes[1:]
        channel = struct.unpack('B', payload_bytes[:1])
        return GetWiFiStatusResp(ip_addr, ssid[0].decode(), bssid, rssi[0], channel[0])

class CartHello(object):
    MSG_TYPE = 0x00002000

    def __init__(self, mac_address):
        self.mac_address = mac_address # uint8[6]

    def __str__(self):
        output = 'mac_address: '
        output += str(self.mac_address)
        return output

    def serialize(self):
        serialized = b''
        for i, byte in enumerate(self.mac_address):
            serialized += struct.pack('>B', byte)

        return serialized

    @staticmethod
    def Deserialize(payload_bytes):
        mac_address = struct.unpack('>6B', payload_bytes)
        return CartHello(mac_address)

class CartHelloResp(object):
    MSG_TYPE = 0x40002000
    def __init__(self, cart_no):
        self.cart_no = cart_no

    def __str__(self):
        output = 'cart_no: '
        output += str(self.cart_no)
        return output

    def serialize(self):
        return struct.pack('>H', self.cart_no)

    @staticmethod
    def Deserialize(payload_bytes):
        cart_no = struct.unpack('>H', payload_bytes)
        return CartHelloResp(cart_no[0])

class CartConnStatus(object):
    MSG_TYPE = 0x00000006
    def __init__(self):
        pass

    def __str__(self):
        return ''

    def serialize(self):
        return b''

    @staticmethod
    def Deserialize(payload_bytes):
        return CartConnStatus()

class CartConnStatusResp(object):
    MSG_TYPE = 0x40000006
    def __init__(self, status):
        self.status = status

    def __str__(self):
        output = 'status: '
        output += str(self.status)
        return output

    def serialize(self):
        return struct.pack('>B', self.status)

    @staticmethod
    def Deserialize(payload_bytes):
        status = struct.unpack('>B', payload_bytes)
        return CartConnStatusResp(status[0])

class WelcomeMessage(object):
    MSG_TYPE = 0x00000007
    def __init__(self, status):
        self.status = status

    def __str__(self):
        output = 'status: '
        output += str(self.status)
        return output

    def serialize(self):
        return struct.pack('>B', self.status)

    @staticmethod
    def Deserialize(payload_bytes):
        status = struct.unpack('>B', payload_bytes)
        return WelcomeMessage(status[0])

class WelcomeMessageResp(object):
    MSG_TYPE = 0x40000007
    def __init__(self, status):
        self.status = status

    def __str__(self):
        output = 'status: '
        output += str(self.status)
        return output

    def serialize(self):
        return struct.pack('>B', self.status)

    @staticmethod
    def Deserialize(payload_bytes):
        status = struct.unpack('>B', payload_bytes)
        return WelcomeMessageResp(status[0])

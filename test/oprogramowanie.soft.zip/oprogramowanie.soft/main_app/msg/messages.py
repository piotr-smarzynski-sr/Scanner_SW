import struct
HEADER_SIZE = 7

class InvalidMessageHeader(Exception):
    pass

def buildMessage(payload, cart_id):
    pld = payload.serialize()
    header = struct.pack('>BIH', HEADER_SIZE+len(pld), payload.MSG_TYPE, cart_id)
    return header+pld

def parseMessage(message_bytes):
    # Pre verify length
    if len(message_bytes) < HEADER_SIZE:
        raise InvalidMessageHeader()
    header_bytes = message_bytes[0:HEADER_SIZE]
    payload_bytes = message_bytes[HEADER_SIZE:]
    length, payload_type, cart_id = struct.unpack('>BIH', header_bytes)
    return payload_type, cart_id, payload_bytes, (length - HEADER_SIZE)

import struct

class GoTo(object):
    MSG_TYPE = 0x00012000
    def __init__(self, stop_id, stop_track_num, stop_track_offset, direction, max_speed, slow_id, slow_track_num, slow_track_offset):
        self.stop_id = stop_id
        self.stop_track_num = stop_track_num
        self.stop_track_offset = stop_track_offset
        self.direction = direction
        self.max_speed = max_speed
        self.slow_id = slow_id
        self.slow_track_num = slow_track_num
        self.slow_track_offset = slow_track_offset

    def __str__(self):
        output = 'stop_id: '
        output += str(self.stop_id)
        output += '\nstop_track_num: '
        output += str(self.stop_track_num)
        output += '\nstop_track_offset: '
        output += str(self.stop_track_offset)
        output += '\ndirection: '
        output += str(self.direction)
        output += '\nmax_speed: '
        output += str(self.max_speed)
        output += '\nslow_id: '
        output += str(self.slow_id)
        output += '\nslow_track_num: '
        output += str(self.slow_track_num)
        output += '\nslow_track_offset: '
        output += str(self.slow_track_offset)

        return output

    def serialize(self):
        return struct.pack('>IHHBBIHH',
                           self.stop_id,
                           self.stop_track_num,
                           self.stop_track_offset,
                           self.direction,
                           self.max_speed,
                           self.slow_id,
                           self.slow_track_num,
                           self.slow_track_offset)

    @staticmethod
    def Deserialize(payload_bytes):
        stop_id, stop_track_num, stop_track_offset, direction, max_speed, slow_id, slow_track_num, slow_track_offset = struct.unpack('>IHHBBIHH', payload_bytes)
        return GoTo(stop_id,
                    stop_track_num,
                    stop_track_offset,
                    direction,
                    max_speed,
                    slow_id,
                    slow_track_num,
                    slow_track_offset)

class GoToResp(object):
    MSG_TYPE = 0x40012000
    def __init__(self, status):
        self.status = status

    def __str__(self):
        return 'Status: '+str(self.status)

    def serialize(self):
        return struct.pack('>B', self.status)

    @staticmethod
    def Deserialize(payload_bytes):
        status = struct.unpack('>B', payload_bytes)
        return GoToResp(status)

class GoDist(object):
    MSG_TYPE = 0x00012001
    def __init__(self, distance, direction):
        self.distance = distance
        self.direction = direction
    def serialize(self):
        return struct.pack('>HB', self.distance, self.direction)
    @staticmethod
    def Deserialize(payload_bytes):
        distance, direction = struct.unpack('>HB', payload_bytes)
        return GoDist(distance, direction)

class GoDistResp(object):
    MSG_TYPE = 0x40012001
    def __init__(self, status):
        self.status = status
    def serialize(self):
        return struct.pack('>B', self.status)
    @staticmethod
    def Deserialize(payload_bytes):
        status = struct.unpack('>B', payload_bytes)
        return GoDistResp(status)

class RouteDone(object):
    MSG_TYPE = 0x00012002
    def __init__(self, status):
        self.status = status

    def __str__(self):
        return 'Status: '+str(self.status)

    def serialize(self):
        return struct.pack('>B', self.status)

    @staticmethod
    def Deserialize(payload_bytes):
        status = struct.unpack('>B', payload_bytes)
        return RouteDone(status)

class RouteDoneResp(object):
    MSG_TYPE = 0x40012002
    def __init__(self, status):
        self.status = status

    def __str__(self):
        return 'Status: '+str(self.status)

    def serialize(self):
        return struct.pack('>B', self.status)

    @staticmethod
    def Deserialize(payload_bytes):
        status = struct.unpack('>B', payload_bytes)
        return RouteDoneResp(status)

class GetAccel(object):
    MSG_TYPE = 0x00010000
    def __init__(self):
        pass

    def __str__(self):
        return ''

    def serialize(self):
        return b''

    @staticmethod
    def Deserialize(payload_bytes):
        return GetAccel()

class GetAccelResp(object):
    MSG_TYPE = 0x40010000
    def __init__(self, acceleration):
        self.acceleration = acceleration

    def __str__(self):
        return 'acceleration: '+str(self.acceleration)

    def serialize(self):
        return struct.pack('>B', self.acceleration)

    @staticmethod
    def Deserialize(payload_bytes):
        acceleration = struct.unpack('>B', payload_bytes)
        return GetAccelResp(acceleration[0])

class SetAccel(object):
    MSG_TYPE = 0x00011000
    def __init__(self, acceleration):
        self.acceleration = acceleration

    def __str__(self):
        return 'acceleration: '+str(self.acceleration)

    def serialize(self):
        return struct.pack('>B', self.acceleration)

    @staticmethod
    def Deserialize(payload_bytes):
        acceleration = struct.unpack('>B', payload_bytes)
        return SetAccel(acceleration[0])

class SetAccelResp(object):
    MSG_TYPE = 0x40011000
    def __init__(self):
        pass

    def __str__(self):
        return ''

    def serialize(self):
        return b''

    @staticmethod
    def Deserialize(payload_bytes):
        return SetAccelResp()

class GetDecel(object):
    MSG_TYPE = 0x00010001
    def __init__(self):
        pass

    def __str__(self):
        return ''

    def serialize(self):
        return b''

    @staticmethod
    def Deserialize(payload_bytes):
        return GetDecel()

class GetDecelResp(object):
    MSG_TYPE = 0x40010001
    def __init__(self, deceleration):
        self.deceleration = deceleration

    def __str__(self):
        return 'deceleration: '+str(self.deceleration)

    def serialize(self):
        return struct.pack('>B', self.deceleration)

    @staticmethod
    def Deserialize(payload_bytes):
        deceleration = struct.unpack('>B', payload_bytes)
        return GetDecelResp(deceleration[0])

class SetDecel(object):
    MSG_TYPE = 0x00011001
    def __init__(self, acceleration):
        self.acceleration = acceleration

    def __str__(self):
        return 'acceleration: '+str(self.acceleration)

    def serialize(self):
        return struct.pack('>B', self.acceleration)

    @staticmethod
    def Deserialize(payload_bytes):
        acceleration = struct.unpack('>B', payload_bytes)
        return SetDecel(acceleration[0])

class SetDecelResp(object):
    MSG_TYPE = 0x40011001
    def __init__(self):
        pass

    def __str__(self):
        return ''

    def serialize(self):
        return b''

    @staticmethod
    def Deserialize(payload_bytes):
        return SetDecelResp()

class GetTorqueLimit(object):
    MSG_TYPE = 0x00010002
    def __init__(self):
        pass

    def __str__(self):
        return ''

    def serialize(self):
        return b''

    @staticmethod
    def Deserialize(payload_bytes):
        return GetTorqueLimit()

class GetTorqueLimitResp(object):
    MSG_TYPE = 0x40010002
    def __init__(self, torque_limit):
        self.torque_limit = torque_limit

    def __str__(self):
        return 'torque_limit: '+str(self.torque_limit)

    def serialize(self):
        return struct.pack('>B', self.torque_limit)

    @staticmethod
    def Deserialize(payload_bytes):
        torque_limit = struct.unpack('>B', payload_bytes)
        return GetTorqueLimitResp(torque_limit[0])

class SetTorqueLimit(object):
    MSG_TYPE = 0x00011002
    def __init__(self, torque_limit):
        self.torque_limit = torque_limit

    def __str__(self):
        return 'torque_limit: '+str(self.torque_limit)

    def serialize(self):
        return struct.pack('>B', self.torque_limit)

    @staticmethod
    def Deserialize(payload_bytes):
        torque_limit = struct.unpack('>B', payload_bytes)
        return SetTorqueLimit(torque_limit[0])

class SetTorqueLimitResp(object):
    MSG_TYPE = 0x40011002
    def __init__(self):
        pass

    def __str__(self):
        return ''

    def serialize(self):
        return b''

    @staticmethod
    def Deserialize(payload_bytes):
        return SetTorqueLimitResp()

class GetPosition(object):
    MSG_TYPE = 0x00010003
    def __init__(self):
        pass

    def __str__(self):
        return ''

    def serialize(self):
        return b''

    @staticmethod
    def Deserialize(payload_bytes):
        return GetPosition()

class GetPositionResp(object):
    MSG_TYPE = 0x40010003
    def __init__(self, track_num, track_offset):
        self.track_num = track_num
        self.track_offset = track_offset

    def __str__(self):
        output = 'track_num: '
        output += str(self.track_num)
        output += '\ntrack_offset: '
        output += str(self.track_offset)
        return output

    def serialize(self):
        return struct.pack('>HH', self.track_num, self.track_offset)

    @staticmethod
    def Deserialize(payload_bytes):
        track_num, track_offset = struct.unpack('>HH', payload_bytes)
        return GetPositionResp(track_num, track_offset)

class GetSpeed(object):
    MSG_TYPE = 0x00010004
    def __init__(self):
        pass

    def __str__(self):
        return ''

    def serialize(self):
        return b''

    @staticmethod
    def Deserialize(payload_bytes):
        return GetSpeed()

class GetSpeedResp(object):
    MSG_TYPE = 0x40010004
    def __init__(self, direction, speed):
        self.direction = direction
        self.speed = speed

    def __str__(self):
        output = 'direction: '
        output += str(self.direction)
        output += '\nspeed: '
        output += str(self.speed)
        return output

    def serialize(self):
        return struct.pack('>BB', self.direction, self.speed)

    @staticmethod
    def Deserialize(payload_bytes):
        direction, speed = struct.unpack('>hh', payload_bytes)
        return GetSpeedResp(direction, speed)

class CollisionAhead(object):
    MSG_TYPE = 0x00012004
    def __init__(self, status):
        self.status = status

    def __str__(self):
        output = 'status: '
        output += str(self.status)
        return output

    def serialize(self):
        return struct.pack('>B', self.status)

    @staticmethod
    def Deserialize(payload_bytes):
        status = struct.unpack('>B', payload_bytes)
        return CollisionAhead(status[0])

class CollisionAheadResp(object):
    MSG_TYPE = 0x40012004
    def __init__(self, status):
        self.status = status

    def __str__(self):
        output = 'status: '
        output += str(self.status)
        return output

    def serialize(self):
        return struct.pack('>B', self.status)

    @staticmethod
    def Deserialize(payload_bytes):
        status = struct.unpack('>B', payload_bytes)
        return CollisionAheadResp(status[0])

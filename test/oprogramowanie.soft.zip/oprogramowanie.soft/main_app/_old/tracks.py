class Track:
    def __init__(self, name_input, length_mm_input, stopper_start_input, stopper_end_input, prev_track_input, prev_track_all_input, next_track_input, next_track_all_input, prev_track_connects_with_start_input, next_track_connects_with_start_input, is_station_input, is_crossroad_input, max_speed_input, max_carts_input):
        self.name = name_input
        self.length_mm = length_mm_input
        self.stopper_start = stopper_start_input
        self.stopper_end = stopper_end_input
        self.prev_track = prev_track_input
        self.prev_track_all = prev_track_all_input
        self.next_track = next_track_input
        self.next_track_all = next_track_all_input
        self.prev_track_connects_with_start = prev_track_connects_with_start_input
        self.next_track_connects_with_start = next_track_connects_with_start_input
        self.is_station = is_station_input
        self.is_crossroad = is_crossroad_input
        self.max_speed = max_speed_input
        self.max_carts = max_carts_input
        self.carts = []

    def get_length(self):
        return self.length_mm

    def update_cart(self, cart_input):
        if not cart_input in self.carts:
            self.carts.append(cart_input)

    def delete_cart(self, cart_input):
        if cart_input in self.carts:
            self.carts.remove(cart_input)

    def update_crossroad(self, track_input, start_input):
        if start_input == True and track_input in self.prev_track_all:
            # track_index = self.prev_track_all.index(track_input)
            self.prev_track = track_input
            # self.prev_track_connects_with_start = prev_track_connects_with_start

        if start_input == False and track_input in self.next_track_all:
            self.next_track = track_input
            # self.next_track_connects_with_start = next_track_connects_with_start

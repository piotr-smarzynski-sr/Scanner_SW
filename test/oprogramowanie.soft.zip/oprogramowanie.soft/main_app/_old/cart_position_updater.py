from time import time as now
from time import sleep as sleep
from thread_print import s_print
import importlib.util
from colorama import init, Fore

import db_communication
import mqtt_communication
import udp_payloads


carts_clients = []
carts_clients_last_alive = {}

def clients_refresh(mqtt_clients, DEBUG=False):
    sleep(2)
    db_ok = db_communication.update('carts',
                                    ['active', 'speed', 'updated'],
                                    ['false', 0, 'now()'],
                                    [],
                                    [],
                                    DEBUG=DEBUG,
                                    UNSAFE_UPDATE=True)
    s_print('All carts set inactive: ', db_ok)
    while(1):
        message_rx = udp_payloads.Frame_to_Cart("message_rx")
        ########## UPDATE/SAVE NEW CLIENT #############
        if mqtt_clients[0][0].ACTUAL_MESSAGE != '' and mqtt_clients[0][0].ACTUAL_MESSAGE != None:
            message = str(mqtt_clients[0][0].ACTUAL_MESSAGE)
            message_rx.unpack(mqtt_clients[0][0].ACTUAL_MESSAGE)
            if DEBUG:
                # s_print('message_rx: ', message_rx.Cart)
                pass

            if not message_rx.Cart in carts_clients:
                if message != '':
                    carts_clients.append(message_rx.Cart)
                    client_found = False
                    for client in mqtt_clients:
                        if client[1] == 'sub_'+message_rx.Cart:
                            client_found = True
                    if client_found == False and len(carts_clients) > 0:
                        mqtt_clients.append((mqtt_communication.createClient('sub_'+message_rx.Cart, sub_topic='carts/'+message_rx.Cart+'/toMain'), 'sub_C'+message))
                
                s_print("New client: ", message_rx.Cart, "\t",len(carts_clients), "clients in total")
            
            while message_rx.Track_Actual[-1].isdigit() == False:
                message_rx.Track_Actual = message_rx.Track_Actual[:-1]

            while message_rx.Cart[-1].isdigit() == False:
                message_rx.Cart = message_rx.Cart[:-1]

            db_ok = db_communication.update('carts',
                                            ['track_actual', 'speed', 'active', 'updated'],
                                            [message_rx.Track_Actual, int(message_rx.Velocity), True, 'now()'],
                                            ['name'],
                                            [message_rx.Cart],
                                            DEBUG=DEBUG)
            if DEBUG:
                # s_print('UPDATE ok: ', db_ok)
                pass
            carts_clients_last_alive[message_rx.Cart] = now()
            mqtt_clients[0][0].ACTUAL_MESSAGE = ''
        
        ########## CHECK CLIENT TIMEOUT ###############
        for key in carts_clients_last_alive:
            if now() - carts_clients_last_alive[key] > 10:
                db_ok = db_communication.update('carts',
                                                ['active'],
                                                [False],
                                                ['name'],
                                                [key],
                                                DEBUG=DEBUG)
                del(carts_clients_last_alive[key])
                if key in carts_clients:
                    carts_clients.remove(key)
                for client in mqtt_clients:
                    if client[1] == key:
                        pass
                        # mqtt_communication.clientStop(client[0])
                        # mqtt_clients.remove(client)
                        break
                
                s_print("Client ", key, " timeout!", "\t",len(carts_clients), "clients in total. Mqtt_clients: ", len(mqtt_clients))
                if len(carts_clients) == 0:
                    s_print("No clients!")
                break
    s_print(Fore.LIGHTRED_EX, 'Thread Cart position updater ended.', Fore.RESET)        
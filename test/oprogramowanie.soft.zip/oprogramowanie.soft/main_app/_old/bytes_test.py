# import numpy as np
import math

# x = np.int16(8)
# x = 4
# print('x: ', x)
# arr = bytearray(x)
# print('arr: ', arr)

# y = int('1b100', base=0)
# print('y: ', y)

# string = "Python is interesting."

# # string with encoding 'utf-8'
# arr = bytearray(string, 'ASCII')
# print(arr)
# print('len(arr): ', len(arr))
# print()

# size = 5
# arr = bytearray(size)
# print('arr: ', arr)
# print('len(arr): ', len(arr))
# print()

# rList = [1, 2, 3, 4, 5]
# arr = bytearray(rList)
# print('arr: ', arr)
# print('len(arr): ', len(arr))

import struct


# var = struct.pack('hhh', 127, 255, 16)
# # for byte in var:
# #     print(byte)

# # print()
# print(var)
# print(struct.unpack('hhh', var))

# print('len(var): ', len(var))

# var = struct.pack('ii', 127, 255)
# print('var: ', var)
# print(struct.unpack('ii', var))
# print('len(var): ', len(var))


def intlenbytes(input):
    length = 1
    divider = 255
    while input / divider > 1:
        divider *= divider
        length += 1

    return length


# input = 70000


# def test(input, byteorder_input):
#     print('input: ', input)
#     length = intlenbytes(input)
#     print('length: ', length)
#     array = (input).to_bytes(length, byteorder=byteorder_input)
#     print('array: ', array)

#     if byteorder_input == 'little':
#         power = 0
#     if byteorder_input == 'big':
#         power = length - 1
#     output = 0
#     for byte in array:
#         print(byte, end=' ')
#         output = output + byte*pow(256, power)
#         if byteorder_input == 'little':
#             power += 1
#         if byteorder_input == 'big':
#             power -= 1

#     print('output: ', output)


# test(int(pow(256, 2)), 'big')
# test(int(pow(256, 2)), 'little')
# test(int(pow(256, 3)), 'big')
# test(int(pow(256, 3)), 'little')

# bytes(int(pow(256, 3))
# print('bytes(int(pow(256, 3)): ', bytes(int(pow(256, 3))))


# print('math.log(8,2): ', math.log(pow(256, 3), 256))

# print('math.log(pow(256, 3), 256): ', math.floor(math.log(pow(256, 3)+7, 256)))


# input = int(pow(256, 3)) + 7
# print('input: ', input)
# length = intlenbytes(input)
# print('length: ', length)

# math.floor(math.log(input, 256))
# print('math.floor(math.log(input, 256)): ', math.floor(math.log(input, 256)))

# bytes([pow(256, 3)])
# print('bytes([pow(256, 3)]): ', bytes([pow(256, 3)]))

# pow(256, 3).encode()
# print('pow(256, 3).encode(): ', pow(256, 3).encode())


var = struct.pack('i', pow(256, 3))
print('var: ', var)
unpacked = struct.unpack('i', var)

unpacked = unpacked[0]
print('unpacked: ', unpacked)
print('len(var): ', len(var))


var = struct.pack('10s', 'dupa123'.encode())
print('var: ', var)
unpacked = struct.unpack('10s', var)
unpacked = unpacked[0]
print('bytes: ', end=' ')
for byte in unpacked:
    print(byte, end=' ')
print()
print('unpacked: ', unpacked.decode())

print('len(var): ', len(var))

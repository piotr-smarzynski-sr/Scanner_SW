FWD = 1
BWD = -1


class Cart:
    def __init__(self, name_input):
        self.name = name_input
        self.route = []
        self.route_prev = []

    def get_velo(self):
        return self.velocity

    def get_pos_mm(self):
        return self.pos_branch_mm

    def set_velo(self, velo_in):
        if velo_in < self.velocity_max:
            self.velocity = velo_in
        else:
            self.velocity = self.velocity_max

    def get_name(self):
        return self.name

    def update_total_distance_mm(self):
        self.total_distance_mm = self.total_distance_mm + self.velocity

    def update_pos_branch_mm(self):
        self.pos_branch_mm = self.pos_branch_mm + self.velocity * self.direction

    def set_dir(self, dir_in):
        self.direction = dir_in

    def flip_dir(self):
        self.direction = self.direction*(-1)

    def get_dir(self):
        return self.direction

    def update_track(self, track_input):
        self.track_actual = track_input

    def print_info(self):
        output = {
            "name":    self.get_name(),
            "track":   self.track_actual_no,
            "position": self.get_pos_mm(),
            "velocity": self.get_velo(),
            "direction": self.get_dir()
        }

        # return ""+ self.get_name() +" "+ self.track_actual_no +" "+ '{0:.2f}'.format(self.get_pos_mm()) +" "+ '{0:.2f}'.format(self.get_velo()) + self.get_dir()
        return output

    def print_info_string(self):
        output = ""
        output = "name="
        output += self.get_name()
        output += " "
        output += "track="
        output += self.track_actual_no
        output += " "
        output += "position="
        output += str(self.get_pos_mm())
        output += " "
        output += "velocity="
        output += str(self.get_velo())
        output += " "
        output += "direction="
        output += str(self.get_dir())

        return output

    direction = FWD
    direction_last = FWD
    direction_branch = FWD
    direction_branch_last = FWD
    velocity = 0
    velocity_max = 4
    pos_branch_mm = 0
    total_distance_mm = 0
    track_actual = None
    track_actual_no = None
    track_last_no = None

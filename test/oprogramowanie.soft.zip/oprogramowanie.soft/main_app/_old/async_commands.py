# import importlib.util
# spec = importlib.util.spec_from_file_location("udp_communication", "D:/Projekty/099.MPLTechma/Rollercoaster/Python/Rollercoaster_modules/udp_communication.py")
# udp_communication = importlib.util.module_from_spec(spec)
# spec.loader.exec_module(udp_communication)

import udp_communication

from keyboard import is_pressed
from time import time as now
from thread_print import s_print


hotkeys_dict = {        
    'get firmware version'   : 'shift+a+1',
    'get total distance'     : 'shift+a+2'
}

def asyncCommandsHandler(running, socket_receive, clients, DEBUG=False):
    keyboard_check_time = now()
    while running:
        if now() - keyboard_check_time > 0.2:
            keyboard_check_time = now()
            '''
            adding new async comand:
            1) Add function similar to getSoftwareVersionAllCarts(clients, DEBUG=False)
            2) Go to cart_updater_udp in function cart_updater(socket_receive, running, RX_PORT, clients, DEBUG=False)
            3) Add code similar to if header['message_type'] == 1: around line 57
            4) Go to symulator_threads to function async_message2(header, message_rx, message_answered):
            5) Add code similar to if message_rx == 'v?': around line 168
            '''
            if is_pressed(hotkeys_dict['get firmware version']):
                getSoftwareVersionAllCarts(clients, DEBUG=DEBUG)
            elif is_pressed(hotkeys_dict['get total distance']):
                getTotalDistanceAllCarts(clients, DEBUG=DEBUG)        
                    
def getSoftwareVersionAllCarts(clients, DEBUG=False):
    s_print('Get firmware version from carts')
    message_to_client = 'v?'
    for client in clients:
        if DEBUG:
            s_print('Message sent to ',client[0], client[1])
        udp_communication.transmitDataUDP(client[0], client[1], 5005, message_to_client, MESSAGE_TYPE = 1, USE_B85=False, DEBUG=DEBUG)

def getTotalDistanceAllCarts(clients, DEBUG=False):
    s_print('Get total distance from carts')
    message_to_client = 'td?'
    for client in clients:
        if DEBUG:
            s_print('Message sent to ',client[0], client[1])
        udp_communication.transmitDataUDP(client[0], client[1], 5005, message_to_client, MESSAGE_TYPE = 2, USE_B85=False, DEBUG=DEBUG)
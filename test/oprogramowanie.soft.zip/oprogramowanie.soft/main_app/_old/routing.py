from random import randrange

def distance(start_track, end_track):
    """
    Calculates cost to reach end point
    """
    return randrange(0, 9999)

def calculate_route(start_track, end_track):
    tracks = ['T0', 'T1', 'T2', 'T3', 'T4', 'T5']#, 'T6', 'T7', 'T8', 'T9', 'T10']
    route = [start_track]
    if start_track in tracks:
        tracks.pop(tracks.index(start_track))
    if end_track in tracks:
        tracks.pop(tracks.index(end_track))

    tracks_buf = tracks
    for x in range(1, randrange(1, len(tracks_buf))):
        index = randrange(0, len(tracks_buf))
        route.append(tracks_buf[index])
        tracks_buf.pop(index)

    route.append(end_track)
    return route


# s_print("calculate_route('T5', 'T9'): ", calculate_route('T5', 'T9'))
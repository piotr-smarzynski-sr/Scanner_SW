import bcolors
import db_communication
import udp_communication
import udp_payloads
import mqtt_communication
import other
import routing
from pathfinder.graph import Graph, Edge
from pathfinder.pathfinder import Pathfinder
from thread_print import s_print

from time import sleep as sleep
from time import time as now
from colorama import init, Fore
from datetime import datetime as datetime
from threading import Thread
import json

init(convert=True) #COLORAMA

UDP_ENABLED = True
ORDERS_DEBUG = False
USE_STRUCT_MODULE = False
FACING_BEGIN = 1
FACING_END = 0
CART_FULL_SPEED = 25
CART_LIGHTRED_EXUCED_SPEED = 5
CART_STOP = 0

def ordersCheck(sleep_length, udp_clients, DEBUG=ORDERS_DEBUG):
    """
    Infinite loop to check available orders in DB. Use as thread.
    Return: None
    1) sleep_length is float, defines time in beetween loops. Value -1 breaks loop
    2) DEBUG prints SQL SELECT output dictionary
    """
    # global ordersCheckOutput
    if isinstance(sleep_length, str): ## usunąć, parametr powinien mieć zawsze typ int
        sleep_length = int(sleep_length)
    if UDP_ENABLED == False:
        client = mqtt_communication.createClient('OrderHandler')

    while(1):
        # Find available orders
        db_ok, ordersCheckOutput = db_communication.getAvailableOrders()
        if db_ok == False:
            s_print('Error in select')

        if DEBUG:
            s_print('db_ok: ', db_ok)
            s_print('type(ordersCheckOutput): ', type(ordersCheckOutput))
            if isinstance(ordersCheckOutput, dict):
                other.print_dict(ordersCheckOutput, prefix = 'DICT: ordersCheckOutput:', suffix = None)
            elif isinstance(ordersCheckOutput[0], dict):
                counter = 1
                for localdict in ordersCheckOutput:
                    other.print_dict(localdict, prefix = 'DICT: ordersCheckOutput_'+str(counter)+':', suffix = None)

        # if order with status = 1 found, proceed further. If not, restart checking after some time
        if len(ordersCheckOutput)>0:
            if DEBUG:
                s_print('Order found')

            """
            update order
            maybe start new thread
            find available cart
            send order to cart
            track cart and update order while state changes
            """
            if isinstance(ordersCheckOutput, dict):
                actual_order = ordersCheckOutput
            elif isinstance(ordersCheckOutput[0], dict):
                actual_order = ordersCheckOutput[0]

            if DEBUG:
                s_print("actual_order['ID']: ", str(actual_order['ID']))

            db_communication.orderUpdateStatus(actual_order['ID'], 2, 'Accepted, cart searching', DEBUG=False)
            if DEBUG:
                s_print('update: ', db_ok)

            #Find available cart - cart with no current order and closest to start point
            available_carts = []
            waiting_for_cart_time = now()
            while len(available_carts) == 0:
                db_ok, available_carts = db_communication.getAvailableCarts()
                if db_ok == False:
                    s_print('Select ok: ', db_ok)

                travel_cost = 999999
                if len(available_carts)>0:
                    if DEBUG:
                        s_print("Cart found")
                    # cart choosing
                    counter = 1
                    for localdict in available_carts:
                        if DEBUG:
                            other.print_dict(localdict, prefix = 'DICT: Available_carts: '+str(counter), suffix = '--------------')
                        counter += 1

                    # find available cart closest to starting point
                    travel_cost_list = []
                    travel_cost_list.append(routing.distance(localdict['track_actual'], actual_order['start_point']))
                    travel_minimal_cost = min(travel_cost_list)
                    travel_minimal_cost_index = travel_cost_list.index(travel_minimal_cost)
                    cart_choosen = available_carts[travel_minimal_cost_index]
                    #cart is choosen
                    ############### NEW THREAD START, ORDER CHECK BACK TO START #############################
                    db_communication.orderUpdateStatus(actual_order['ID'], 2, 'Cart found: '+ cart_choosen['name'], DEBUG=False)
                    thread_name = "Order_"+str(actual_order['ID'])
                    cart_choosen_udp = []
                    if UDP_ENABLED:
                        cart_choosen_udp = None
                        for client in udp_clients:
                            if client[0] == cart_choosen['ip_address'] and client[1] == cart_choosen['port']:
                                cart_choosen_udp = client
                                s_print(Fore.LIGHTCYAN_EX, 'cart_choosen_udp: ', cart_choosen_udp, Fore.RESET)
                                orderThread = Thread(target=cart_order_execution,
                                    kwargs={'cart_choosen':cart_choosen,
                                            'actual_order':actual_order,
                                            'thread_name':thread_name,
                                            'UDP_ENABLED':UDP_ENABLED,
                                            'cart_choosen_udp':cart_choosen_udp,
                                            'DEBUG':DEBUG},
                                    name=thread_name,
                                    daemon=True)

                                orderThread.start()
                                s_print(Fore.LIGHTCYAN_EX,"Thread ", orderThread.getName(), 'started', Fore.RESET)
                                break

                    else:
                        orderThread = Thread(target=cart_order_execution,
                            kwargs={'cart_choosen':cart_choosen,
                                    'actual_order':actual_order,
                                    'thread_name':thread_name,
                                    'UDP_ENABLED':UDP_ENABLED,
                                    'cart_choosen_udp':cart_choosen_udp,
                                    'DEBUG':DEBUG},
                            name=thread_name,
                            daemon=True)

                        orderThread.start()
                        s_print("Thread ", orderThread.getName(), 'started')
                    ########## ORDER THREAD END #################################

                else:
                    if now() - waiting_for_cart_time > 20:
                        s_print("Finding cart timeout")
                        db_ok = db_communication.orderUpdateStatus(actual_order['ID'], 5, 'Timeout', DEBUG=False)
                        if db_ok:
                            s_print(Fore.LIGHTRED_EX, "Order ", str(actual_order['ID']), 'updated to timeout', Fore.RESET)
                            break

                    s_print("Repeat loop, no carts found")
                    sleep(1)

        if sleep_length < 0:
            s_print(Fore.LIGHTCYAN_EX, 'Orders check END', Fore.RESET)
            break

        sleep(sleep_length)

def cart_order_execution(cart_choosen, actual_order,  thread_name, UDP_ENABLED, cart_choosen_udp = [], DEBUG=False):
    if UDP_ENABLED == False:
        client = mqtt_communication.createClient('OrderHandler')

    # tracking cart to starting destination
    tracked_cart_name = cart_choosen['name']
    if UDP_ENABLED:
        if DEBUG:
            if cart_choosen_udp[0] == cart_choosen['ip_address'] and cart_choosen_udp[1] == cart_choosen['port']:
                s_print(Fore.YELLOW, 'cart_choosen_udp choosen: ', cart_choosen_udp, Fore.RESET)

    if DEBUG:
        other.print_dict(cart_choosen, prefix = 'DICT:  cart_choosen', suffix = '--------------')

    db_ok = db_communication.cartUpdateOrder(cart_choosen['name'], actual_order['ID'])
    if DEBUG:
        if db_ok == False:
            s_print('update_ok: ', db_ok)

    route_to_start = routing.calculate_route(cart_choosen['track_actual'], actual_order['start_point'])
    route_to_start = ['T0','T1', 'T2', 'T3', 'T4', 'T5']
    if DEBUG:
        s_print(tracked_cart_name, 'route: ', route_to_start)

    order_start_time = now()
    #--------------- Tracking start --------------------------
    s_print(Fore.LIGHTCYAN_EX, 'Travelling to order start destination', Fore.RESET)
    db_communication.orderUpdateStatus(actual_order['ID'], 2, 'Cart '+ cart_choosen['name']+ ' travels to start', DEBUG=False)
    track_cart_on_route(route_to_start, tracked_cart_name,  cart_choosen_udp, DEBUG=DEBUG)
    #---------------- Cart stopped in order starting point -------------
    s_print(Fore.LIGHTCYAN_EX, 'Cart', tracked_cart_name, 'is loaded on station' , Fore.LIGHTRED_EX, '####', Fore.LIGHTCYAN_EX, 'with cargo', actual_order['cargo'], Fore.RESET)
    db_communication.orderUpdateStatus(actual_order['ID'], 2, 'Cart '+ cart_choosen['name']+ ' loading', DEBUG=False)
    sleep(3) # loading cargo simulation
    s_print(Fore.LIGHTCYAN_EX, 'Loading cart', tracked_cart_name, 'done', Fore.RESET)
    db_communication.orderUpdateStatus(actual_order['ID'], 2, 'Cart '+ cart_choosen['name']+ ' travels to end', DEBUG=False)
    route_delivery = routing.calculate_route(actual_order['start_point'], actual_order['end_point'])
    # route_delivery = ['T5','T4','T3','T2','T1','T0']
    route_delivery = [5,4,3,2,1,0]
    if DEBUG:
        s_print(tracked_cart_name, 'route: ', route_delivery)

    s_print(Fore.LIGHTCYAN_EX, 'Travelling to order end destination', Fore.RESET)
    track_cart_on_route(route_delivery, tracked_cart_name, cart_choosen_udp, DEBUG=DEBUG)
    s_print(Fore.LIGHTCYAN_EX, 'Cart', tracked_cart_name, 'is unloaded on station' , Fore.LIGHTRED_EX, '####', Fore.LIGHTCYAN_EX, 'with cargo', actual_order['cargo'], Fore.RESET)
    db_communication.orderUpdateStatus(actual_order['ID'], 2, 'Cart '+ cart_choosen['name']+ ' unloading', DEBUG=False)
    sleep(3) # unloading cargo time
    s_print(Fore.LIGHTCYAN_EX, 'Unoading cart', tracked_cart_name, 'done', Fore.RESET)
    # ------------- CLEANUP -------------
    s_print('------------- CLEANUP -------------')
    db_ok = db_communication.cartUpdateOrder(cart_choosen['name'], 0)
    db_ok = db_communication.orderUpdateStatus(actual_order['ID'], 3, 'Done', DEBUG=False)
    s_print(Fore.LIGHTCYAN_EX, 'Order '+ str(actual_order['ID']) +' done, execution time:', round(now() - order_start_time,2), 's', Fore.RESET)
    s_print(Fore.LIGHTCYAN_EX, 'Thread', thread_name, 'ended', Fore.RESET)
    if UDP_ENABLED == False:
        mqtt_communication.clientStop(client)
        del(client)

def track_cart_on_route(route, tracked_cart_name, cart_choosen_udp, mqtt_client=None, DEBUG=False):
    message_to_cart = udp_payloads.Frame_to_Cart("message_to_cart")
    starting_tries = 1
    reducing_tries = 1
    while len(route) > 0:
        db_ok, tracked_cart = db_communication.getCart(tracked_cart_name)
        db_ok, actual_track = db_communication.getTrack(tracked_cart['track_actual'])
        if DEBUG:
            s_print('select ok: ', db_ok)

        if tracked_cart['track_actual'] == route[0]:
            route = route[1:]
            # cart can start moving
            if DEBUG:
                other.print_dict(actual_track, prefix = 'DICT:  actual_track', suffix = '--------------')

            if route[0] in actual_track['prev_conn']:
                if tracked_cart['facing'] == FACING_BEGIN:
                    message_to_cart.Direction = 2

                if tracked_cart['facing'] == FACING_END:
                    message_to_cart.Direction = 1

            if route[0] in actual_track['next_conn']:
                if tracked_cart['facing'] == FACING_BEGIN:
                    message_to_cart.Direction = 1

                if tracked_cart['facing'] == FACING_END:
                    message_to_cart.Direction = 2

            if route[0] in actual_track['prev_conn'] or route[0] in actual_track['next_conn']:
                message_to_cart.Next_Track = route[0]

            message_to_cart.Cart = tracked_cart_name
            message_to_cart.Velocity = CART_FULL_SPEED
            message_to_cart.Stop_at = route[-1]
            # message_to_cart.pack('FR01', USE_STRUCT_MODULE)
            message_to_cart.pack(USE_STRUCT_MODULE)
            if DEBUG:
                s_print(Fore.YELLOW, 'message_to_cart: \n', Fore.RESET, message_to_cart)

            if UDP_ENABLED == False:
                topic = 'cart_'+tracked_cart['name']
                if DEBUG:
                    s_print(Fore.YELLOW, 'MQTT topic: ', topic, Fore.RESET)

                mqtt_communication.publish(mqtt_client, topic, message_to_cart.Message_Packed, QoS=2, DEBUG=False)

        print_counter = 1
        s_print('Waiting for cart', tracked_cart_name, 'to change tracks. Actual: ', tracked_cart['track_actual'])
        while tracked_cart['track_actual'] != route[0]:
            db_ok, tracked_cart = db_communication.getCart(tracked_cart_name)
            if tracked_cart['track_actual'] == route[0]:
                route = route[1:]
                break

            if len(route) < 2 and len(route) >= 1 and tracked_cart['speed'] != CART_LIGHTRED_EXUCED_SPEED:
                message_to_cart.Velocity = CART_LIGHTRED_EXUCED_SPEED
                # message_to_cart.pack('FR01', USE_STRUCT_MODULE)
                message_to_cart.pack(USE_STRUCT_MODULE)
                if UDP_ENABLED:
                    udp_communication.transmitDataUDP(cart_choosen_udp[0], cart_choosen_udp[1], 5005, message_to_cart.Message_Packed, MESSAGE_TYPE = 0, USE_B85=False, DEBUG=False)
                else:
                    mqtt_communication.publish(mqtt_client, topic, message_to_cart.Message_Packed, QoS=2, DEBUG=False)

                reducing_tries += 1

            if len(route) < 2 and len(route) >= 1 and tracked_cart['speed'] == CART_LIGHTRED_EXUCED_SPEED and reducing_tries != 0:
                s_print(Fore.YELLOW, 'Cart', tracked_cart_name, 'reduced speed, tries:', reducing_tries, Fore.RESET)
                reducing_tries = 0

            if tracked_cart['speed'] == CART_STOP:
                if UDP_ENABLED:
                    udp_communication.transmitDataUDP(cart_choosen_udp[0], cart_choosen_udp[1], 5005, message_to_cart.Message_Packed, MESSAGE_TYPE = 0, USE_B85=False, DEBUG=False)
                else:
                    mqtt_communication.publish(mqtt_client, topic, message_to_cart.Message_Packed, QoS=2, DEBUG=False)

                starting_tries += 1

            if tracked_cart['speed'] != CART_STOP and starting_tries != 0:
                s_print(Fore.YELLOW, 'Cart', tracked_cart_name, 'started after', starting_tries, 'tries', Fore.RESET)
                starting_tries = 0

            s_print(print_counter, ', ', end='', flush=True)
            print_counter += 1
            sleep(0.1)

        s_print()
    #---------------- Cart in order starting point -------------
    s_print(Fore.LIGHTCYAN_EX, tracked_cart['name'], 'reached route end', Fore.RESET)
    stopping_tries = 1
    while (1):  # ADD EMERGENCY EXIT
        message_to_cart.Velocity = CART_STOP
        message_to_cart.Direction = 0
        # message_to_cart.pack('FR01', USE_STRUCT_MODULE)
        message_to_cart.pack(USE_STRUCT_MODULE)
        if UDP_ENABLED:
            udp_communication.transmitDataUDP(cart_choosen_udp[0], cart_choosen_udp[1], 5005, message_to_cart.Message_Packed, MESSAGE_TYPE = 0, USE_B85=False)
        else:
            mqtt_communication.publish(mqtt_client, topic, message_to_cart.Message_Packed, QoS=2, DEBUG=False)
            sleep(0.01)

        db_ok, tracked_cart = db_communication.getCart(tracked_cart_name)
        if tracked_cart['speed'] == CART_STOP:
            s_print(Fore.YELLOW, 'Cart', tracked_cart_name, 'stopped after', stopping_tries, 'tries.',Fore.RESET)
            break

        stopping_tries += 1

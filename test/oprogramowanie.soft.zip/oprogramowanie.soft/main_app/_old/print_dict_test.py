def print_dict(dictionary, prefix = None, suffix = None):
    longest = 0
    for key in dictionary:
        if len(key) > longest:
            longest = len(key)
    if prefix != None and isinstance(prefix, str):
        print(prefix)
    for key in dictionary:
        print(key, end='')
        for x in range(longest+5-len(key)):
            print(" ", end='')
        print(dictionary[key], "\n", end='')
    if suffix != None and isinstance(suffix, str):
        print(suffix)

    
hotkeys_dict = {        
        'print db_output'       : 'shift+d+1',

        'print frame_01'        : 'shift+f+1',
        'print frame_02'        : 'shift+f+2',
        'print frame_03'        : 'shift+f+3',

        'mqtt DEBUG'            : 'shift+m+0',
        'mqtt LOGGING'          : 'shift+m+1',
        'print mqtt_output'     : 'shift+m+2',

        'DEBUG LEVEL 0'         : 'shift+d+0',
        'DEBUG LEVEL 1'         : 'shift+d+1',
        'DEBUG LEVEL 2'         : 'shift+d+2',


        'print clients_messages': 'shift+c+1',

        # 'respects'              : 'shift+f',
        'hotkey_list'           : 'shift+h'
    }


print_dict(hotkeys_dict, prefix = '# HOTKEYS #', suffix  = '################')
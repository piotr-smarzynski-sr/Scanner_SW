import psycopg2

USER = "piotr"
PASSWORD = "admin"
HOST = "127.0.0.1"
PORT = "5432"
DATABASE = "rollercoaster"

def insert(table, variables, values, DEBUG=False):
    """
    Insert record in database
    Return: True if ok
    1) variables and values needs to be in the same order.
    2) DEBUG prints SQL query
    """
    if len(variables) == 0 or len(variables) != len(values):
        print("Wrong length of variables: ", len(
            variables), "or values: ", len(values))
        return False

    connection = psycopg2.connect(user=USER,
                                  password=PASSWORD,
                                  host=HOST,
                                  port=PORT,
                                  database=DATABASE)

    dbCoursor = connection.cursor()

    sql_query = "INSERT INTO " + table + "("
    x = 0
    for var in variables:
        sql_query += var
        if x == len(variables) - 1:
            sql_query += ")"
        else:
            sql_query += ", "
        x = x + 1

    sql_query += " VALUES ("

    x = 0
    for val in values:
        sql_query += "'"
        sql_query += val
        if x == len(values) - 1:
            sql_query += "')"
        else:
            sql_query += "', "
        x = x + 1

    if DEBUG == True:
        print('SQL QUERY: ', sql_query)
    dbCoursor.execute(sql_query)
    connection.commit()
    dbCoursor.close()
    connection.close()
    return True

def update(table, variables, values, where_variables, where_values, DEBUG=False, UNSAFE_UPDATE=False):
    """
    Update record in database
    Return: True if ok
    1) variables and values needs to be in the same order.
    2) where_variables and where_values needs to be in the same order.
    3) DEBUG prints SQL query
    4) UNSAFE_UPDATE allows to update without WHERE (all records in table). USE WITH CAUTION
    """
    if UNSAFE_UPDATE == False or len(where_variables) > 0 or len(where_values):
        if len(variables) == 0 or len(variables) != len(values):
            print("Wrong length of variables: ", len(
                variables), "or values: ", len(values))
            return False
    
    # if DEBUG:
    #     print('variables: ', variables)
    #     print('values: ', values)

    connection = psycopg2.connect(user=USER,
                                  password=PASSWORD,
                                  host=HOST,
                                  port=PORT,
                                  database=DATABASE)

    dbCoursor = connection.cursor()
    sql_query = "UPDATE " + table + " SET "
    for x in range(len(variables)):
        sql_query += variables[x]
        sql_query += "="
        if isinstance(values[x], str):
            sql_query += "'"
            sql_query += values[x]

        if not isinstance(values[x], str):
            sql_query += str(values[x])

        if isinstance(values[x], str):
            sql_query += "'"

        if x == len(variables) - 1:
            sql_query += " "
        else:
            sql_query += ", "

    if UNSAFE_UPDATE == False or len(where_variables) > 0 or len(where_values):
        sql_query += "WHERE "

        for x in range(len(where_variables)):
            sql_query += where_variables[x]
            sql_query += "="
            if isinstance(where_values[x], str):
                sql_query += "'"
            sql_query += where_values[x]
            if isinstance(where_values[x], str):
                sql_query += "'"

            if x == len(where_variables) - 1:
                sql_query += " "
            else:
                sql_query += " AND "

    if DEBUG == True:
        print('SQL QUERY: ', sql_query)
    dbCoursor.execute(sql_query)
    connection.commit()
    dbCoursor.close()
    connection.close()
    return True

def select(table, where_variables, where_values, Select_variables = '*', ORDER_BY='', Fetch = 'one', DEBUG=False):
    """
    Select whole record from database
    Return: dictionary
    1) where_variables and where_values needs to be in the same order.
    2) ORDER_BY is optional string argument that needs to be in SQL syntax
    3) DEBUG prints SQL query and SELECT output dictionary
    """
    Fetch = Fetch.lower()
    output = {}
    if len(where_variables) != len(where_values):
        print("Wrong length of variables: ", len(
            where_variables), "or values: ", len(where_values))
        return False, output

    connection = psycopg2.connect(user=USER,
                                  password=PASSWORD,
                                  host=HOST,
                                  port=PORT,
                                  database=DATABASE)

    dbCoursor = connection.cursor()
    
    # This must stay until finishing coding select with specific variables
    Select_variables = '*'

    if Select_variables == '*':
        sql_query = "SELECT * FROM " + table + " WHERE "
    else:
        sql_query = "SELECT "
        Select_variables_counter = 0
        for variable in Select_variables:
            sql_query += variable
            if Select_variables_counter < len(Select_variables) - 1:
                sql_query += ", "
            else: 
                sql_query += " "

    for x in range(len(where_variables)):
        sql_query += where_variables[x]
        sql_query += " = "

        if isinstance(where_values[x], str):
            sql_query += "'"
        sql_query += where_values[x]
        if isinstance(where_values[x], str):
            sql_query += "'"

        if x == len(where_variables) - 1:
            sql_query += " "
        else:
            sql_query += "AND "

    if ORDER_BY != '':
        sql_query += " ORDER BY " + ORDER_BY

    if DEBUG == True:
        print('SQL QUERY: ', sql_query)
    dbCoursor.execute(sql_query)
    connection.commit()

    if Fetch == 'all':
        select_output = dbCoursor.fetchall()
    if Fetch == 'one':
        select_output = dbCoursor.fetchone()

    if DEBUG == True:
        print('SQL OUTPUT: ', select_output)
    
    if isinstance(select_output, dict) or isinstance(select_output, list) or isinstance(select_output, tuple):
        if len(select_output)>0:
            sql_query = "SELECT column_name FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = '" + table + "'"
            dbCoursor.execute(sql_query)
            connection.commit()
            column_names = dbCoursor.fetchall()
            # if DEBUG:
            #     print('column_names: ', column_names)
            #     print('select_output: ', select_output)

            x = 0
            for x in range(len(column_names)):
                column_names[x] = str(column_names[x])
                column_names[x] = column_names[x].strip(",()'")

            if Fetch == 'one':
                for x in range(len(column_names)):
                    output[column_names[x]] = select_output[x]

            if Fetch == 'all':
                output_list = []
                output_dict = {}
                for x in range(len(select_output)):
                    output_dict = {}
                    for y in range(len(select_output[x])):
                        output_dict[column_names[y]] = select_output[x][y]
                    output_list.append(output_dict)
                output = output_list

            # if DEBUG == True:
            #     print('column_names: ', column_names)
            #     if Fetch == 'one':
            #         print('select_output: ', select_output)
        else:
            # if DEBUG == True:
            #     print("Empty output from Select")
            pass

    dbCoursor.close()
    connection.close()
    return True, output

def getAvailableOrders():
    output = {}
    connection = psycopg2.connect(user=USER,
                                password=PASSWORD,
                                host=HOST,
                                port=PORT,
                                database=DATABASE)

    dbCoursor = connection.cursor()
    sql_query = "SELECT * FROM orders WHERE status = 1 OR status = 5 ORDER BY time ASC LIMIT 1"
    dbCoursor.execute(sql_query)
    connection.commit()
    select_output = dbCoursor.fetchone()
    if (isinstance(select_output, list) or isinstance(select_output, tuple)) and len(select_output) > 0:
        sql_query = "SELECT column_name FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = 'orders'"
        dbCoursor.execute(sql_query)
        connection.commit()
        column_names = dbCoursor.fetchall()

        for x in range(len(column_names)):
            column_names[x] = str(column_names[x])
            column_names[x] = column_names[x].strip(",()'")

        for x in range(len(column_names)):
            output[column_names[x]] = select_output[x]

        db_ok = True    
    else:
        db_ok = False

    dbCoursor.close()
    connection.close()
    return db_ok, output

def getAvailableCarts():
    output = {}
    connection = psycopg2.connect(user=USER,
                                password=PASSWORD,
                                host=HOST,
                                port=PORT,
                                database=DATABASE)
    dbCoursor = connection.cursor()
    sql_query = "SELECT * FROM carts WHERE order_no = 0 AND active = true"
    dbCoursor.execute(sql_query)
    connection.commit()
    select_output = dbCoursor.fetchall()
    if len(select_output) > 0:
        
        sql_query = "SELECT column_name FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = 'carts'"
        dbCoursor.execute(sql_query)
        connection.commit()
        column_names = dbCoursor.fetchall()
        for x in range(len(column_names)):
            column_names[x] = str(column_names[x])
            column_names[x] = column_names[x].strip(",()'")

        output_list = []
        output_dict = {}
        for x in range(len(select_output)):
            output_dict = {}
            for y in range(len(select_output[x])):
                output_dict[column_names[y]] = select_output[x][y]
            output_list.append(output_dict)            

        output = output_list
        db_ok = True
    else:
        output = []
        db_ok = False
        
    dbCoursor.close()
    connection.close()
    return db_ok, output

def orderUpdateStatus(ID, status, text_status, DEBUG=False):
    output = False
    types_ok = True
    types_list = []
    types_list.append(isinstance(status, int))
    types_list.append(isinstance(ID, int))
    types_list.append(isinstance(text_status, str))
    for type_item in types_list:
        if type_item == False:
            types_ok = False
    
    if types_ok == True: # po wypracowaniu standardowych tekstowych statusów porównywac tu ze słownikiem / listą    
        connection = psycopg2.connect(user=USER,
                                    password=PASSWORD,
                                    host=HOST,
                                    port=PORT,
                                    database=DATABASE)

        dbCoursor = connection.cursor()        
        sql_query = "UPDATE orders SET status = %s, status_text = %s, updated = now()  WHERE \"ID\" = %s"
        params = (status, text_status, ID)
        dbCoursor.execute(sql_query, params)        
        connection.commit()
        output = True
    else:
        output = False

    return output

def addNewOrder(order_type, start_dest, delivery_dest, cart_type, cart_no, cargo_type=0, status=1, text_status='Ready', DEBUG=False):
    output = False
    types_ok = True
    types_list = []
    types_list.append(isinstance(order_type, int))
    types_list.append(isinstance(start_dest, int))
    types_list.append(isinstance(delivery_dest, int))
    types_list.append(isinstance(cart_type, int))
    types_list.append(isinstance(cart_no, int))
    types_list.append(isinstance(cargo_type, int))
    types_list.append(isinstance(status, int))
    types_list.append(isinstance(text_status, str))
    for type_item in types_list:
        if type_item == False:
            types_ok = False
    
    if types_ok == True: # po wypracowaniu standardowych tekstowych statusów porównywac tu ze słownikiem / listą
        connection = psycopg2.connect(user=USER,
                                    password=PASSWORD,
                                    host=HOST,
                                    port=PORT,
                                    database=DATABASE)
        dbCoursor = connection.cursor()        
        sql_query = "INSERT INTO orders (time, type, start_point, end_point, cargo, cart_type, cart_no, status, status_text) VALUES (now(), %s, %s, %s, %s, %s, %s, %s, %s)"
        params = (order_type, start_dest, delivery_dest, cargo_type, cart_type, cart_no, status, text_status)
        dbCoursor.execute(sql_query, params)
        connection.commit()
        output = True
    else:
        output = False
    
    return output

def cartUpdateOrder(cart_name, order_no):
    types_ok = True
    types_list = []
    types_list.append(isinstance(cart_name, str))
    types_list.append(isinstance(order_no, int))
    for type_item in types_list:
        if type_item == False:
            types_ok = False

    if types_ok == True:
        connection = psycopg2.connect(user=USER,
                            password=PASSWORD,
                            host=HOST,
                            port=PORT,
                            database=DATABASE)

        dbCoursor = connection.cursor()
        sql_query = "UPDATE carts SET order_no = %s, updated = now()  WHERE name = %s"
        params = (order_no, cart_name)
        dbCoursor.execute(sql_query, params)
        connection.commit()
        output = True
    else:
        output = False

    return output

def getCart(cart_name):
    output = {}
    if len(cart_name) < 5 and cart_name[0] == 'C':
        connection = psycopg2.connect(user=USER,
                                    password=PASSWORD,
                                    host=HOST,
                                    port=PORT,
                                    database=DATABASE)

        dbCoursor = connection.cursor()
        sql_query = "SELECT * FROM carts WHERE name = %s"
        params = (cart_name, )
        dbCoursor.execute(sql_query, params)
        connection.commit()
        select_output = dbCoursor.fetchone()
        if isinstance(select_output, list) or isinstance(select_output, tuple):
            sql_query = "SELECT column_name FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = 'carts'"
            dbCoursor.execute(sql_query)
            connection.commit()
            column_names = dbCoursor.fetchall()
            for x in range(len(column_names)):
                column_names[x] = str(column_names[x])
                column_names[x] = column_names[x].strip(",()'")

            for x in range(len(column_names)):
                output[column_names[x]] = select_output[x]

        dbCoursor.close()
        connection.close()
        return True, output
    else:
        return False, output

def getTrack(track_name):
    output = {}
    # if len(track_name) < 5 and track_name[0] == 'T':
    if isinstance(track_name, int):
        connection = psycopg2.connect(user=USER,
                                    password=PASSWORD,
                                    host=HOST,
                                    port=PORT,
                                    database=DATABASE)

        dbCoursor = connection.cursor()
        sql_query = "SELECT * FROM tracks_map WHERE no = %s"
        params = (track_name, )
        dbCoursor.execute(sql_query, params)
        connection.commit()
        select_output = dbCoursor.fetchone()
        if isinstance(select_output, list) or isinstance(select_output, tuple):
            sql_query = "SELECT column_name FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = 'tracks_map'"
            dbCoursor.execute(sql_query)
            connection.commit()
            column_names = dbCoursor.fetchall()
            for x in range(len(column_names)):
                column_names[x] = str(column_names[x])
                column_names[x] = column_names[x].strip(",()'")

            for x in range(len(column_names)):
                output[column_names[x]] = select_output[x]

        dbCoursor.close()
        connection.close()
        return True, output
    else:
        return False, output

def getAllTracks():
    output = {}
    connection = psycopg2.connect(user=USER,
                                password=PASSWORD,
                                host=HOST,
                                port=PORT,
                                database=DATABASE)
    dbCoursor = connection.cursor()
    sql_query = "SELECT * FROM tracks_map"
    dbCoursor.execute(sql_query)
    connection.commit()
    select_output = dbCoursor.fetchall()
    if len(select_output) > 0:
        
        sql_query = "SELECT column_name FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = 'tracks_map'"
        dbCoursor.execute(sql_query)
        connection.commit()
        column_names = dbCoursor.fetchall()
        for x in range(len(column_names)):
            column_names[x] = str(column_names[x])
            column_names[x] = column_names[x].strip(",()'")


        output_list = []
        output_dict = {}
        for x in range(len(select_output)):
            output_dict = {}
            for y in range(len(select_output[x])):
                output_dict[column_names[y]] = select_output[x][y]
            output_list.append(output_dict)            

        output = output_list
        db_ok = True
    else:
        output = []
        db_ok = False
        
    dbCoursor.close()
    connection.close()
    return db_ok, output

def cartsAllUpdateInactive():
    connection = psycopg2.connect(user=USER,
                        password=PASSWORD,
                        host=HOST,
                        port=PORT,
                        database=DATABASE)

    dbCoursor = connection.cursor()
    sql_query = "UPDATE carts SET active = false, speed = 0, updated = now()"
    dbCoursor.execute(sql_query)
    connection.commit()
    output = True
    return output

def getOrder(order_no):
    output = {}
    types_ok = True
    types_list = []
    types_list.append(isinstance(order_no, int))
    for type_item in types_list:
        if type_item == False:
            types_ok = False

    if types_ok == True:
        connection = psycopg2.connect(user=USER,
                            password=PASSWORD,
                            host=HOST,
                            port=PORT,
                            database=DATABASE)

        dbCoursor = connection.cursor()
        sql_query = "SELECT * from orders WHERE \"ID\" = %s"
        params = (order_no,)
        dbCoursor.execute(sql_query, params)
        connection.commit()
        select_output = dbCoursor.fetchone()
        if isinstance(select_output, list) or isinstance(select_output, tuple):
            sql_query = "SELECT column_name FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = 'orders'"
            dbCoursor.execute(sql_query)
            connection.commit()
            column_names = dbCoursor.fetchall()
            for x in range(len(column_names)):
                column_names[x] = str(column_names[x])
                column_names[x] = column_names[x].strip(",()'")

            for x in range(len(column_names)):
                output[column_names[x]] = select_output[x]

        dbCoursor.close()
        connection.close()

        return True, output
    else:
        return False, output

def cartSetInactive(cart_ip, cart_port):
    types_ok = True
    types_list = []
    types_list.append(isinstance(cart_ip, str))
    types_list.append(isinstance(cart_port, int))
    for type_item in types_list:
        if type_item == False:
            types_ok = False

    if types_ok == True:
        connection = psycopg2.connect(user=USER,
                            password=PASSWORD,
                            host=HOST,
                            port=PORT,
                            database=DATABASE)

        dbCoursor = connection.cursor()
        sql_query = "UPDATE carts SET active = false, updated = now()  WHERE ip_address = %s AND port = %s"
        params = (cart_ip, cart_port)
        dbCoursor.execute(sql_query, params)
        connection.commit()
        output = True
    else:
        output = False

    return output

def cartUpdateInfo(name, track_actual, velocity, direction, ip_address, port):
    db_ok = False
    types_ok = True
    types_list = []
    types_list.append(isinstance(name, str))
    types_list.append(isinstance(track_actual, int))
    types_list.append(isinstance(velocity, int))
    types_list.append(isinstance(direction, int))
    types_list.append(isinstance(ip_address, str))
    types_list.append(isinstance(port, int))
    types_list.append(isinstance(direction, int))
    for type_item in types_list:
        if type_item == False:
            types_ok = False

    if types_ok == True:
        connection = psycopg2.connect(user=USER,
                            password=PASSWORD,
                            host=HOST,
                            port=PORT,
                            database=DATABASE)

        dbCoursor = connection.cursor()
        sql_query = "UPDATE carts SET track_actual = %s, speed = %s, direction = %s, ip_address = %s, port = %s, active = true, updated = now()  WHERE name = %s"
        params = (track_actual, velocity, direction, ip_address, port, name)
        dbCoursor.execute(sql_query, params)
        connection.commit()
        db_ok = True
    else:
        db_ok = False

    return db_ok

def test_code():
    # db_ok, output = getAvailableOrders()
    # print('db_ok: ', db_ok)
    # print('output: ', output)
    # print('len(output): ', len(output))

    # db_ok, output = getAvailableCarts()
    # print('db_ok: ', db_ok)
    # print('output: ', output)
    # print('len(output): ', len(output))

    # db_ok = orderUpdateStatus(342, 4, 'NG TEST')
    # print('db_ok: ', db_ok)

    # db_ok = addNewOrder(1, 'T0', 'T5', 2, 0, 3, 4, 'NG_TEST')
    # print('db_ok: ', db_ok)

    # db_ok, output = getCart('C96')
    # print('output: ', output)

    # db_ok, output = getOrder(418)
    # print('output: ', output)

    # db_ok, output = getTrack('T2')
    # print('output: ', output)

    db_ok, allTracks = getAllTracks()
    # print('allTracks: ', allTracks)
    output = ''
    for track in allTracks:
        for key in track:
            output += str(key)
            output += ': '
            output += str(track[key])
            output += '\n'

        print(output)
        output = ''

    # print(allTracks[0])
    # print(allTracks[0]['prev_no'])
    # print(allTracks[0]['prev_no_all'])
    # if allTracks[0]['prev_no'] in allTracks[0]['prev_no_all']:
    #     print('OK')

# test_code()


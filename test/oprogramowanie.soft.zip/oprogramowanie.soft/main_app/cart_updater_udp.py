"""
Module cart_updater_udp - cyclic updates cart info given via UDP in database

Functions:
    cartUpdaterUDP2: Receive cyclic messages from carts over UDP
                     and puts it into 'carts' table in DB.
"""

from queue import Queue
from threading import Thread
from time import time as now

from colorama import init, Fore
from keyboard import is_pressed

from alarms import Alarms
import db_communication
import udp_communication
from other import Timer, getFromQueue
from thread_print import s_print

init(convert=True) #COLORAMA

db_messages_q = Queue()
timeout_q = Queue()

def cartUpdaterUDP2(socket_receive, DEBUG=False):
    """
    Receive cyclic messages from carts over UDP and puts it into 'carts' table in DB.

    Args:
        socket_receive: socket
            UDP socket for receiving data
        DEBUG: bool
            Default: False, switches on additional debug printing

    Returns:
        None

    Raises:
        None
    """
    # Function name for printing
    function_name = Fore.LIGHTCYAN_EX+"cartUpdaterUDP2:"+Fore.RESET
    timer1 = Timer()
    incoming_messages_per_s = 0
    # update all carts in DB as inactive as application start
    db_ok = db_communication.cartsAllUpdateInactive()
    s_print(function_name, Fore.LIGHTCYAN_EX, 'All carts set inactive: ', db_ok, Fore.RESET)
    dbCoursor = db_communication.connection.cursor()
    incoming_counter_printing = False
    while True:
        if DEBUG is True:
            if timer1.fromStart() > 1:
                timer1.reset()
                if incoming_messages_per_s > 0 and incoming_counter_printing:
                    # s_print(function_name, 'incoming_messages_per_s: ', incoming_messages_per_s)
                    pass

                incoming_messages_per_s = 0

        message_rx, ip_address = udp_communication.receiveDataUDP2(socket_receive)
        incoming_messages_per_s += 1
        if message_rx.MSG_TYPE == 0:
            thread_db = Thread(target=db_communication.cartUpdateInfo3,
                               name="thread_db",
                               kwargs={'dbCoursor': dbCoursor,
                                       'cart_no':message_rx.cart_id,
                                       'track_actual':message_rx.track_num,
                                       'track_pos_mm':message_rx.track_offset,
                                       'velocity':message_rx.speed,
                                       'direction':message_rx.direction,
                                       'ip_address':ip_address},
                               daemon=True)

            thread_db.start()
            if db_ok is False:
                s_print(Fore.LIGHTRED_EX, 'Cart info not updated', Fore.RESET)


def cartUpdaterUDP3(socket_receive, queue_db, queue_timeout, queue_alarms, DEBUG=False):
    """
    Receive cyclic messages from carts over UDP and puts it into 'carts' table in DB.

    Args:
        socket_receive: socket
            UDP socket for receiving data
        DEBUG: bool
            Default: False, switches on additional debug printing

    Returns:
        None

    Raises:
        None
    """
    # Function name for printing
    function_name = Fore.LIGHTCYAN_EX+"cartUpdaterUDP3:"+Fore.RESET
    timer1 = Timer()
    incoming_messages_per_s = 0
    # update all carts in DB as inactive as application start
    db_ok = db_communication.cartsAllUpdateInactive()
    s_print(function_name, Fore.LIGHTCYAN_EX, 'All carts set inactive: ', db_ok, Fore.RESET)
    incoming_counter_printing = True
    cart_alarms = []
    all_alarms = []
    while True:
        if DEBUG is True:
            if timer1.fromStart() > 1:
                timer1.reset()
                if incoming_messages_per_s > 0 and incoming_counter_printing:
                    # s_print(function_name, 'incoming_messages_per_s: ', incoming_messages_per_s)
                    incoming_messages_per_s = 0

        message_rx, ip_address, port = udp_communication.receiveDataUDP2(socket_receive)
        # s_print(function_name, 'Alarms:', format(message_rx.alarm,'032b'))
        cart_found = False
        for cart_alarms in all_alarms:
            if isinstance(cart_alarms, Alarms):
                if cart_alarms.subsystem == 'C' and cart_alarms.device_no == message_rx.cart_id:
                    cart_found = True
                    cart_alarms.setAlarmAll(message_rx.alarm)
                    if cart_alarms.alarms_diff != 0:
                        queue_alarms.put(cart_alarms)

        if cart_found is False:
            cart_alarms = Alarms('C', message_rx.cart_id, message_rx.alarm)
            all_alarms.append(cart_alarms)
            queue_alarms.put(cart_alarms)

        incoming_messages_per_s += 1
        queue_db.put((message_rx, ip_address))
        queue_timeout.put((message_rx.cart_id, now()))

def cartUpdaterThreadDB(queue_input, DEBUG=False):
    """
    Receive cyclic messages from queue and puts it into 'carts' table in DB.

    Args:
        queue_input: Queue
            queue for receiving data

    Returns:
        None

    Raises:
        None
    """
    function_name = Fore.LIGHTCYAN_EX+"cartUpdaterThreadDB:"+Fore.RESET
    QUEUE_THRESHOLD = 10
    t1 = Timer()
    dbCoursor = db_communication.connection.cursor()
    while True:
        if queue_input.empty() == False:
            if queue_input.qsize() < QUEUE_THRESHOLD:
                queue_ok, message = getFromQueue(queue_input)
                if queue_ok:
                    message_rx, ip_address = message
                    db_ok = db_communication.cartUpdateInfo2(message_rx.cart_id,
                                                             message_rx.track_num,
                                                             message_rx.track_offset,
                                                             message_rx.speed,
                                                             message_rx.direction,
                                                             ip_address)

            if queue_input.qsize() >= QUEUE_THRESHOLD:
                queue_messages = []
                multi_query = ""
                multi_params = []
                sql_query = "UPDATE carts SET track_actual = %s, track_position = %s, speed = %s, direction = %s, ip_address = %s, active = true, updated = now()  WHERE no = %s;"
                for _ in range(QUEUE_THRESHOLD):
                    queue_ok, message = getFromQueue(queue_input)
                    if queue_ok:
                        message_rx, ip_address = message
                        params = [message_rx.track_num,
                                  message_rx.track_offset,
                                  message_rx.speed,
                                  message_rx.direction,
                                  ip_address,
                                  message_rx.cart_id]

                        queue_messages.append(message)
                        multi_query = multi_query + sql_query
                        for param in params:
                            multi_params.append(param)

                if multi_query != "" and multi_params != []:
                    dbCoursor = db_communication.connection.cursor()
                    dbCoursor.execute(multi_query, multi_params)
                    db_communication.connection.commit()
                    dbCoursor.close()

        if DEBUG is True:
            if t1.fromStart() > 1:
                t1.reset()
                if queue_input.qsize() > 10:
                    s_print(function_name, 'remaining items in queue:', queue_input.qsize())

def cartTimeoutUDP(queue_input, TIMEOUT=3):
    '''
    Thread that sets cart as inactive after timeout - no activity over udp

    Args:
        queue_input: Queue        
            ip_address : str,
            port: int,
            last_updated: time.time

    Returns:
        None

    Raises:
        "cartTimeoutUDP: Cannot get from queue"
    '''
    cart_list = [] # [[ip_address, port, last_updated], [ip_address, port, last_updated], ...]
    t1 = Timer()
    while True:
        # ------- UPDATE SECTION --------
        if queue_input.empty() is False:
            queue_ok, queue_element = getFromQueue(queue_input)
            assert queue_ok is True, "cartTimeoutUDP: Cannot get from queue"
            cart_id, last_updated = queue_element

            cart_found = False
            for cart in cart_list:
                if cart_id == cart[0]:
                    cart[1] = last_updated
                    cart_found = True
                    break
            
            if cart_found is False:
                cart_list.append([cart_id, last_updated])

        # ------- TIMEOUT SECTION --------
        if t1.fromStart() > TIMEOUT: # every TIMEOUT * 1s check all carts
            cart_to_remove = -1
            for index, cart in enumerate(cart_list):
                if now() - cart[1] > TIMEOUT:
                    db_ok = db_communication.cartSetInactive(cart_id=cart[0])
                    s_print('Removing client', cart[0], 'from client list after timeout')
                    if db_ok is True:
                        cart_to_remove = index
                    # break loop, but don't reset timer in case there are more timeouts
                    break

            if cart_to_remove != -1:
                del cart_list[cart_to_remove]

            else:
                # reset timer only if no carts timeouted, 
                # otherwise only one cart could be removed per second
                t1.reset()


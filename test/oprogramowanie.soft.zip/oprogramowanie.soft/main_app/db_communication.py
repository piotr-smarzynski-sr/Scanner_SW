#TODO CONSIDER rozważyc stosowanie jednego globalnego połączenia zamiast tworzenia nowego w razie potrzeby.
# sprawdzic, czy rozwiazanier z jednym polaczeniem będzie bezpieczne dla wątków,
#  sprawdzić rozwiązanie z Lock, zamiast z kolejką
# sprawdzić z with

"""
Module db_communication - interface beetween this application and PostgreSQL database

Functions:
    cartsAllUpdateInactive: Update column 'active' in all carts as false,
                            'speed' as 0 and 'updated' as actual time in all carts.
    cartSetInactive: Update column 'active' in all carts as false,
                     'speed' as 0 and 'updated' as actual time in specific cart in DB.
    cartUpdateOrder: Update order no in specific cart.
    cartUpdateInfo: (Obsolete) Update cart info in db for specific cart.
    cartUpdateInfo2: Update cart info in db for specific cart.
    getAllTracks: Return full map of tracks with parameters.
    getAvailableCarts: Return list of carts without assigned order with parameters.
    getAvailableOrder: Return one available order where status == READY or
                       status == TIMEOUT and is oldest on list. Order is returned with parameters.
    getCart: Return cart of given name.
    getOrder: Return order of given number.
    getTrack: Return track of given number.
    isTrackOccupied: Return carts numbers occupying specific track.
    orderUpdateStatus: Update order status and text status in DB.
    addNewOrder: Save new order into table orders.
"""

import psycopg2
import logging

# from other import Timer # TODO: fix circular import
from thread_print import s_print, getDate, getHour
"""
TODO
save passwords to json and encrypt them
Decrypt passwords in every DB operation
"""

# credentials for DB
USER = "piotr"
PASSWORD = "admin"
HOST = "127.0.0.1"
PORT = "5432"
DATABASE = "rollercoaster"

connection = psycopg2.connect(user=USER,
                              password=PASSWORD,
                              host=HOST,
                              port=PORT,
                              database=DATABASE)

def cartCheckExistence(cart_no):
    """
    Check if cart exists in DB

    Args:
        cart_no : int

    Returns:
        True if SQL query returns any data / False if SQL query returns no data

    Raises:
        None
    """
    assert isinstance(cart_no, int) and (cart_no >= 0), "Bad cart_no value"
    dbCoursor = connection.cursor()
    sql_query = "SELECT 1 FROM carts WHERE no = %s"
    params = (cart_no,)
    dbCoursor.execute(sql_query, params)
    select_output = dbCoursor.fetchall()
    if select_output == []:
        exists = False
    else:
        exists = True
    connection.commit()
    dbCoursor.close()
    return True, exists

def cartsAllUpdateInactive():
    """
    Update column 'active' in all carts as false,
    'speed' as 0 and 'updated' as actual time in all carts.

    Args:
        None

    Returns:
        True

    Raises:
        None
    """
    # connection credentials
    # connection = psycopg2.connect(user=USER,
                                #   password=PASSWORD,
                                #   host=HOST,
                                #   port=PORT,
                                #   database=DATABASE)

    dbCoursor = connection.cursor()
    sql_query = "UPDATE carts SET active = false, speed = 0, track_actual = -1, updated = now()"
    dbCoursor.execute(sql_query)
    connection.commit()
    db_ok = True
    dbCoursor.close()
    # connection.close()
    return db_ok

def cartInsertDefault(cart_no):
    """
    Insert cart with default configuration

    Args:
        cart_no : int

    Returns:
        True

    Raises:
        None
    """
    output = False
    assert isinstance(cart_no, int) and (cart_no >= 0), "Bad cart_no value"
    dbCoursor = connection.cursor()
    sql_query = "INSERT INTO carts (name, description, order_no, order_type, order_task, track_position, type, direction, facing, max_speed, speed, active, updated, ip_address, port, no, track_no, track_actual) VALUES (%s, %s, 0, 0, 0, 0, 0, 1, 1, 10, 0, false, now(), '0.0.0.0', 0, %s, 0, 0)"
    params = ('C'+str(cart_no), 'Cart C'+str(cart_no), cart_no)
    dbCoursor.execute(sql_query, params)
    connection.commit()
    output = True
    dbCoursor.close()
    # connection.close()
    return output

def cartSetInactive(cart_ip=None, cart_port=None, cart_id=None):
    """
    Update specific cart as inactive.

    Args:
        cart_ip: str
            IP addres of specific cart e.g. '192.168.0.25'
        cart_port: int
            Port od specific cart e.g. 60002

        OR

        cart_id: int
            Cart number. If given, cart is searched by ID, not IP and port

    Returns:
        True

    Raises:
        "Bad cart_ip type or value": if IP is not str or in wrong format
        "Bad cart_port type or value": if port is not int or equal or less than 0
        "Bad ID type or value": if cart_id is not int or equal or less than 0
    """

    # check if types of inputs are correct
    if cart_id is None:
        assert (isinstance(cart_ip, str) and (cart_ip.count('.') == 3 or cart_ip == 'localhost')), "Bad cart_ip value"
        assert isinstance(cart_port, int) and cart_port > 0, "Bad port value"
    else:
        assert (isinstance(cart_id, int) and (cart_id > 0)), "Bad ID value"
    # connection credentials
    # connection = psycopg2.connect(user=USER,
                                #   password=PASSWORD,
                                #   host=HOST,
                                #   port=PORT,
                                #   database=DATABASE)

    dbCoursor = connection.cursor()
    #prepare and execute query
    if cart_id is None:
        sql_query = "UPDATE carts SET active = false, updated = now() WHERE ip_address = %s AND port = %s"
        params = (cart_ip, cart_port)
    else:
        sql_query = "UPDATE carts SET active = false, updated = now() WHERE no = %s"
        params = (cart_id,)
    dbCoursor.execute(sql_query, params)
    connection.commit()
    dbCoursor.close()
    # connection.close()
    return True

def cartUpdateOrder(cart_no, order_no):
    """
    Update order no in specific cart.

    Args:
        cart_no: int
            cart number
        order_no: int
            order number to set

    Returns:
        True if input types are ok / False if input types are wrong

    Raises:
        None
    """
    # check if types of inputs are correct
    assert isinstance(cart_no, int) and cart_no > 0, "Bad cart_no value"
    assert isinstance(order_no, int) and order_no >= 0, "Bad order_no value"
    # connection credentials
    # connection = psycopg2.connect(user=USER,
                                #   password=PASSWORD,
                                #   host=HOST,
                                #   port=PORT,
                                #   database=DATABASE)

    dbCoursor = connection.cursor()
    sql_query = "UPDATE carts SET order_no = %s, updated = now()  WHERE no = %s"
    params = (order_no, cart_no)
    dbCoursor.execute(sql_query, params)
    connection.commit()
    dbCoursor.close()
    # connection.close()
    return True

def cartUpdateInfo(cart_no, track_actual, velocity, direction, ip_address, port):
    """
    Update cart info in db for specific cart.

    Args:
        cart_no: int
            cart number e.g. 96
        track_actual: int
            actual track number e.g. 2
        velocity: int
            actual speed [0-255]
        direction: int
            cart direction: 0 - STOP, 1 - FORWARD, 2 - BACKWARD
        ip_address: int
            cart IP address, ex: 192.168.0.25
        port: int
            cart UDP port e.g. 60021

    Returns:
        True if input types are ok / False if input types are wrong

    Raises:
        None
    """
    assert isinstance(cart_no, int) and (cart_no > 0), "Bad cart_no value"
    assert isinstance(track_actual, int) and (track_actual > 0), "Bad track_actual value"
    assert isinstance(velocity, int) and (velocity >= 0), "Bad velocity value"
    assert isinstance(direction, int) and (direction >= 0 and direction <= 2), "Bad direction value"
    assert isinstance(ip_address, str) and (True), "Bad ip_address value"
    assert isinstance(port, int) and (port > 0), "Bad port value"
    # connection = psycopg2.connect(user=USER,
                                #   password=PASSWORD,
                                #   host=HOST,
                                #   port=PORT,
                                #   database=DATABASE)

    dbCoursor = connection.cursor()
    sql_query = "UPDATE carts SET track_actual = %s, speed = %s, direction = %s, ip_address = %s, port = %s, active = true, updated = now()  WHERE no = %s"
    params = (track_actual, velocity, direction, ip_address, port, cart_no)
    dbCoursor.execute(sql_query, params)
    connection.commit()
    dbCoursor.close()
    # connection.close()
    return True

def cartUpdateInfo2(cart_no, track_actual, track_pos_mm, velocity, direction, ip_address):
    """
    Update cart info in db for specific cart.

    Args:
        cart_no: int
            cart number e.g. 96
        track_actual: int
            actual track number e.g. 2
        track_pos_mm: int
            actual position on track in mm from start of segment
        velocity: int
            actual speed [0-255]
        direction: int
            cart direction: 0 - STOP, 1 - FORWARD, 2 - BACKWARD
        ip_address: int
            cart IP address, ex: 192.168.0.25
        port: int
            cart UDP port e.g. 60021

    Returns:
        True if input types are ok / False if input types are wrong

    Raises:
        None
    """
    # types_check_timer = now()
    assert isinstance(cart_no, int) and (cart_no > 0), "Bad cart_no value"
    assert isinstance(track_actual, int), "Bad track_actual value"
    assert isinstance(track_pos_mm, int), "Bad track_pos_mm value"
    assert isinstance(velocity, int) and (velocity >= 0), "Bad velocity value"
    assert isinstance(direction, int) and (direction >= 0 and direction <= 2), "Bad direction value"
    assert isinstance(ip_address, str) and (True), "Bad ip_address value"
    # connection = psycopg2.connect(user=USER,
                                #   password=PASSWORD,
                                #   host=HOST,
                                #   port=PORT,
                                #   database=DATABASE)

    dbCoursor = connection.cursor()

    sql_query = "UPDATE carts SET track_actual = %s, track_position = %s, speed = %s, direction = %s, ip_address = %s, active = true, updated = now()  WHERE no = %s"
    params = (track_actual, track_pos_mm, velocity, direction, ip_address, cart_no)
    dbCoursor.execute(sql_query, params)
    connection.commit()
    dbCoursor.close()
    del dbCoursor
    # connection.close()
    return True

def cartUpdateInfo3(dbCoursor, cart_no, track_actual, track_pos_mm, velocity, direction, ip_address):
    """
    Update cart info in db for specific cart.

    Args:
        cart_no: int
            cart number e.g. 96
        track_actual: int
            actual track number e.g. 2
        track_pos_mm: int
            actual position on track in mm from start of segment
        velocity: int
            actual speed [0-255]
        direction: int
            cart direction: 0 - STOP, 1 - FORWARD, 2 - BACKWARD
        ip_address: int
            cart IP address, ex: 192.168.0.25
        port: int
            cart UDP port e.g. 60021

    Returns:
        True if input types are ok / False if input types are wrong

    Raises:
        None
    """
    # types_check_timer = now()
    assert isinstance(cart_no, int) and (cart_no > 0), "Bad cart_no value"
    assert isinstance(track_actual, int), "Bad track_actual value"
    assert isinstance(track_pos_mm, int), "Bad track_pos_mm value"
    assert isinstance(velocity, int) and (velocity >= 0), "Bad velocity value"
    assert isinstance(direction, int) and (direction >= 0 and direction <= 2), "Bad direction value"
    assert isinstance(ip_address, str) and (True), "Bad ip_address value"
    sql_query = "UPDATE carts SET track_actual = %s, track_position = %s, speed = %s, direction = %s, ip_address = %s, active = true, updated = now()  WHERE no = %s"
    params = (track_actual, track_pos_mm, velocity, direction, ip_address, cart_no)
    # t1 = Timer()
    dbCoursor.execute(sql_query, params)
    connection.commit()
    # s_print('cartUpdateInfo3, db execution time:'+ str(t1.fromStart()))
    return True

def cartUpdateInfoMulti(dbCoursor, cart_no, track_actual, track_pos_mm, velocity, direction, ip_address):
    """
    Update cart info in db for specific cart.

    Args:
        cart_no: int
            cart number e.g. 96
        track_actual: int
            actual track number e.g. 2
        track_pos_mm: int
            actual position on track in mm from start of segment
        velocity: int
            actual speed [0-255]
        direction: int
            cart direction: 0 - STOP, 1 - FORWARD, 2 - BACKWARD
        ip_address: int
            cart IP address, ex: 192.168.0.25
        port: int
            cart UDP port e.g. 60021

    Returns:
        True if input types are ok / False if input types are wrong

    Raises:
        None
    """
    # types_check_timer = now()
    assert isinstance(cart_no, int) and (cart_no > 0), "Bad cart_no value"
    assert isinstance(track_actual, int), "Bad track_actual value"
    assert isinstance(track_pos_mm, int), "Bad track_pos_mm value"
    assert isinstance(velocity, int) and (velocity >= 0), "Bad velocity value"
    assert isinstance(direction, int) and (direction >= 0 and direction <= 2), "Bad direction value"
    assert isinstance(ip_address, str) and (True), "Bad ip_address value"
    sql_query = "UPDATE carts SET track_actual = %s, track_position = %s, speed = %s, direction = %s, ip_address = %s, active = true, updated = now()  WHERE no = %s"
    params = (track_actual, track_pos_mm, velocity, direction, ip_address, cart_no)
    # t1 = Timer()
    dbCoursor.execute(sql_query, params)
    connection.commit()
    # s_print('cartUpdateInfo3, db execution time:'+ str(t1.fromStart()))
    return True

def getAllTracks():
    """
    Return full map of tracks with parameters.

    Args:
        None

    Returns:
        True if SQL query returns any data / False if SQL query returns no data
        If first return is True:
            List of tracks where every track is dictionary
            with keys identical as columns in DB in table tracks_map
        If first return is False:
            []

    Raises:
        None
    """
    output = {}
    # connection = psycopg2.connect(user=USER,
                                #   password=PASSWORD,
                                #   host=HOST,
                                #   port=PORT,
                                #   database=DATABASE)
    dbCoursor = connection.cursor()
    sql_query = "SELECT * FROM tracks_map"
    dbCoursor.execute(sql_query)
    connection.commit()
    select_output = dbCoursor.fetchall()
    if len(select_output) > 0:

        sql_query = "SELECT column_name FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = 'tracks_map'"
        dbCoursor.execute(sql_query)
        connection.commit()
        column_names = dbCoursor.fetchall()
        for index, value in enumerate(column_names):
            value = str(value)
            column_names[index] = value.strip(",()'")

        output_list = []
        output_dict = {}
        for x in range(len(select_output)):
            output_dict = {}
            for y in range(len(select_output[x])):
                output_dict[column_names[y]] = select_output[x][y]
            output_list.append(output_dict)

        output = output_list
        db_ok = True
    else:
        output = []
        db_ok = True

    dbCoursor.close()
    # connection.close()
    return db_ok, output

def getAvailableCarts():
    """
    Return list of carts without assigned order with parameters.

    Args:
        None

    Returns:
        True if SQL query returns any data / False if SQL query returns no data
        If first return is True:
            List of carts where every cart is dictionary
            with keys identical as columns in DB in table carts
        If first return is False:
            []

    Raises:
        None
    """

    output = {}
    # connection = psycopg2.connect(user=USER,
                                #   password=PASSWORD,
                                #   host=HOST,
                                #   port=PORT,
                                #   database=DATABASE)
    dbCoursor = connection.cursor()
    sql_query = "SELECT * FROM carts WHERE order_no = 0 AND active = true"
    dbCoursor.execute(sql_query)
    connection.commit()
    select_output = dbCoursor.fetchall()
    if len(select_output) > 0:

        sql_query = "SELECT column_name FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = 'carts'"
        dbCoursor.execute(sql_query)
        connection.commit()
        column_names = dbCoursor.fetchall()
        for index, value in enumerate(column_names):
            value = str(value)
            column_names[index] = value.strip(",()'")

        output_list = []
        output_dict = {}
        for x in range(len(select_output)):
            output_dict = {}
            for y in range(len(select_output[x])):
                output_dict[column_names[y]] = select_output[x][y]
            output_list.append(output_dict)

        output = output_list
        db_ok = True
    else:
        output = []
        db_ok = True

    dbCoursor.close()
    # connection.close()
    return db_ok, output


def getAvailableOrder():
    """
    Return one available order where status == READY or
    status == TIMEOUT and is oldest on list. Order is returned with parameters.

    Args:
        None

    Returns:
        True if SQL query returns any data / False if SQL query returns no data
        If first return is True:
            Dictionary with keys identical as columns in DB in table orders
        If first return is False:
            []

    Raises:
        None
    """
    output = {}
    # connection = psycopg2.connect(user=USER,
                                #   password=PASSWORD,
                                #   host=HOST,
                                #   port=PORT,
                                #   database=DATABASE)

    dbCoursor = connection.cursor()
    sql_query = "SELECT * FROM orders WHERE status = 1 OR status = 5 ORDER BY time ASC LIMIT 1"
    dbCoursor.execute(sql_query)
    connection.commit()
    select_output = dbCoursor.fetchone()
    if (isinstance(select_output, list) or isinstance(select_output, tuple)) and len(select_output) > 0:
        sql_query = "SELECT column_name FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = 'orders'"
        dbCoursor.execute(sql_query)
        connection.commit()
        column_names = dbCoursor.fetchall()

        for index, value in enumerate(column_names):
            value = str(value)
            column_names[index] = value.strip(",()'")

        for x in range(len(column_names)):
            output[column_names[x]] = select_output[x]

    dbCoursor.close()
    # connection.close()
    return True, output

def getCart(cart_name):
    """
    Return cart of given name.

    Args:
        cart_name: int or str
            if int then cart_name is  e.g. 96
            if str the cart_name is  e.g. 'C96'

    Returns:
        True if input data type is ok / False if input data type is wrong
        If first return is True:
            Dictionary with keys identical as columns in DB in table carts
        If first return is False:
            []

    Raises:
        None
    """
    output = {}
    assert ((isinstance(cart_name, int) and cart_name > 0) or (isinstance(cart_name, str) and cart_name[0] == 'C')), "Bad cart_name value"
    # connection = psycopg2.connect(user=USER,
                                #   password=PASSWORD,
                                #   host=HOST,
                                #   port=PORT,
                                #   database=DATABASE)

    if isinstance(cart_name, str) and len(cart_name) < 5 and cart_name[0] == 'C':
        dbCoursor = connection.cursor()
        sql_query = "SELECT * FROM carts WHERE name = %s"

    elif isinstance(cart_name, int) and cart_name > 0:
        dbCoursor = connection.cursor()
        sql_query = "SELECT * FROM carts WHERE no = %s"

    params = (cart_name, )
    dbCoursor.execute(sql_query, params)
    connection.commit()
    select_output = dbCoursor.fetchone()
    if isinstance(select_output, list) or isinstance(select_output, tuple):
        sql_query = "SELECT column_name FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = 'carts'"
        dbCoursor.execute(sql_query)
        connection.commit()
        column_names = dbCoursor.fetchall()
        for index, value in enumerate(column_names):
            value = str(value)
            column_names[index] = value.strip(",()'")

        for x in range(len(column_names)):
            output[column_names[x]] = select_output[x]

    dbCoursor.close()
    # connection.close()
    return True, output

def getOrder(order_no):
    """
    Return order of given number.

    Args:
        order_no: int
            order number e.g. 486

    Returns:
        True if input data type is ok / False if input data type is wrong
        If first return is True:
            Dictionary with keys identical as columns in DB in table carts
        If first return is False:
            {}

    Raises:
        None
    """
    assert (isinstance(order_no, int) and order_no > 0), "Bad order_no value"
    output = {}
    # connection = psycopg2.connect(user=USER,
                                #   password=PASSWORD,
                                #   host=HOST,
                                #   port=PORT,
                                #   database=DATABASE)

    dbCoursor = connection.cursor()
    sql_query = "SELECT * from orders WHERE \"ID\" = %s"
    params = (order_no,)
    dbCoursor.execute(sql_query, params)
    connection.commit()
    select_output = dbCoursor.fetchone()
    if isinstance(select_output, list) or isinstance(select_output, tuple):
        sql_query = "SELECT column_name FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = 'orders'"
        dbCoursor.execute(sql_query)
        connection.commit()
        column_names = dbCoursor.fetchall()
        for index, value in enumerate(column_names):
            value = str(value)
            column_names[index] = value.strip(",()'")

        for x in range(len(column_names)):
            output[column_names[x]] = select_output[x]

    dbCoursor.close()
    # connection.close()
    return True, output

def getTrack(track_name):
    """
    Return track of given number.

    Args:
        track_name: int
            track_name is  e.g. 4

    Returns:
        True if input data type is ok / False if input data type is wrong
        If first return is True:
            Dictionary with keys identical as columns in DB in table tracks_map
        If first return is False:
            {}

    Raises:
        None
    """
    assert isinstance(track_name, int), "Bad track_name"
    output = {}
    # connection = psycopg2.connect(user=USER,
                                #   password=PASSWORD,
                                #   host=HOST,
                                #   port=PORT,
                                #   database=DATABASE)

    dbCoursor = connection.cursor()
    sql_query = "SELECT * FROM tracks_map WHERE no = %s"
    params = (track_name, )
    dbCoursor.execute(sql_query, params)
    connection.commit()
    select_output = dbCoursor.fetchone()
    if isinstance(select_output, list) or isinstance(select_output, tuple):
        sql_query = "SELECT column_name FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = 'tracks_map'"
        dbCoursor.execute(sql_query)
        connection.commit()
        column_names = dbCoursor.fetchall()
        for index, value in enumerate(column_names):
            value = str(value)
            column_names[index] = value.strip(",()'")

        for x in range(len(column_names)):
            output[column_names[x]] = select_output[x]

    dbCoursor.close()
    # connection.close()
    return True, output

def isTrackOccupied(track_name):
    """
    Return carts numbers occupying specific track.

    Args:
        track_name: int
            track_name is  e.g. 4

    Returns:
        True if input data type is ok / False if input data type is wrong
        If first return is True:
            List with cart numbers
        If first return is False:
            {}

    Raises:
        None
    """
    assert isinstance(track_name, int), "Bad track_name"
    select_output = {}
    # connection = psycopg2.connect(user=USER,
                                #   password=PASSWORD,
                                #   host=HOST,
                                #   port=PORT,
                                #   database=DATABASE)

    dbCoursor = connection.cursor()
    sql_query = "SELECT no FROM carts WHERE track_actual = %s"
    params = (track_name, )
    dbCoursor.execute(sql_query, params)
    connection.commit()
    select_output = dbCoursor.fetchall()
    if len(select_output) != 0:
        select_output = select_output[0]

    dbCoursor.close()
    # connection.close()
    return True, select_output


def orderUpdateStatus(ID, status, text_status, DEBUG=False):
    """
    Update order status and text status in DB.

    Args:
        ID: int
            ID (order number)  e.g. 214
        status: int
            Numerical status according to order state according to order_status.py e.g. 1
        text_status: str
            Text status according to order state according to order_status.py e.g. 'READY'
        DEBUG: bool
            Default: False, switches on additional debug printing

    Returns:
        True if input data type is ok / False if input data type is wrong

    Raises:
        None
    """
    assert isinstance(ID, int) and (ID > 0), "Bad ID value"
    assert isinstance(status, int), "Bad status value"
    assert isinstance(text_status, str), "Bad text_status value"
    output = False
    # connection = psycopg2.connect(user=USER,
                                #   password=PASSWORD,
                                #   host=HOST,
                                #   port=PORT,
                                #   database=DATABASE)

    dbCoursor = connection.cursor()
    sql_query = "UPDATE orders SET status = %s, status_text = %s, updated = now()  WHERE \"ID\" = %s"
    params = (status, text_status, ID)
    dbCoursor.execute(sql_query, params)
    connection.commit()
    output = True
    dbCoursor.close()
    # connection.close()
    return output

def setAlarm(subsystem, device_no, code, DEBUG=False):
    assert isinstance(subsystem, str) and (len(subsystem) == 1), "Bad subsystem value"
    assert isinstance(device_no, int) and (device_no >= 0), "Bad device_no value"
    assert isinstance(code, int) and (code >= 0), "Bad code value"
    dbCoursor = connection.cursor()
    if DEBUG:
        print('subsystem, device_no, code: ', subsystem, device_no, code)
    # sprawdzenie, czy alarm o danym subsystemie+numerze urządzenia+kodzie i cause_active == true istnieje w tabeli alarms_current
    #------------- INSERT / UPDATE CURRENT ----------------
    sql_query = """SELECT \"ID\" FROM alarms_current
                   WHERE subsystem= %s AND device_no = %s AND code = %s AND cause_active = true
                   ORDER BY raise_time DESC
                   LIMIT 1;"""
    params = (subsystem, device_no, code)
    dbCoursor.execute(sql_query, params)
    connection.commit()
    select_output = dbCoursor.fetchone()
    if DEBUG:
        print('Check if record exists in alarms_current: ', select_output)
    # jeśli tak:
    if select_output is not None:
        select_output = {'ID': select_output[0]}
        if DEBUG:
            print("Update cause_gone_time = Null for ID=", select_output['ID'])
        # aktualizuj cause_gone_time = None
        sql_query = "UPDATE alarms_current SET cause_gone_time = Null WHERE \"ID\"= %s"
        params = (select_output['ID'],)
        dbCoursor.execute(sql_query, params)
        connection.commit()
    # jeśli nie:
    if select_output is None:
        if DEBUG:
            print('Add new record in alarms_current')
        # dodaj nowy wiersz w tabeli alarms_current
        sql_query = """INSERT INTO alarms_current
                            (subsystem, device_no, code, cause_active, raise_time)
                       VALUES
                            (%s, %s, %s, true, now());"""
        params = (subsystem, device_no, code)
        dbCoursor.execute(sql_query, params)
        connection.commit()

    # sprawdzenie, czy alarm o danym subsystemie+numerze urządzenia+kodzie i raise_time == alarms_current istnieje w tabeli alarms_history
    #------------- INSERT / UPDATE HISTORY ----------------
    sql_query = """SELECT \"ID\" FROM alarms_history
                   WHERE subsystem= %s AND
                         device_no = %s AND
                         code = %s AND
                         raise_time = (SELECT raise_time FROM alarms_current
                                       WHERE subsystem= %s AND
                                             device_no = %s AND
                                             code = %s AND
                                             cause_active = true
                                       ORDER BY raise_time DESC
                                       LIMIT 1);"""
    params = (subsystem, device_no, code, subsystem, device_no, code)
    dbCoursor.execute(sql_query, params)
    connection.commit()
    select_output = dbCoursor.fetchone()
    if DEBUG:
        print('Check if record exists in alarms_history: ', select_output)
    # jeśli tak:
    if select_output is not None:
        # aktualizuj cause_gone_time i ack_time na Null
        select_output = {'ID': select_output[0]}
        if DEBUG:
            print("Update cause_gone_time = Null and ack_time = Null for ID=", select_output['ID'])

        sql_query = """UPDATE alarms_history
                       SET cause_gone_time = Null, ack_time = Null
                       WHERE \"ID\"= %s;"""
        params = (select_output['ID'],)
        dbCoursor.execute(sql_query, params)
        connection.commit()
    # jeśli nie:
    if select_output is None:
        if DEBUG:
            print('Add new record in alarms_history')
        # dodaj nowy wiersz w tabeli alarms_history
        sql_query = """INSERT INTO alarms_history
                            (subsystem, device_no, code, raise_time)
                       VALUES(%s, %s, %s,
                             (SELECT raise_time from alarms_current
                              WHERE subsystem = %s AND
                                    device_no = %s AND
                                    code = %s AND
                                    cause_active = true
                              ORDER BY raise_time DESC LIMIT 1));"""
        params = (subsystem, device_no, code, subsystem, device_no, code)
        dbCoursor.execute(sql_query, params)
        connection.commit()

    dbCoursor.close()
    return True


def resetAlarm(subsystem, device_no, code, DEBUG=False):
    """
    Set alarm in alarms_current table in DB

    Args:
        subsystem: str
            Single-letter name of subsystem: C/S/J/M
        device_no: int
            number of device with error
        code: int
            number of error

    Returns:
        None

    Raises:
        Assertion error: bad data type or out of range
    """
    assert isinstance(subsystem, str) and (len(subsystem) == 1), "Bad subsystem value"
    assert isinstance(device_no, int) and (device_no >= 0), "Bad device_no value"
    assert isinstance(code, int) and (code >= 0), "Bad code value"
    dbCoursor = connection.cursor()
    if DEBUG:
        print('subsystem, device_no, code: ', subsystem, device_no, code)
    # sprawdzenie, czy alarm o danym subsystemie+numerze urządzenia+kodzie+cause_active=true istnieje w tabeli alarms_current
    #------------- INSERT / UPDATE CURRENT ----------------
    sql_query = """SELECT \"ID\" FROM alarms_current
                   WHERE subsystem= %s AND device_no = %s AND code = %s AND cause_active = true
                   ORDER BY raise_time DESC
                   LIMIT 1;"""
    params = (subsystem, device_no, code)
    dbCoursor.execute(sql_query, params)
    connection.commit()
    select_output = dbCoursor.fetchone()
    if DEBUG:
        print('Check if record exists in alarms_current: ', select_output)

    # jeśli tak:
    if select_output is not None:
        select_output = {'ID': select_output[0]}
        # aktualizuj kolumnę cause_active na false i cause_gone_time na aktualny czas
        if DEBUG:
            print("Update cause_active = false, cause_gone_time = now() for ID=", select_output['ID'])
        sql_query = """UPDATE alarms_current
                       SET cause_active = false, cause_gone_time = now()
                       WHERE \"ID\"= %s;"""

        params = (select_output['ID'],)
        dbCoursor.execute(sql_query, params)
        connection.commit()
    # jeśli nie:
    if select_output is None:
        # sprawdź, czy alarm o danym kodzie istnieje w tabeli alarms_history z cause_gone_time IS NULL
        sql_query = """SELECT \"ID\" FROM alarms_history
                    WHERE subsystem= %s AND
                            device_no = %s AND
                            code = %s AND
                            cause_gone_time IS NOT NULL
                    ORDER BY raise_time DESC
                    LIMIT 1;"""
        params = (subsystem, device_no, code)
        dbCoursor.execute(sql_query, params)
        connection.commit()
        select_output = dbCoursor.fetchone()
        if DEBUG:
            print('Check if matching unacknowledged record exists in alarms_history: ', select_output)
        # jeśli tak:
        if select_output is not None:
            # Dodaj alarm z kolumną cause_active na false, raise_time = alarms_history i cause_gone_time na aktualny czas
            if DEBUG:
                print('Add new record in alarms_current with raise time from alarm_history')
            sql_query = """INSERT INTO alarms_current
                                (subsystem, device_no, code, cause_active, raise_time, cause_gone_time)
                           VALUES
                                (%s, 
                                 %s, 
                                 %s, 
                                 false, 
                                 (SELECT raise_time FROM alarms_history
                                  WHERE "ID" = %s), 
                                  now());"""
            params = (subsystem, device_no, code, select_output[0])
            dbCoursor.execute(sql_query, params)
            connection.commit()

        # jeśli nie:
        if select_output is None:
            # Dodaj alarm z kolumną cause_active na false, raise_time na aktualny czas i cause_gone_time na aktualny czas
            if DEBUG:
                print('Add new record in alarms_current')
            sql_query = """INSERT INTO alarms_current
                                (subsystem, device_no, code, cause_active, raise_time, cause_gone_time)
                        VALUES
                                (%s, %s, %s, false, now(), now());"""
            params = (subsystem, device_no, code)
            dbCoursor.execute(sql_query, params)
            connection.commit()

    # sprawdzenie, czy alarm o danym subsystemie+numerze urządzenia+kodzie, raise_time == alarms_current istnieje w tabeli alarms_history
    #------------- INSERT / UPDATE HISTORY ----------------
    sql_query = """SELECT \"ID\" FROM alarms_history
                   WHERE subsystem= %s AND
                         device_no = %s AND
                         code = %s AND
                         raise_time = (SELECT raise_time FROM alarms_current
                                       WHERE subsystem= %s AND
                                             device_no = %s AND
                                             code = %s AND
                                             cause_active = false
                                       ORDER BY raise_time DESC
                                       LIMIT 1);"""
    params = (subsystem, device_no, code, subsystem, device_no, code)
    dbCoursor.execute(sql_query, params)
    connection.commit()
    select_output = dbCoursor.fetchone()
    if DEBUG:
        print('Check if record exists in alarms_history: ', select_output)

    # jeśli tak:
    if select_output is not None:
        select_output = {'ID': select_output[0]}
        # aktualizuj cause_gone_time na aktualny czas
        if DEBUG:
            print("Update cause_gone_time = now() for ID=", select_output['ID'])
        sql_query = """UPDATE alarms_history
                       SET cause_gone_time = (SELECT cause_gone_time FROM alarms_current
                                              WHERE subsystem= %s AND
                                                    device_no = %s AND
                                                    code = %s AND
                                                    cause_active = false
                                              ORDER BY cause_gone_time DESC
                                              LIMIT 1)
                       WHERE \"ID\"= %s;"""

        params = (subsystem, device_no, code, select_output['ID'],)
        dbCoursor.execute(sql_query, params)
        connection.commit()

    # jeśli nie:
    if select_output is None:
        # dodaj nowy wiersz w tabeli alarms_history z cause_gone_time na aktualny czas i raise_time == alarms_current gdzie cause_gone_time jest najnowsze i subsystem i inne sie zgadzają
        if DEBUG:
            print('Add new record in alarms_history')
        sql_query = """INSERT INTO alarms_history
                            (subsystem, device_no, code, raise_time, cause_gone_time)
                       VALUES
                            (%s,
                             %s,
                             %s,
                             (SELECT raise_time FROM alarms_current
                              WHERE subsystem= %s AND
                                    device_no = %s AND
                                    code = %s AND
                                    cause_active = false
                              ORDER BY cause_gone_time DESC
                              LIMIT 1),
                             (SELECT cause_gone_time FROM alarms_current
                              WHERE subsystem= %s AND
                                    device_no = %s AND
                                    code = %s AND
                                    cause_active = false
                              ORDER BY cause_gone_time DESC
                              LIMIT 1));"""
        params = (subsystem, device_no, code, subsystem, device_no, code, subsystem, device_no, code)
        dbCoursor.execute(sql_query, params)
        connection.commit()

    dbCoursor.close()
    return True

def acknowledgeAllAlarms():
    """
    Delete alarms with cause gone from alarms_current and update them in alarms_history

    Args:
        None

    Returns:
        None

    Raises:
        Assertion error: bad data type or out of range
    """
    # usunięcie wszystkich rekordów z tabeli alarms_current, które mają wartość cause_active == false
    # aktualizacja wszystkich rekordów, które mają uzupełnioną kolumnę cause_gone_time i nieuzupełnioną ack_time na ack_time = now()
    dbCoursor = connection.cursor()

    sql_query = """DELETE FROM alarms_current WHERE cause_active IS false;"""
    dbCoursor.execute(sql_query)
    connection.commit()
    sql_query = """UPDATE alarms_history SET ack_time = now() WHERE cause_gone_time IS NOT NULL AND ack_time IS NULL;"""
    dbCoursor.execute(sql_query)
    connection.commit()
    dbCoursor.close()
    return True

def displayAlarmsCurrent(lang='EN'):
    """
    Print alarms from alarms_current table

    Args:
        None

    Returns:
        alarms: list
            [ {subsystem: int, code: int, raise_time: time, PL/EN/DE:str, ...}, {...}]

    Raises:
        Assertion error: bad data type or out of range
    """
    assert isinstance(lang, str), "Bad lang type"
    assert lang == 'EN' or lang == 'PL' or lang == 'DE', "Bad lang value"
    if lang != 'EN' and lang != 'PL' and lang != 'DE':
        raise ValueError('Unhandled language: '+lang+'. Accepted: EN DE PL')
    dbCoursor = connection.cursor()
    sql_query = """SELECT alarms_current.subsystem,
                          alarms_current.device_no,
                          alarms_current.code,
                          alarms_description.\""""+lang+"""\",
                          alarms_current.cause_active,
                          alarms_current.raise_time,
                          alarms_current.cause_gone_time
                   FROM alarms_current
                   INNER JOIN alarms_description
                   ON alarms_description.subsystem=alarms_current.subsystem and
                      alarms_description.code=alarms_current.code
                   ORDER BY alarms_current.raise_time DESC;"""

    params = (lang,)
    dbCoursor.execute(sql_query)
    connection.commit()
    select_output = dbCoursor.fetchall()
    dbCoursor.close()
    return True, select_output

def displayAlarmsHistory(lang='EN'):
    """
    Print alarms from alarms_history table

    Args:
        None

    Returns:
        alarms: list
            [ {subsystem: int, code: int, raise_time: time, PL/EN/DE:str, ...}, {...}]

    Raises:
        Assertion error: bad data type or out of range
    """
    assert isinstance(lang, str), "Bad lang type: "+str(type(str))
    assert lang == 'EN' or lang == 'PL' or lang == 'DE', "Bad lang value"
    if lang != 'EN' and lang != 'PL' and lang != 'DE':
        raise ValueError('Unhandled language: '+lang+'. Accepted: EN DE PL')
    dbCoursor = connection.cursor()
    sql_query = """SELECT alarms_history.subsystem,
                        alarms_history.device_no,
                        alarms_history.code,
                        alarms_description.\""""+lang+"""\",
                        alarms_history.raise_time,
                        alarms_history.cause_gone_time,
                        alarms_history.ack_time

                   FROM alarms_history
                   INNER JOIN alarms_description
                   ON alarms_description.subsystem=alarms_history.subsystem and
                      alarms_description.code=alarms_history.code
                   ORDER BY alarms_history.raise_time DESC; """

    # params = (lang,)
    dbCoursor.execute(sql_query)
    connection.commit()
    select_output = dbCoursor.fetchall()
    dbCoursor.close()
    return True, select_output


def addNewOrder(order_type, start_dest, delivery_dest, cart_type, cart_no=0, cargo_type=0, status=1, text_status='Ready', DEBUG=False):
    """
    Save new order into table orders.

    Args:
        order_type: int
            type of order (not yet determined)
        start_dest: int
            track number where order starts
        delivery_dest: int
            track number where order ends
        cart_type: int
            required cart type
        cart_no: int
            Default: 0, specific cart number if required
        cargo_type: int
            Default: 0, specific cargo type if required
        status: int
            Default: 1, numerical status according to
            order state according to order_status.py e.g. 1
        text_status: str
            Default: 'Ready', text status according to
            order state according to order_status.py e.g. 'READY'
        DEBUG: bool
            Default: False, switches on additional debug printing

    Returns:
        True if input data type is ok / False if input data type is wrong

    Raises:
        None
    """
    output = False
    assert isinstance(order_type, int) and (order_type >= 0), "Bad order_type value"
    assert isinstance(start_dest, int) and (start_dest >= 0), "Bad start_dest value"
    assert isinstance(delivery_dest, int) and (delivery_dest >= 0), "Bad delivery_dest value"
    assert isinstance(cart_type, int) and (cart_type >= 0), "Bad cart_type value"
    assert isinstance(cart_no, int) and (cart_no >= 0), "Bad cart_no value"
    assert isinstance(cargo_type, int) and (cargo_type >= 0), "Bad cargo_type value"
    assert isinstance(status, int), "Bad status value"
    assert isinstance(text_status, str), "Bad text_status value"
    # connection = psycopg2.connect(user=USER,
                                #   password=PASSWORD,
                                #   host=HOST,
                                #   port=PORT,
                                #   database=DATABASE)
    dbCoursor = connection.cursor()
    sql_query = "INSERT INTO orders (time, type, start_point, end_point, cargo, cart_type, cart_no, status, status_text) VALUES (now(), %s, %s, %s, %s, %s, %s, %s, %s)"
    params = (order_type, start_dest, delivery_dest, cargo_type, cart_type, cart_no, status, text_status)
    dbCoursor.execute(sql_query, params)
    connection.commit()
    output = True
    dbCoursor.close()
    # connection.close()
    return output

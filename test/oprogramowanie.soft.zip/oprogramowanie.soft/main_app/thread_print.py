"""
Module thread_print - thread-safe printing

Functions:
    getDate: return date in string format
    getHour: return time in string format
    s_print: Thread-safe printing
"""

import re
from threading import Lock
import logging
from datetime import datetime
from colorama import init, Fore

init(convert=True) #COLORAMA

s_print_lock = Lock()


# 7-bit C1 ANSI sequences
ansi_escape = re.compile(r'''
    \x1B  # ESC
    (?:   # 7-bit C1 Fe (except CSI)
        [@-Z\\-_]
    |     # or [ for CSI, followed by a control sequence
        \[
        [0-?]*  # Parameter bytes
        [ -/]*  # Intermediate bytes
        [@-~]   # Final byte
    )
''', re.VERBOSE)


def getDate():
    """
    return date in string format

    Args:
        None
    Returns:
        date_and_time: str

    Raises:
        None
    """
    now = datetime.now() # current date and time
    return now.strftime("%Y%m%d_%H%M%S")

def getHour():
    """
    return time in string format

    Args:
        None
    Returns:
        time: str

    Raises:
        None
    """
    now = datetime.now() # current date and time
    return now.strftime("%H:%M:%S")

def s_print(*a, **b):
    """
    Thread-safe printing

    Args:
        Same as print()
    Returns:
        None

    Raises:
        None
    """
    global s_print_lock
    """Thread safe print function"""
    with s_print_lock:
        print(*a, **b)
        output = ''
        for argument in a:
            output += str(argument)
            output += ' '
        if output.strip() != '':
            # logging.info(getHour() +' '+ ansi_escape.sub('', output))
            pass


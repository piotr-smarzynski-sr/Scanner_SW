"""
Module other - other functions

Functions:
    aliveThreadsChecker: Thread periodically checks if other threads are alive.
        If necessary, thread is destroyed.

    print_dict: Nice dictionary printing.
    randomString: Generate a random string of fixed length.
    str_list: Converts all elements from list to strings.
    getFromQueue: Safely get from queue.
    ordersExampleSave: Save predefined order to database.
    keyboardHandler: Thread for handling keyboard shortcuts.
"""
import queue
from queue import Queue
import random as r
from string import ascii_lowercase
from time import sleep

from colorama import init, Fore

import db_communication
from thread_print import s_print

init(convert=True) #COLORAMA
queued_printer_q = Queue()
hotkeys_dict = {
    'Order and cart prepare': 'o+1',
    'Orders get available'  : 'o+2',
    'Carts get available'   : 'o+3',
    'hotkey_list'           : 'h+1',
    'GetIP'                 : 'f+1',
    'GetRSSI'               : 'f+2',
    'GetSSID'               : 'f+3',
    'GetWiFiChannel'        : 'f+4',
    'GetWiFiStatus'         : 'f+5'
    }

init(convert=True) #COLORAMA

class RunEnabler(object):
    """Object that can enable work for another thread
    """
    def __init__(self, enable):
        self.enable = enable

class Timer(object):
    """
    class with simple timer functionality

    Methods:
        fromStart: Time in seconds from object creation or from last reset
        reset: set timer start from now
        waitFor: block execution for specified anmount of seconds
    """
    from time import time as now

    def __init__(self):
        self.start_time = self.now()

    def fromStart(self):
        """
        Returns time in seconds from start or last reset.

        Args:
            None

        Returns:
            time_from_start: float

        Raises:
            None
        """
        return self.now() - self.start_time

    def reset(self):
        """
        Set timer start to now.

        Args:
            None

        Returns:
            None

        Raises:
            None
        """
        self.start_time = self.now()

    def waitFor(self, time_wait):
        """
        Block code execution for specified time.

        Args:
            time_wait: float
                Time in seconds to wait

        Returns:
            None

        Raises:
            None
        """
        wait_end = self.fromStart() + time_wait
        while self.fromStart() < wait_end:
            pass

def aliveThreadsChecker(threads, run_enable):
    """
    Thread periodically checks if other threads are alive. If necessary, thread is destroyed.

    Args:
        threads: list
            list of alive threads

    Returns:
        None

    Raises:
        None
    """
    function_name = Fore.LIGHTCYAN_EX+"aliveThreadsChecker:"+Fore.RESET
    # sleep(5)
    while True:
        if run_enable.enable is True:
            found = False
            for thread in threads:
                # Jak nie jest alive to juz nie jest w głównej pętli,
                # a uruchomiony musiał zostac wcześniej
                if thread.is_alive() is False and thread.name != 'socketCreator':
                    s_print(function_name,
                            Fore.LIGHTRED_EX+ 'Thread',
                            thread.name,
                            'not alive, deleting from list',
                            Fore.RESET)
                    threads.remove(thread)
                    found = True
                    break

            if found is True:
                output = 'Alive threads:'
                for thread in threads:
                    output += ' '
                    output += thread.name

                s_print(function_name, output)
        sleep(1)

def minTupleIndex(input_list, search_index):
    """
    Finding minimal index in list in format [(route, cost), (route, cost) ..].

    Args:
        input_list: list
            list in format [(route, cost), (route, cost) ..],
            at least one value in tuples must be int
        search_index: int
            index in tuple to search

    Returns:
        out_index: int
            index of element with minimal indicated tuple element

    Raises:
        None
    """
    buffer = []
    for element in input_list:
        buffer.append(element[search_index])

    out_index = buffer.index(min(buffer))
    return out_index

def print_dict(dictionary, prefix=None, suffix=None):
    """
    Nice dictionary printing.

    Args:
        dictionary: dictionary
            dictionary to print
        prefix: str
            Default: None, string for print before dictionary
        suffix: str
            Default: None, string for print after dictionary

    Returns:
        None

    Raises:
        None
    """
    longest = 0
    output = ''
    if len(dictionary) > 0:
        for key in dictionary:
            if len(key) > longest:
                longest = len(key)
        if prefix is not None and isinstance(prefix, str):
            output += prefix
            output += '\n'
        for key in dictionary:
            output += key
            for _ in range(longest+5-len(key)):
                output += " "
            if not isinstance(dictionary[key], str):
                output += str(dictionary[key])
            else:
                output += dictionary[key]
            output += "\n"
        if suffix is not None and isinstance(suffix, str):
            output += suffix
    else:
        if prefix is not None and isinstance(prefix, str):
            output += prefix
            output += "EMPTY DICT"
        else:
            output += "-------EMPTY DICT-------"
        s_print("{}")
        output += "{}"
        if suffix is not None and isinstance(suffix, str):
            s_print(suffix)
            output += suffix
        else:
            output += "-------EMPTY DICT-------"

    s_print(output)

def queueToStr(queue):
    """Convert queue to list
    Args:
        queue: Queue
            input queue
    Returns:
        output: list
            queue converted to list

    Raises:
        None
    """
    output = ''
    for n in list(queue.queue):   # convert queue to list
        output += str(n)
        output += ' '                    # separate every list element by space

    return output

def randomString(stringLength=10):
    """
    Generate a random string of fixed length.

    Args:
        stringLength: int
            Default: 10, length of random string

    Returns:
        string

    Raises:
        None
    """
    letters = ascii_lowercase
    return ''.join(r.choice(letters) for i in range(stringLength))

def str_list(list_input): # jeśłi nieużywane, usunąć
    """
    Converts all elements from list to strings.

    Args:
        list_input: list
            input list

    Returns:
        list_output: str
            list of strings

    Raises:
        None
    """

    list_output = []
    for element in list_input:
        if not isinstance(element, str):
            element = str(element)
        list_output.append(element)
    return list_output

def getFromQueue(queue_input):
    """
    Safely get from queue.

    Args:
        queue_input: Queue
            input queue

    Returns:
        queue_ok: bool
        queue_element: any

    Raises:
        None
    """
    try:
        # False jako argment: zamiast blokować, wywalamy wyjątek jak nie ma wiadomości w kolejce
        data = queue_input.get(False)
        return True, data
    except queue.Empty:
        print('EXCEPTION: Cannot get item from queue')
        return False, None

def ordersExampleSave():
    """
    Save predefined order to database.

    Args:
        None

    Returns:
        None

    Raises:
        None
    """
    test_order_count = 0
    s_print('\n', 'Order example save, ', hotkeys_dict['Order example save'], 'shortcut')
    db_ok = db_communication.addNewOrder(2,
                                         5,
                                         0,
                                         7,
                                         0,
                                         cargo_type=6,
                                         status=1,
                                         text_status='Test_'+str(test_order_count),
                                         DEBUG=True)
    test_order_count += 1
    if db_ok is False:
        s_print('db_ok: ', db_ok)

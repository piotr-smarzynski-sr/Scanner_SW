'''Planned moving some functions to own modules
'''
# TODO CONSIDER zdecydować czy ta i podobne funkcje mają byc w other czy poza
from thread_print import s_print

def print_dict(dictionary, prefix = None, suffix = None): 
    '''Nice dictionary printing - actually unused
    '''
    longest = 0
    output = ''
    if len(dictionary) > 0:
        for key in dictionary:
            if len(key) > longest:
                longest = len(key)
        if prefix != None and isinstance(prefix, str):
            output += prefix
        for key in dictionary:
            output += key
            for x in range(longest+5-len(key)):
                output += " "
            output += dictionary[key]
            output += "\n"
        if suffix != None and isinstance(suffix, str):
            output += suffix
    else:
        if prefix != None and isinstance(prefix, str):
            output += prefix
            output += "EMPTY DICT"
        else: 
            output += "-------EMPTY DICT-------"
        s_print("{}")
        output += "{}"
        if suffix != None and isinstance(suffix, str):
            s_print(suffix)
            output += suffix
        else: 
            output += "-------EMPTY DICT-------"
    
    s_print(output)
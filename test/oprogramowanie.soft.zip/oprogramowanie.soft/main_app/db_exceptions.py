"""
Module db_exceptions - exceptions thrown in db_communication module

Classes:
    InputDBDataError: Exception raised for errors in the input data
    BadIP: Exception raised for errors in the IP address
"""
class InputDBDataError(Exception):
    """Exception raised for errors in the input data.

    Attributes:
        data -- input data which caused the error
        message -- explanation of the error
    """

    def __init__(self, data, message="Bad input data"):
        self.data = data
        self.message = message

    def __str__(self):
        return f'{self.data} ({type(self.data)}) -> {self.message}'

class BadIP(Exception):
    """Exception raised for errors in the IP address.

    Attributes:
        data -- input data which caused the error
        message -- explanation of the error
    """
    def __init__(self, data, message='Bad IP address'):
        self.data = data
        self.message = message

    def __str__(self):
        return f'{self.data} ({type(self.data)}) -> {self.message}'

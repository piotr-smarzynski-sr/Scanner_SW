"""
Module orders_queued - threads definitions for managing physical part of the system

Classes:
    Cart: Class for tracked cart info
    SubCartControllerMessageTx: Class for tx messages to carts

Functions:
    alarmsHandlerSQL: Thread periodically checks for alarms change and updates them in database
    ordersCheck: Thread periodically checks for new orders in database
    ordersHandlerSQL: Thread periodically checks for orders updates and commits them to database
    cartHandlerSQL: Thread periodically checks for cart updates and commits them to database
    stationHandlerSQL: Thread periodically checks for station updates and commits them to database
    cartDispatcher: Thread assign new orders to carts and handles event on tracks
    subCartController: Thread controls cart over TCP and receives messages from it
"""

import socket
from queue import Queue
from time import sleep
from time import time as now
import sys

from colorama import Fore, init

import db_communication
import other
from pathfinder.simple_pathfinding import pathfinderInit
from tcp_communication import queues as queues_for_sub_cart_controllers
from thread_print import s_print
from orders_functions import newOrderHandler, routeDoneHandler, sensorObstacleHandler
from orders_functions import subCartControllerQueueHandler
from orders_functions import subCartControllerCollisionCheck
from orders_functions import messageSender
from orders_functions import receivedMessagesHandler
from orders_functions import localQueueToOutputQueue
from other import getFromQueue, Timer

UDP_ENABLED = True
UDP_DISABLED = False
ORDERS_DEBUG = False
USE_STRUCT_MODULE = True
DONT_USE_STRUCT_MODULE = False
USE_B85 = False
FACING_BEGIN = 1
FACING_END = 0
CART_REDUCED_SPEED = 5
CART_FULL_SPEED = 25
CART_STOP = 0
HEADERSIZE = 7
ORDER_TIMEOUT = 30

init(convert=True) #COLORAMA
# {'ID': order_no, 'time_start': order_accepted_time}
cart_dispatcher_from_orders_check_q = Queue()

# {'subsystem': 'C'/'S'/'J', 'ID': device_no, alarm: alarms bit chain, 'alarm_last': last alarms}
alarm_handler_sql_q = Queue()

cart_dispatcher_from_station_check_q = Queue()

# 'cart_name command text' {'ID': cart_name, 'command': command}
cart_dispatcher_from_sub_cart_controller_q = Queue()

# {'ID': cart_name, 'command': 'order'/'status'/'status_text',
# 'parameter': order_no/status/status_text}
cart_handler_sql_from_cart_dispatcher_q = Queue()

# {'ID': order_no, 'status': order_status, 'status_text': order_status_text}
orders_handler_sql_q = Queue()

# {'ID': station_name, 'command': 'order'/'status'/'status_text',
# 'parameter': order_no/status/status_text}
station_handler_sql_from_sub_station_controller_q = Queue()


class Cart(object):
    """
    Class for tracked cart info

    Attributes:
        name: int
            Tracked cart no
        on_route: bool
            Does cart has assigned route?
        direction: int
            Direction of cart: 0 - STOP, 1 - FWD, 2 - BWD
        collision_front: bool
            Are there obstacles in front of cart?
        collision_back: bool
            Are there obstacles in back of cart?
        db_info: dict
            Cart info from database

    Methods:
        updateDBInfo: Update cart info from DB
        setDirection: Set direction of cart
    """
    def __init__(self, name, on_route, direction, collision_front, collision_back):
        self.name = name
        self.on_route = on_route
        self.direction = direction
        self.collision_front = collision_front
        self.collision_back = collision_back
        self.db_info = {}
        self.track_actual = None
        self.speed = None

    def updateDBInfo(self, db_info):
        '''
        updateDBInfo
            Update cart info from DB
            Args:
                db_info: dict
            Returns:
                None
        '''
        self.db_info = db_info
        self.setDirection(self.db_info['direction'])
        self.track_actual = db_info['track_actual']
        self.speed = db_info['speed']

    def setDirection(self, direction):
        '''
        setDirection
            Set direction of cart
            Args:
                direction: int
            Returns:
                None
        '''
        if direction >= 0 and direction <= 2:
            self.direction = direction
        else:
            print('Cart '+ self.name + ' wrong direction set: ' + direction)

class SubCartControllerMessageTx(object):
    """
    Class for tx messages to carts

    Attributes:
        messages: Queue
            Queue of messages in msg module format

    Methods:
        addMessage: put message into queue
        getMessage: get message from queue
        ifMessages: Check if there are messages in queue
    """
    def __init__(self):
        self.messages = Queue()

    def addMessage(self, message):
        '''
        addMessage
            put message into queue
            Args:
                message: msg payload class object
            Returns:
                None
        '''
        self.messages.put(message)

    def getMessage(self):
        '''
        getMessage
            get message from queue
            Args:
                None
            Returns:
                queue_element: msg payload class object OR None if queue is empty
        '''
        if self.messages.empty() is False:
            queue_ok, element = getFromQueue(self.messages)
            if queue_ok:
                return element
            else:
                return None

    def ifMessages(self):
        '''
        ifMessages
            Check if there are messages in queue
            Args:
                None
            Returns:
                True if messages in queue OR False if no messages in queue
        '''
        messages_waiting = False
        if self.messages.empty() is False:
            messages_waiting = True
        else:
            messages_waiting = False

        return messages_waiting

def alarmHandlerSQL(queue_input):
    '''
    alarmsHandlerSQL
        Thread periodically checks for alarms change and updates them in database
    Args:
        queue_input: Queue of dict
            {'subsystem': str
             'ID': int
             'alarm': int
             'alarm_last': int

    Returns:
        None

    Raises
        None
    '''
    while True:
        if queue_input.empty() is False:
            queue_ok, queue_element = getFromQueue(queue_input)
            if queue_ok is True:
                for index, value in queue_element.diff_list:
                    if value == 1:
                        # print('index, value: ', index, value)
                        db_communication.setAlarm(queue_element.subsystem,
                                                  queue_element.device_no,
                                                  index,
                                                  DEBUG=True)
                    elif value == 0:
                        # print('index, value: ', index, value)
                        db_communication.resetAlarm(queue_element.subsystem,
                                                    queue_element.device_no,
                                                    index,
                                                    DEBUG=False)


def ordersCheck(queue_for_cart_dispatcher, queue_for_orders_handler_sql):
    """
    Thread periodically checks for new orders in database

    Args:
        queue_for_cart_dispatcher: Queue
            queue where new orders are passed
        queue_for_orders_handler_sql: Queue
            queue for changing new orders statuses
    Returns:
        None

    Raises:
        None
    """
    function_name = Fore.LIGHTCYAN_EX+"ordersCheck:"+Fore.RESET
    while True:
        # TODO w warunkach wyszukiwania zlecen dodać timeouty
        db_ok, ordersCheckOutput = db_communication.getAvailableOrder()
        if len(ordersCheckOutput) > 0:
            s_print(function_name, 'ordersCheck: ', db_ok, 'order no: ', ordersCheckOutput['ID'])
            queue_for_cart_dispatcher.put({
                'ID': ordersCheckOutput['ID'],
                'time_start': now()
            })
            db_communication.orderUpdateStatus(ordersCheckOutput['ID'], 2, 'Accepted')

        sleep(0.2)

def ordersHandlerSQL(queue_input):
    """
    Thread periodically checks for orders updates and commits them to database

    Args:
        queue_input: Queue
            queue for changing new orders statuses
    Returns:
        None

    Raises:
        None
    """
    function_name = Fore.LIGHTCYAN_EX+"ordersHandlerSQL:"+Fore.RESET
    while True:
        if queue_input.empty() is False:
            queue_element = queue_input.get()
            if queue_element['ID'] > 0:
                db_ok = db_communication.orderUpdateStatus(queue_element['ID'],
                                                           queue_element['status'],
                                                           queue_element['status_text'])
                if db_ok is False:
                    s_print(function_name, 'Cannot update order: ', queue_element)
            else:
                s_print(function_name, Fore.LIGHTRED_EX, 'Wrong order no', Fore.RESET)

        sleep(0.2)

def cartHandlerSQL(queue_input):
    """
    Thread periodically checks for cart updates and commits them to database

    Args:
        queue_input: Queue
            queue for changing new cart statuses
    Returns:
        None

    Raises:
        None
    """
    #queue = {'ID': cart_name, 'command': 'order'/'status'/'status_text',
    #         'parameter': order_no/status/status_text}
    function_name = Fore.LIGHTCYAN_EX+"cartHandlerSQL:"+Fore.RESET
    while True:
        if queue_input.empty() is False:
            queue_ok, queue_element = other.getFromQueue(queue_input)
            if queue_ok:
                if 'order' in queue_element['command']:
                    db_ok = db_communication.cartUpdateOrder(queue_element['ID'],
                                                             queue_element['parameter'])
                    if db_ok is False:
                        s_print(function_name, 'Cannot update cart: ', queue_element)
                if 'status_text' in queue_element['command']:
                    # FUTURE FEATURE
                    s_print(function_name, queue_element['command'], '# FUTURE FEATURE')
                    # db_ok = db_communication.cartUpdateStatusText(
                    #           queue_element['ID'], queue_element['parameter'])
                    # if db_ok is False:
                    #     s_print(function_name, 'Cannot update cart: ', queue_element)
                if 'status' in queue_element['command']:
                    # FUTURE FEATURE
                    s_print(function_name, queue_element['command'], '# FUTURE FEATURE')
                    # db_ok = db_communication.cartUpdateStatus(
                    #           queue_element['ID'], queue_element['parameter'])
                    # if db_ok is False:
                    #     s_print(function_name, 'Cannot update cart: ', queue_element)

        sleep(0.2)

def subJunctionController(connection, junction_name, queue_input, queue_output):
    """TCP connection and messenger to specific junction
    """
    pass

def stationHandlerSQL(queue_input):
    """
    Thread periodically checks for station updates and commits them to database

    Args:
        queue_input: Queue
            queue for changing new station statuses
    Returns:
        None

    Raises:
        None
    """
    #queue = {'ID': cart_name, 'command': 'order'/'status'/'status_text',
    #         'parameter': order_no/status/status_text}
    function_name = Fore.LIGHTCYAN_EX+"stationHandlerSQL:"+Fore.RESET
    while True:
        if queue_input.empty() is False:
            queue_ok, queue_element = other.getFromQueue(queue_input)
            if queue_ok:
                if 'order' in queue_element['command']:
                    # FUTURE FEATURE
                    s_print(function_name, queue_element['command'], '# FUTURE FEATURE')
                    # db_ok = db_communication.stationUpdateOrder(queue_element['ID'],
                    #                                       queue_element['parameter'])
                    # if db_ok is False:
                    #     s_print(function_name, 'Cannot update station: ', queue_element)
                elif 'status_text' in queue_element['command']:
                    # FUTURE FEATURE
                    s_print(function_name, queue_element['command'], '# FUTURE FEATURE')
                    # db_ok = db_communication.stationUpdateStatusText(queue_element['ID'],
                    #                                               queue_element['parameter'])
                    # if db_ok is False:
                    #     s_print(function_name, 'Cannot update station: ', queue_element)
                elif 'status' in queue_element['command']:
                    # FUTURE FEATURE
                    s_print(function_name, queue_element['command'], '# FUTURE FEATURE')
                    # db_ok = db_communication.stationUpdateStatus(queue_element['ID'],
                    #                                               queue_element['parameter'])
                    # if db_ok is False:
                    #     s_print(function_name, 'Cannot update station: ', queue_element)

        sleep(0.2)

def subStationController(queue_output):
    """TCP connection and messenger to specific station
    """
    pass

def cartDispatcher(queue_from_orders_check,
                   queue_from_station_check,
                   queue_for_cart_handler_sql,
                   queue_from_sub_cart_controller,
                   queue_for_order_handler_sql):
    """
    Thread assign new orders to carts and handles event on tracks
    FUTURE FEATURE: junction setting, handling messages from stations

    Args:
        queue_from_orders_check: Queue
            queue with incoming orders
        queue_from_station_check: Queue
            queue with station events
        queue_for_cart_handler_sql: Queue
            queue for updating cart statuses
        queue_from_sub_cart_controller: Queue
            feedback queue from carts
        queue_for_order_handler_sql: Queue
            queue for updating order statuses

    Returns:
        None

    Raises:
        None
    """
    function_name = Fore.LIGHTCYAN_EX+"cartDispatcher:"+Fore.RESET
    # timer1 = Timer()
    tracks_map, pathfinder = pathfinderInit()
    while True:
        #--------------------- NEW ORDERS HANDLE ---------------------
        #{'ID': order_no, 'time_start': order_accepted_time}
        if queue_from_orders_check.empty() is False:
            newOrderHandler(function_name,
                            queue_from_orders_check,
                            queue_for_cart_handler_sql,
                            queue_for_order_handler_sql,
                            queues_for_sub_cart_controllers,
                            pathfinder)
        #--------------------- SUB CART CONTROLLER MESSAGES FROM QUEUE ---------------------
        # {'ID': cart_name, 'command': command}
        if queue_from_sub_cart_controller.empty() is False:
            queue_ok, message = other.getFromQueue(queue_from_sub_cart_controller)
            if queue_ok:
                s_print(function_name, 'message: ', message['ID'], message['command'])
                #----------- ROUTE DONE HANDLE -----------------
                if 'route done' == message['command']:
                    routeDoneHandler(function_name,
                                     message,
                                     queue_for_order_handler_sql,
                                     queue_for_cart_handler_sql,
                                     queues_for_sub_cart_controllers,
                                     pathfinder)
                #----------- OBSTACLE HANDLE -----------------
                elif 'obstacle' == message['command']:
                    sensorObstacleHandler(function_name,
                                          message, queue_for_order_handler_sql,
                                          queues_for_sub_cart_controllers,
                                          pathfinder)
                elif 'GetIP' == message['command']:
                    for queue in queues_for_sub_cart_controllers:
                        queue_dict = {'ID': queue[0], 'command': 'GetIP', 'parameters': {}}
                        queue[1].put(queue_dict)
                elif 'GetRSSI' == message['command']:
                    for queue in queues_for_sub_cart_controllers:
                        queue_dict = {'ID': queue[0], 'command': 'GetRSSI', 'parameters': {}}
                        queue[1].put(queue_dict)
                elif 'GetSSID' == message['command']:
                    for queue in queues_for_sub_cart_controllers:
                        queue_dict = {'ID': queue[0], 'command': 'GetSSID', 'parameters': {}}
                        queue[1].put(queue_dict)
                elif 'GetWiFiChannel' == message['command']:
                    for queue in queues_for_sub_cart_controllers:
                        queue_dict = {'ID': queue[0], 'command': 'GetWiFiChannel', 'parameters': {}}
                        queue[1].put(queue_dict)
                elif 'GetWiFiStatus' == message['command']:
                    for queue in queues_for_sub_cart_controllers:
                        queue_dict = {'ID': queue[0], 'command': 'GetWiFiStatus', 'parameters': {}}
                        queue[1].put(queue_dict)
                elif 'sent' in message['command']:
                    s_print(function_name, message)
                else:
                    s_print(function_name,
                            Fore.LIGHTRED_EX,
                            'unexpected command in queue:',
                            Fore.RESET, message)
                    raise ValueError('unexpected command in queue')

        #------------ TESTING -----------------------
        # testing2(timer1, tcp_communication.queues)
        sleep(0.01)

def subCartController(connection, tracked_cart_name, queue_input, queue_output):
    """
    Thread controls cart over TCP and receives messages from it

    Args:
        connection: TCPMessagingConnection
            interface to connect, send and receive data over TCP
        queue_input: list
            [cart_name:int, queue_commands:Queue]
        queue_output: Queue
            feedback queue for cart dispatcher
        tracked_cart_name: int
            number od cart assigned to this thread

    Returns:
        None

    Raises:
        None
    """
    function_name = Fore.LIGHTCYAN_EX+"subCartController"+Fore.RESET+str(tracked_cart_name)+":"
    cart = Cart(tracked_cart_name,
                on_route=False,
                direction=0,
                collision_front=False,
                collision_back=False)
    messages_tx = SubCartControllerMessageTx()
    collision_timer = Timer()
    kill_yourself = False
    queue_local = Queue()
    while True:
        try:
            # -------------- ROUTE QUEUE HANDLE AND MESSAGE PREPARE ---------------
            if queue_input[1].empty() is False and cart.on_route is False:
                kill_yourself = subCartControllerQueueHandler(function_name,
                                                              cart, messages_tx,
                                                              queue_input[1],
                                                              queue_local)

            # -------------- COLLISION CHECK --------------------------------------
            if collision_timer.fromStart() > 0.1:
                collision_timer.reset()
                # subCartControllerCollisionCheck(cart, messages_tx)
                # detectCollisions(cart, messages_tx)

            #-------------- TCP RECEIVE -------------------------------------------
            messages_rx = connection.receiveMessages()

            #------------- RECEIVED MESSAGES HANDLE -------------------------------
            receivedMessagesHandler(messages_rx, messages_tx, cart, queue_local)

            #------------- HANDLE LOCAL QUEUE -------------------------------------
            localQueueToOutputQueue(queue_local, queue_output)

            #------------- SEND PREPARED MESSAGES ---------------------------------
            if messages_tx.ifMessages() is True:
                messageSender(messages_tx, connection)

            #------------- KILL THREAD VIA QUEUE COMMAND --------------------------
            if kill_yourself is True:
                s_print(function_name, Fore.LIGHTRED_EX, 'killed!', Fore.RESET)
                break

        except socket.error as e:
            if e.errno == socket.errno.WSAECONNRESET:
                # https://docs.python.org/3/library/socket.html#socket-timeouts
                # In non-blocking mode, operations fail
                # (with an error that is unfortunately system-dependent)
                # if they cannot be completed immediately:
                #     functions from the select can be used to know when
                #     and whether a socket is available for reading or writing.

                s_print(function_name, Fore.LIGHTRED_EX, 'CONNECTION BROKEN', Fore.RESET)
                db_communication.cartSetInactive(cart_id=cart.name)
                break

    connection.connectionClose()

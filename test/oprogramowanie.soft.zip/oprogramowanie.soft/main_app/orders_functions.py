"""
Module orders_functions - functions for handling orders

Functions:
    sensorObstacleHandler: Handles unexpected obstacles that cart reports.
    sensedObstacleWhenTravellingToEnd: Handles unexpected obstacles
        that cart reports when cart travels to end of order.

    sensedObstacleWhenTravellingToStart: Handles unexpected obstacles
        that cart reports when cart travels to start of order.

    cartEndedRouteInStartPoint: Handles event when cart arrives to order start point.
    cartEndedRouteInStartPoint: Handles event when cart arrives to order start point.
    newOrderHandler: Function handles event of new order and assings it to available cart.
    routeDoneHandler: Function handles event of cart arriving to end of assigned route.
    routeDoneHandler: Function handles event of cart arriving to end of assigned route.
    commandQueueHandler: Function reads data from queue for subCartController and passes commands
    setDirection: direction setting for cart based on route assigned
"""

from time import time as now
from colorama import Fore, init

import order_status
from thread_print import s_print
from other import getFromQueue, minTupleIndex, queueToStr
from db_communication import getOrder, getAvailableCarts, getCart, getTrack, isTrackOccupied
from msg.travel_payloads import GoTo, GoToResp, RouteDone, RouteDoneResp
from msg.travel_payloads import CollisionAhead
from msg.communication_payloads import CartConnStatus, WelcomeMessageResp, GetIP, GetIPResp
from msg.communication_payloads import GetRSSI, GetRSSIResp, GetSSID, GetSSIDResp
from msg.communication_payloads import GetWiFiChannel, GetWiFiChannelResp
from msg.communication_payloads import GetWiFiStatus, GetWiFiStatusResp
from pathfinder.simple_pathfinding import simplePathfinding


CART_FULL_SPEED = 25
CART_REDUCED_SPEED = 5
CART_STOP = 0
FWD = 1
BWD = 2
MSG_MOVE = 0
MSG_CONNECTED = 1
MSG_GOT_ROUTE = 2
MSG_ROUTE_DONE = 3
MSG_OBSTACLE = 4
MSG_STOP = 5
MSG_CONN_HOLD = 99

init(convert=True) #COLORAMA

def testing2(timer, queues):
    '''Testing function, periodically putr GoTo into queue
    '''
    # periodically puts GoTo in queue
    if timer.fromStart > 5:
        timer.reset()
        for queue in queues:
            if queue[0] == 96:
                queue_dict = {'ID': 'C96',
                              'command': 'GoTo',
                              'parameters': {'velocity': 2,
                                             'direction': 1,
                                             'stop_at': 5,
                                             'stop_at_mm': 382}}
                queue[2].put(queue_dict)
                break

def sensorObstacleHandler(function_name,
                          message,
                          queue_for_order_handler_sql,
                          subCartController_queues,
                          pathfinder):
    """
    Handles unexpected obstacles that cart reports.

    Args:
        function_name: str
            name of parent function which calls this function, for print purposes
        message: str
            message received from queue that subCartController puts data
        queue_for_order_handler_sql: Queue
            queue where order updates are saved
        subCartController_queues: list of [cart no, Queue]
            list of queues where cart orders are saved
        pathfinder: Pathfinder
            object that holds all parameters needed to find optimal path

    Returns:
        None

    Raises:
        None
    """
    function_name += Fore.YELLOW+' sensorObstacleHandler: '+Fore.RESET
    '''
    TODO
    Thread cartDispatcher should decide if this is traffic jam or obstacle.
    Basing on this, cart should wait or get another route.
    '''
    s_print(function_name, 'handling obstacle')
    getCart_ok, cart = getCart(message['ID'])   # get tracked cart
    if getCart_ok:

        if cart['order_no'] != 0:
            getOrder_ok, order = getOrder(cart['order_no']) # get order assigned to cart
            if getOrder_ok:
                #------------ CART WAS TRAVELLING TO START POINT -----------------
                # basing on order status, execute one of cases
                if order['status'] == order_status.CART_EXECUTING_ROUTE_TO_START_POINT:
                    sensedObstacleWhenTravellingToStart(function_name,
                                                        queue_for_order_handler_sql,
                                                        subCartController_queues,
                                                        cart,
                                                        order,
                                                        pathfinder)

                # ------------ CART WAS TRAVELLING TO END POINT -----------------
                if order['status'] == order_status.CART_EXECUTING_ROUTE_TO_END_POINT:
                    sensedObstacleWhenTravellingToEnd(function_name,
                                                      queue_for_order_handler_sql,
                                                      subCartController_queues,
                                                      cart,
                                                      order,
                                                      pathfinder)

                # rozważyć opcję, gdy nie mamy zamówienia a mamy wyznaczona trasę

def sensedObstacleWhenTravellingToEnd(function_name,
                                      queue_for_order_handler_sql,
                                      subCartController_queues,
                                      cart,
                                      order,
                                      pathfinder):
    """
    Handles unexpected obstacles that cart reports when cart travels to end of order.

    Args:
        function_name: str
            name of parent function which calls this function, for print purposes
        queue_for_order_handler_sql: Queue
            queue where order updates are saved
        subCartController_queues: list of [cart no, Queue]
            list of queues where cart orders are saved
        cart: dict
            list of cart parameters received form database in format {'param':value}
        pathfinder: Pathfinder
            object that holds all parameters needed to find optimal path

    Returns:
        None

    Raises:
        None
    """
    function_name += Fore.YELLOW+' sensedObstacleWhenTravellingToEnd: '+Fore.RESET
    # update order status via queue for thread
    queue_for_order_handler_sql.put({'ID': cart['order_no'],
                                     'status': order_status.CART_ENCOUTERED_OBSTACLES_ON_ROUTE_TO_END_POINT,
                                     'status_text': order_status.ORDER_STARUS_DICT[order_status.CART_ENCOUTERED_OBSTACLES_ON_ROUTE_TO_END_POINT] % cart['no']})
    # new route mapping to end point
    # TODO decide what kind of obstacle it is and set new costs on the route
    cart.updateDBInfo(getCart(cart.name))
    route_to_end, cost = simplePathfinding(pathfinder, cart.db_info['track_actual'], order['end_point'])
    s_print(function_name, 'Mapping route to order end point')
    # find queue for this cart
    for queue in subCartController_queues:
        # subCartController_queues is list of tuples (cart_no, queue)
        if queue[0] == cart['no']:
            for x in range(len(route_to_end)):
                queue_dict = {'ID': cart['no'], 'command': 'route', 'parameters': {'route': route_to_end[x]}}
                queue[1].put(queue_dict)
            break

def sensedObstacleWhenTravellingToStart(function_name, queue_for_order_handler_sql, subCartController_queues, cart, order, pathfinder):
    """
    Handles unexpected obstacles that cart reports when cart travels to start of order.

    Args:
        function_name: str
            name of parent function which calls this function, for print purposes
        queue_for_order_handler_sql: Queue
            queue where order updates are saved
        subCartController_queues: list of [cart no, Queue]
            list of queues where cart orders are saved
        cart: dict
            list of cart parameters received form database in format {'param':value}
        pathfinder: Pathfinder
            object that holds all parameters needed to find optimal path

    Returns:
        None

    Raises:
        None
    """
    function_name += Fore.YELLOW+' sensedObstacleWhenTravellingToStart: '+Fore.RESET
    queue_for_order_handler_sql.put({'ID': cart['order_no'],
                                     'status': order_status.CART_ENCOUTERED_OBSTACLES_ON_ROUTE_TO_START_POINT,
                                     'status_text': order_status.ORDER_STARUS_DICT[order_status.CART_ENCOUTERED_OBSTACLES_ON_ROUTE_TO_START_POINT] % cart['no']})
    # new route mapping to start point
    # TODO decide what kind of obstacle it is and set new costs on the route
    cart.updateDBInfo(getCart(cart.name))
    route_to_start, cost = simplePathfinding(pathfinder, cart.db_info['track_actual'], order['start_point'])
    s_print(function_name, 'Mapping route to order start point')
    # find queue for this cart
    for queue in subCartController_queues:
        # subCartController_queues is list of tuples (cart_no, queue)
        if queue[0] == cart['no']:
            for x in range(len(route_to_start)):
                queue_dict = {'ID': cart['no'], 'command': 'route', 'parameters': {'route': route_to_start[x]}}
                queue[1].put(queue_dict)
            break

def cartEndedRouteInStartPoint(function_name, cart, queue_for_order_handler_sql, subCartController_queues, pathfinder):
    """
    Handles event when cart arrives to order start point.

    Args:
        function_name: str
            name of parent function which calls this function, for print purposes
        queue_for_order_handler_sql: Queue
            queue where order updates are saved
        subCartController_queues: list of [cart no, Queue]
            list of queues where cart orders are saved
        cart: dict
            list of cart parameters received form database in format {'param':value}
        pathfinder: Pathfinder
            object that holds all parameters needed to find optimal path

    Returns:
        None

    Raises:
        None
    """
    function_name += Fore.YELLOW+' cartEndedRouteInStartPoint: '+Fore.RESET
    s_print(function_name, cart['no'], 'in order start point')
    queue_for_order_handler_sql.put({'ID': cart['order_no'],
                                     'status': order_status.CART_FINISHED_ROUTE_TO_START_POINT,
                                     'status_text': order_status.ORDER_STARUS_DICT[order_status.CART_FINISHED_ROUTE_TO_START_POINT] % cart['no']})
    s_print(function_name, 'Order '+str(cart['order_no'])+' updated')
    getOrder_ok, order = getOrder(cart['order_no'])
    if getOrder_ok is False:
        s_print(function_name,
                Fore.LIGHTRED_EX,
                'Cannot get order',
                cart['order_no'],
                'from database',
                Fore.RESET)
    if getOrder_ok is True:
        # route mapping to end point
        route_to_end, cost = simplePathfinding(pathfinder, cart['track_actual'], order['end_point'])
        route_to_end = (route_to_end,)
        s_print(function_name, 'Mapping route to order end point')
        for queue in subCartController_queues:
            if queue[0] == cart['no']:
                for x in range(len(route_to_end)):
                    queue_dict = {'ID': cart['no'],
                                  'command': 'route',
                                  'parameters': {'route': route_to_end[x]}}
                                  
                    queue[1].put(queue_dict)
                break

def cartEndedRouteInEndPoint(function_name, cart,
                             queue_for_order_handler_sql,
                             queue_for_cart_handler_sql,
                             subCartController_queues,
                             pathfinder):
    """
    Handles event when cart arrives to order end point.

    Args:
        function_name: str
            name of parent function which calls this function, for print purposes
        queue_for_order_handler_sql: Queue
            queue where order updates are saved
        subCartController_queues: list of [cart no, Queue]
            list of queues where cart orders are saved
        cart: dict
            list of cart parameters received form database in format {'param':value}
        pathfinder: Pathfinder
            object that holds all parameters needed to find optimal path

    Returns:
        None

    Raises:
        None
    """
    function_name += Fore.YELLOW+' cartEndedRouteInEndPoint: '+Fore.RESET
    s_print(function_name, cart['no'], 'in order end point')
    queue_for_order_handler_sql.put({'ID': cart['order_no'],
                                     'status': order_status.CART_FINISHED_ROUTE_TO_END_POINT,
                                     'status_text': order_status.ORDER_STARUS_DICT[order_status.CART_FINISHED_ROUTE_TO_END_POINT] % cart['no']})
    queue_for_cart_handler_sql.put({'ID': cart['no'],
                                    'command': 'order',
                                    'parameter': 0})
    s_print(function_name, 'Order '+str(cart['order_no'])+' updated')
    # route mapping to buffer
    route_to_buffer, cost = simplePathfinding(pathfinder, cart['track_actual'], 2)
    route_to_buffer = (route_to_buffer,)
    s_print(function_name, 'Mapping route to buffer track')
    for queue in subCartController_queues:
        if queue[0] == cart['no']:
            for x in range(len(route_to_buffer)):
                queue_dict = {'ID': cart['no'],
                              'command': 'route',
                              'parameters': {'route': route_to_buffer[x]}}
                queue[1].put(queue_dict)
            break

def subCartControllerCollisionCheck(cart, messages_tx):
    # TODO zmienić widocznośc na fizyczna odległość zamiast na cały tor,
    #wysyłanie wiadomości na zmianę odległosci od przeszkody o jakiś określony próg,
    # powyżej zdefiniowanej odległości do przeszkody kolizja nie jest wykrywana
    # liniowa zalezność częstotliwosći wysyałania wiadomości - bliżej = częściej
    """
    subCartControllerCollisionCheck: checking for collisions ahead of cart
    Args:
        cart: Cart
            Class for tracked cart info
        messages_tx: SubCartControllerMessageTx
            Class for tx messages to carts


    Returns:
        None

    Raises:
        None
    """
    ''' Function pseudocode
    get cart actual track
    get cart direction, get next track basing on direction
    from actual track get next track cart will travel on
    check this track for cart on it
    if there are cart, send message to cart to stop, if cart speed > 0
    if there are no conflicts and cart has destination, cart should start moving
    '''
    COLLISION_FWD_NEW = 1
    COLLISION_FWD_CLEARED = 2
    COLLISION_BWD_NEW = 3
    COLLISION_BWD_CLEARED = 4

    collision_fwd = False
    collision_bwd = False
    message_to_cart = None
    db_ok = False

    getCart_ok, cart_db_info = getCart(cart.name)
    if getCart_ok:
        cart.updateDBInfo(cart_db_info)

    getTrack_ok, track_actual = getTrack(cart.db_info['track_actual'])
    track_next = None
    if getTrack_ok is True:
        if cart.db_info['direction'] == FWD:
            track_next = track_actual['next_no']
            db_ok, carts_on_track_next = isTrackOccupied(track_next)
            if len(carts_on_track_next) != 0 and cart.db_info['no'] not in carts_on_track_next:
                collision_fwd = True

        if cart.db_info['direction'] == BWD:
            track_next = track_actual['prev_no']
            db_ok, carts_on_track_next = isTrackOccupied(track_next)
            if len(carts_on_track_next) != 0 and cart.db_info['no'] not in carts_on_track_next:
                collision_bwd = True

    if collision_fwd is True and cart.collision_front is False and getTrack_ok and db_ok:
        message_to_cart = CollisionAhead(COLLISION_FWD_NEW)
        s_print('collision_fwd',
                cart.db_info['no'],
                ':',
                message_to_cart,
                ' on track',
                track_next,
                ': ',
                carts_on_track_next)
        messages_tx.addMessage(message_to_cart)

    if collision_fwd is False and cart.collision_front is True and getTrack_ok and db_ok:
        message_to_cart = CollisionAhead(COLLISION_FWD_CLEARED)
        s_print('collision_fwd',
                cart.db_info['no'],
                ':',
                message_to_cart,
                ' on track',
                track_next,
                ': ',
                carts_on_track_next)
        messages_tx.addMessage(message_to_cart)

    if collision_bwd is True and cart.collision_back is False and getTrack_ok and db_ok:
        message_to_cart = CollisionAhead(COLLISION_BWD_NEW)
        s_print('collision_bwd',
                cart.db_info['no'],
                ':',
                message_to_cart,
                ' on track',
                track_next,
                ': ',
                carts_on_track_next)
        messages_tx.addMessage(message_to_cart)

    if collision_bwd is False and cart.collision_back is True and getTrack_ok and db_ok:
        message_to_cart = CollisionAhead(COLLISION_BWD_CLEARED)
        s_print('collision_bwd',
                cart.db_info['no'],
                ':',
                message_to_cart,
                ' on track',
                track_next,
                ': ',
                carts_on_track_next)
        messages_tx.addMessage(message_to_cart)

def subCartControllerCollisionCheck2(cart, messages_tx):
    # TODO zmienić widocznośc na fizyczna odległość zamiast na cały tor,
    #wysyłanie wiadomości na zmianę odległosci od przeszkody o jakiś określony próg,
    # powyżej zdefiniowanej odległości do przeszkody kolizja nie jest wykrywana
    # liniowa zalezność częstotliwosći wysyałania wiadomości - bliżej = częściej
    """
    subCartControllerCollisionCheck: checking for collisions ahead of cart
    Args:
        cart: Cart
            Class for tracked cart info
        messages_tx: SubCartControllerMessageTx
            Class for tx messages to carts


    Returns:
        None

    Raises:
        None
    """
    '''Function pseudocode
    get cart actual track
    get cart direction, get next track basing on direction
    from actual track get next track cart will travel on
    check this track for cart on it
    if there are cart, send message to cart to stop, if cart speed > 0
    '''

    COLLISION_FWD_NEW = 1
    COLLISION_FWD_CLEARED = 2
    COLLISION_BWD_NEW = 3
    COLLISION_BWD_CLEARED = 4

    collision_fwd_distance = 0
    collision_bwd_distance = 0

    collision_fwd = False
    collision_bwd = False
    message_to_cart = None
    db_ok = False

    getCart_ok, cart_db_info = getCart(cart.name)
    if getCart_ok:
        cart.updateDBInfo(cart_db_info)

    getTrack_ok, track_actual = getTrack(cart.db_info['track_actual'])
    track_next = None
    if getTrack_ok is True:
        if cart.db_info['direction'] == FWD:
            track_next = track_actual['next_no']
            db_ok, carts_on_track_next = isTrackOccupied(track_next)
            if len(carts_on_track_next) != 0 and cart.db_info['no'] not in carts_on_track_next:
                collision_fwd = True

        if cart.db_info['direction'] == BWD:
            track_next = track_actual['prev_no']
            db_ok, carts_on_track_next = isTrackOccupied(track_next)
            if len(carts_on_track_next) != 0 and cart.db_info['no'] not in carts_on_track_next:
                collision_bwd = True

    if collision_fwd is True and cart.collision_front is False and getTrack_ok and db_ok:
        message_to_cart = CollisionAhead(COLLISION_FWD_NEW)
        s_print('collision_fwd', cart.db_info['no'], ':', message_to_cart, ' on track', track_next)
        messages_tx.addMessage(message_to_cart)

    if collision_fwd is False and cart.collision_front is True and getTrack_ok and db_ok:
        message_to_cart = CollisionAhead(COLLISION_FWD_CLEARED)
        s_print('collision_fwd', cart.db_info['no'], ':', message_to_cart, ' on track', track_next)
        messages_tx.addMessage(message_to_cart)

    if collision_bwd is True and cart.collision_back is False and getTrack_ok and db_ok:
        message_to_cart = CollisionAhead(COLLISION_BWD_NEW)
        s_print('collision_bwd', cart.db_info['no'], ':', message_to_cart, ' on track', track_next)
        messages_tx.addMessage(message_to_cart)

    if collision_bwd is False and cart.collision_back is True and getTrack_ok and db_ok:
        message_to_cart = CollisionAhead(COLLISION_BWD_CLEARED)
        s_print('collision_bwd', cart.db_info['no'], ':', message_to_cart, ' on track', track_next)
        messages_tx.addMessage(message_to_cart)


def localQueueToOutputQueue(queue_input, queue_output):
    """
    Function puts data from one queue to another. Just like sending TCP from only one place

    Args:
        queue_input: Queue
            input queue collected all over parent function
        queue_output: Queue
            output queue

    Returns:
        None

    Raises:
        None
    """
    while queue_input.empty() is False:
        queue_ok, queue_element = getFromQueue(queue_input)
        if queue_ok:
            queue_output.put(queue_element)

def messageSender(messages_tx, connection):
    """
    Function send all messages to cart from queue.

    Args:
        messages_tx: SubCartControllerMessageTx
            Class for tx messages to carts
        connection: TCPMessagingConnection
            TCP connection interface

    Returns:
        None

    Raises:
        None
    """
    while messages_tx.ifMessages():
        message_tx = messages_tx.getMessage()
        # if message_tx != None:
        assert (message_tx is not None), 'Message in queue is None'
        connection.sendMessage(message_tx)

def newOrderHandler(function_name,
                    queue_from_orders_check,
                    queue_for_cart_handler_sql,
                    queue_for_order_handler_sql,
                    subCartController_queues,
                    pathfinder,
                    ORDER_TIMEOUT=30):
    """
    Function handles event of new order and assings it to available cart.

    Args:
        function_name: str
            name of parent function which calls this function, for print purposes
        queue_from_orders_check: Queue
            queue where order waits to handle
        queue_for_cart_handler_sql: Queue
            queue where cart updates are saved
        queue_for_order_handler_sql: Queue
            queue where order updates are saved
        subCartController_queues: list of [cart no, Queue]
            list of queues where cart orders are saved
        pathfinder: Pathfinder
            object that holds all parameters needed to find optimal path
        ORDER_TIMEOUT: int
            Default: 60, anmount of seconds after order gets status timeout

    Returns:
        None

    Raises:
        None
    """
    function_name += Fore.YELLOW+' newOrderHandler: '+Fore.RESET
    queue_ok, order = getFromQueue(queue_from_orders_check)
    if queue_ok:
        s_print(function_name, 'order_no from queue: ', order['ID'])
        db_ok, order_current = getOrder(order['ID'])
        if db_ok is True:
            db_ok, available_carts = getAvailableCarts()
            if db_ok:
                # Print available carts
                if len(available_carts) > 0:
                    output = Fore.GREEN + ' Available carts (' + Fore.RESET + str(len(available_carts))+ Fore.GREEN + '): '+ Fore.RESET
                    for cart in available_carts:
                        output += 'C'+str(cart['no']) + ' '

                    s_print(function_name + output)

                if len(available_carts) == 0:
                    s_print(function_name,
                            Fore.LIGHTYELLOW_EX,
                            'No available carts for order',
                            order_current['ID'],
                            'execution',
                            Fore.RESET)

                elif len(available_carts) > 0:
                    #cart choosing
                    route_cost_list = []
                    for cart_choosen in available_carts:
                        route_cost_list.append(simplePathfinding(pathfinder,
                                                                 cart_choosen['track_actual'],
                                                                 order_current['start_point']))

                    # finding cart with minimal cost travel to order start
                    cart_index = minTupleIndex(route_cost_list, search_index=1)
                    cart = available_carts[cart_index]
                    # route_cost_list: [[route, cost], [route, cost], ...]
                    route_to_start = (route_cost_list[cart_index][0],)

                # {'ID': cart_name, 'command': 'order'/'status'/'status_text', 
                #  'parameter': order_no/status/status_text}
                if len(available_carts) > 0:
                    queue_for_cart_handler_sql.put({'ID': cart['no'],
                                                    'command': 'order',
                                                    'parameter': order['ID']})

                    for queue in subCartController_queues:
                        if queue[0] == cart['no']:
                            for x in range(len(route_to_start)):
                                queue_dict = {'ID': cart['no'],
                                              'command': 'route',
                                              'parameters': {'route': route_to_start[x]}}
                                queue[1].put(queue_dict)
                            break

                else:
                    if now() - order['time_start'] < ORDER_TIMEOUT:
                        queue_for_order_handler_sql.put({'ID': order['ID'],
                                                         'status': order_status.NO_CART_FOUND,
                                                         'status_text': order_status.ORDER_STARUS_DICT[order_status.NO_CART_FOUND]})
                        # Put unhandled order to end of input queue
                        queue_from_orders_check.put({
                            'ID': order['ID'],
                            'time_start': order['time_start']
                        })
                    else:
                        queue_for_order_handler_sql.put({'ID': order['ID'],
                                                         'status': order_status.ORDER_TIMEOUT,
                                                         'status_text': order_status.ORDER_STARUS_DICT[order_status.ORDER_TIMEOUT]})
                        s_print(function_name,
                                'Order',
                                order['ID'],
                                'has not been processed in',
                                ORDER_TIMEOUT,
                                'seconds, timeout')


# ------------------- IF ORDER IS REJECTED FOR COUPLE OF TIMES OR WITH TIMEOUT, IT SHOULD BE PERMANENTLY REJECTED
# CORRECT THIS SECTION
        elif db_ok is False:
            if now() - order['time_start'] < ORDER_TIMEOUT:
                s_print(function_name, Fore.LIGHTRED_EX+'Order', order['ID'], 'TIMEOUT'+Fore.RESET)
                queue_for_order_handler_sql.put({'ID': order['ID'],
                                                 'status': order_status.ORDER_DELAYED,
                                                 'status_text': order_status.ORDER_STARUS_DICT[order_status.ORDER_DELAYED]})
                # Put unhandled order to end of input queue
                queue_from_orders_check.put({'ID': order['ID'],
                                             'time_start': order['time_start']})

def routeDoneHandler(function_name,
                     message,
                     queue_for_order_handler_sql,
                     queue_for_cart_handler_sql,
                     subCartController_queues,
                     pathfinder):
    """
    Function handles event of cart arriving to end of assigned route.

    Args:
        function_name: str
            name of parent function which calls this function, for print purposes
        queue_for_order_handler_sql: Queue
            queue where order updates are saved
        queue_for_cart_handler_sql: Queue
            queue where cart updates are saved
        message: str
            message received from queue that subCartController puts data
        subCartController_queues: list of [cart no, Queue]
            list of queues where cart orders are saved
        pathfinder: Pathfinder
            object that holds all parameters needed to find optimal path

    Returns:
        None

    Raises:
        None
    """
    function_name += Fore.YELLOW+' routeDoneHandler: '+Fore.RESET
    s_print(function_name, 'handling route done')
    getCart_ok, cart = getCart(message['ID'])
    if getCart_ok:
        if cart['order_no'] != 0:
            getOrder_ok, order = getOrder(cart['order_no'])
            if getOrder_ok and cart['order_no'] != 0:
                #------------ CART ENDED ROUTE IN ORDER START POINT ----------------
                if cart['track_actual'] == order['start_point']:
                    cartEndedRouteInStartPoint(function_name,
                                               cart,
                                               queue_for_order_handler_sql,
                                               subCartController_queues,
                                               pathfinder)
                #------------ CART ENDED ROUTE IN ORDER END POINT ----------------
                elif cart['track_actual'] == order['end_point']:
                    cartEndedRouteInEndPoint(function_name,
                                             cart,
                                             queue_for_order_handler_sql,
                                             queue_for_cart_handler_sql,
                                             subCartController_queues,
                                             pathfinder)
            else:
                print(function_name, 'getOrder_ok: ', getOrder_ok)

        else:
            print(function_name, "Cart", cart['no'], "has no assigned order")

def receivedMessagesHandler(messages_rx, messages_tx, cart, queue_output):
    function_name = Fore.YELLOW+ 'C' + str(cart.name) + ' receivedMessagesHandler: ' + Fore.RESET

    for message_rx_raw in messages_rx:
        # odpowiedzi przekazać do cart dispatchera
        if message_rx_raw.payload_type == GetIPResp.MSG_TYPE:
            message_rx = GetIPResp.Deserialize(message_rx_raw.payload_bytes)
            s_print(function_name, 'GetIPResp ip address:', message_rx.ip_address)

        if message_rx_raw.payload_type == WelcomeMessageResp.MSG_TYPE:
            message_rx = WelcomeMessageResp.Deserialize(message_rx_raw.payload_bytes)
            if message_rx.status[0] != 1:
                s_print(function_name, 'Connection error, status:', message_rx.status)

        if message_rx_raw.payload_type == GoToResp.MSG_TYPE:
            message_rx = GoToResp.Deserialize(message_rx_raw.payload_bytes)
            s_print(function_name, 'GoToResp status:', message_rx.status)

        if message_rx_raw.payload_type == RouteDone.MSG_TYPE:
            message_rx = RouteDone.Deserialize(message_rx_raw.payload_bytes)
            s_print(function_name, 'RouteDone status:', message_rx.status)
            message_tx = RouteDoneResp(1)
            messages_tx.addMessage(message_tx)
            queue_output.put({'ID': cart.name,
                              'command': 'route done'})
            cart.on_route = False

    messages_rx = []


def subCartControllerQueueHandler(function_name, cart, messages_tx, queue_input, queue_output):
    """
    Function reads data from queue for subCartController and passes returns messages to transmit

    Args:
        function_name: str
            name of parent function which calls this function, for print purposes
        cart: Cart
            Object of class for tracked cart info
        messages_tx: SubCartControllerMessageTx
            object of queue with messages
        queue_input: Queue
            queue for input commands
        queue_output: Queue
            queue for feedback commands to cart dispatcher
    Returns:
        kill_yorself: bool
            flag for killing this thread

    Raises:
        None
    """

    function_name += Fore.YELLOW+' subCartControllerQueueHandler: '+Fore.RESET
    kill_yorself = False
    if queue_input.empty() is False:
        queue_ok, queue_element = getFromQueue(queue_input)
        if queue_ok is False:
            s_print((function_name, Fore.LIGHTRED_EX+'Cannot get queue element!'+Fore.RESET))
        elif queue_ok is True:
            if 'route' in queue_element['command']:
                cart.on_route = True
                s_print(function_name,
                        'Cart_on_route: ',
                        cart.on_route,
                        queue_element['command'],
                        'remaining: ',
                        queue_input.qsize())
                # print remaining elements in queue
                s_print(function_name+' Queue: '+queueToStr(queue_input))
                route = queue_element['parameters']['route']
                s_print(function_name, 'Got route', route)
                getCart_ok, cart_db_info = getCart(cart.name)
                if getCart_ok:
                    cart.updateDBInfo(cart_db_info)

                calculateDirection(cart, route)
                if len(route) > 1:
                    message_to_cart = GoTo(stop_id=route[-1],
                                           stop_track_num=route[-1],
                                           stop_track_offset=50,
                                           direction=cart.direction,
                                           max_speed=5,
                                           slow_id=route[-2],
                                           slow_track_num=route[-2],
                                           slow_track_offset=0)
                else:
                    message_to_cart = GoTo(stop_id=route[-1],
                                           stop_track_num=route[-1],
                                           stop_track_offset=50,
                                           direction=cart.direction,
                                           max_speed=5,
                                           slow_id=route[-1],
                                           slow_track_num=route[-1],
                                           slow_track_offset=0)

                messages_tx.addMessage(message_to_cart)
                s_print(queueToStr(messages_tx.messages))
                queue_output.put({'ID': cart.name,
                                  'command': 'route sent'})

            elif queue_element['command'] == 'GoTo':
                message_to_cart = GoTo(stop_id=queue_element['parameters']['stop_at'],
                                       stop_track_num=queue_element['parameters']['stop_at'],
                                       stop_track_offset=queue_element['parameters']['stop_at_mm'],
                                       direction=queue_element['parameters']['direction'],
                                       max_speed=queue_element['parameters']['velocity'],
                                       slow_id=queue_element['parameters']['slow_id'],
                                       slow_track_num=queue_element['parameters']['slow_track_num'],
                                       slow_track_offset=queue_element['parameters']['slow_track_offset'])

                messages_tx.addMessage(message_to_cart)
                queue_output.put({'ID': cart.name,
                                  'command': 'GoTo sent'})

            elif queue_element['command'] == 'CartConnStatus':
                message_to_cart = CartConnStatus()
                messages_tx.addMessage(message_to_cart)
                queue_output.put({'ID': cart.name,
                                  'command': 'CartConnStatus sent'})

            elif queue_element['command'] == 'GetIP':
                message_to_cart = GetIP()
                messages_tx.addMessage(message_to_cart)
                queue_output.put({'ID': cart.name,
                                  'command': 'Get IP sent'})

            elif queue_element['command'] == 'GetRSSI':
                message_to_cart = GetRSSI()
                messages_tx.addMessage(message_to_cart)
                queue_output.put({'ID': cart.name,
                                  'command': 'Get RSSI sent'})

            elif queue_element['command'] == 'GetSSID':
                message_to_cart = GetSSID()
                messages_tx.addMessage(message_to_cart)
                queue_output.put({'ID': cart.name,
                                  'command': 'Get SSID sent'})

            elif queue_element['command'] == 'GetWiFiChannel':
                message_to_cart = GetWiFiChannel()
                messages_tx.addMessage(message_to_cart)
                queue_output.put({'ID': cart.name,
                                  'command': 'Get WiFi Channel sent'})

            elif queue_element['command'] == 'GetWiFiStatus':
                message_to_cart = GetWiFiStatus()
                messages_tx.addMessage(message_to_cart)
                queue_output.put({'ID': cart.name,
                                  'command': 'Get WiFi Status sent'})

            elif queue_element['command'] == 'Kill':
                kill_yorself = True

            else:
                s_print(function_name,
                        Fore.LIGHTRED_EX,
                        'unexpected command in queue:',
                        Fore.RESET,
                        queue_element)
                raise ValueError('unexpected command in queue')

    return kill_yorself

def calculateDirection(cart, route, DEBUG=False):
    """
    direction setting for cart based on route assigned

    Args:
        cart: Cart
            Object of class for tracked cart info
        route: list
            list of tracks in route
        DEBUG: bool
            additional printing

    Returns:
        None

    Raises:
        None
    """
    function_name = Fore.YELLOW+' calculateDirection: '+Fore.RESET
    DIR_STOP = 0
    DIR_FWD = 1
    DIR_BWD = 2

    getTrack_ok, actual_track = getTrack(cart.db_info['track_actual'])
    if getTrack_ok:
        # case if cart is on its destination - route has one element
        if len(route) == 1 and route[0] == actual_track['no']:
            direction = DIR_STOP
            s_print(function_name,
                    'C'+str(cart.name),
                    'on track destination, not need to set direction')
            cart.setDirection(direction)

        # case if route has at least 2 elements
        if len(route) > 1 and route[1] == actual_track['prev_no']:
            direction = DIR_BWD
            cart.setDirection(direction)

        elif len(route) > 1 and  route[1] == actual_track['next_no']:
            direction = DIR_FWD
            cart.setDirection(direction)

        else:
            s_print(Fore.LIGHTRED_EX,
                    'no direction set, route[0]:',
                    route[0],
                    'actual_track_prev:',
                    actual_track['prev_no'],
                    'actual_track_next:',
                    actual_track['next_no'],
                    Fore.RESET)

        if DEBUG:
            if direction == DIR_FWD:
                print(function_name, 'direction set: FWD')

            if direction == DIR_BWD:
                print(function_name, 'direction set: BWD')

            if direction == DIR_STOP:
                print(function_name, 'direction set: STOP')

class Alarms(object):
    """Alarm class
    """
    def __init__(self, subsytem, device_no, alarms=None):
        self.subsystem = subsytem
        self.device_no = device_no
        if alarms is not None:
            self.alarms = alarms
        else:
            self.alarms = 0x0
        self.alarms_last = 0x0
        self.alarms_diff = 0x0
        self.diff_list = []

    def __str__(self):
        output = ''
        output += 'subsystem: '
        output += str(self.subsystem)
        output += ', device_no: '
        output += str(self.device_no)
        output += ', alarms: '
        output += format(self.alarms,'032b')
        output += ', alarms_last: '
        output += format(self.alarms_last,'032b')
        output += ', alarms_diff: '
        output += format(self.alarms_diff,'032b')
        output += ', diff_list: '
        output += str(self.diff_list)
        return output

    def setAlarm(self, alarm_index, size=32):
        """
        Set alarm bit in given chain

        Args:
            alarms: int (0b)
                Chain of bits. Every bit represents different alarm
            alarm_index: int
                Index of alarm to be set
            size: int
                Length of bit chain. Default 32
        Returns:
            alarms: int (0b)
                Chain of bits. Every bit represents different alarm

        Raises:
            AssertionError: alarm index is equal or higher than size
        """
        assert alarm_index < size, "Wrong alarm index: "+str(alarm_index)+", size: "+str(size)
        assert alarm_index >= 0, "Wrong alarm index: "+str(alarm_index)+", size: "+str(size)
        self.alarms_last = self.alarms
        mask = 0b1
        mask = mask << alarm_index
        self.alarms = self.alarms | mask
        self.calculateDiff()
        self.convertDiffToList()


    def setAlarmAll(self, alarms):
        self.alarms_last = self.alarms
        self.alarms = alarms
        self.calculateDiff()
        self.convertDiffToList()

    def convertDiffToList(self, size=32):
        self.diff_list = []
        for x in range(size):
            diff = self.alarms_diff >> x
            mask = 0b1
            diff = diff & mask
            if diff == 1:
                self.diff_list.append((x, self.getAlarm(x)))



    def resetAlarm(self, alarm_index=None, size=32):
        """
        Reset alarm bit in given chain

        Args:
            alarms: int (0b)
                Chain of bits. Every bit represents different alarm
            alarm_index: int
                Index of alarm to be reset
            size: int
                Length of bit chain. Default 32
        Returns:
            alarms: int (0b)
                Chain of bits. Every bit represents different alarm

        Raises:
            AssertionError: alarm index is equal or higher than size
        """
        if alarm_index is not None:
            assert alarm_index < size, "Wrong alarm index: "+str(alarm_index)+", size: "+str(size)
            assert alarm_index >= 0, "Wrong alarm index: "+str(alarm_index)+", size: "+str(size)
            self.alarms_last = self.alarms
            mask = 0b1
            mask = mask << alarm_index
            mask = ~mask
            self.alarms = self.alarms & mask
        else:
            self.alarms = 0x0

        self.calculateDiff()
        self.convertDiffToList()

    def getAlarm(self, alarm_index, size=32):
        """
        Get alarm bit from given chain

        Args:
            alarms: int (0b)
                Chain of bits. Every bit represents different alarm
            alarm_index: int
                Index of alarm to be looked up
            size: int
                Length of bit chain. Default 32
        Returns:
            alarms: int (0b)
                Chain of bits. Every bit represents different alarm

        Raises:
            AssertionError: alarm index is equal or higher than size
        """
        assert alarm_index < size, "Wrong alarm index: "+str(alarm_index)+", size: "+str(size)
        assert alarm_index >= 0, "Wrong alarm index: "+str(alarm_index)+", size: "+str(size)
        alarm = self.alarms >> alarm_index
        alarm = alarm & 0b1
        return alarm
    
    def calculateDiff(self):
        self.alarms_diff = self.alarms ^ self.alarms_last


def testCode():
    alarms = Alarms('C', 69)
    alarms.setAlarmAll(0b000111)
    print('alarms: ', alarms)

    alarms.setAlarmAll(0b111000)
    print('alarms: ', alarms)

    alarms.setAlarmAll(0b111000)
    print('alarms: ', alarms)

    alarms.setAlarm(5)
    print('alarms: ', alarms)

# testCode()
"""
Module udp_payloads - messages definition to send over UDP

Classes:
    cartInfoUDP: Class that holds default MQTT credentials.
    newClient: Class that holds MQTT client, inherits from paho.Client.
"""
import struct

class cartInfoUDP(object):
    """
    Basic cart info message

    Parameters:
        cart_id: uint16
            Cart ID/number
        direction: uint8
            Actual direction 0 - STOP, 1 - FORWARD, 2 - BACKWARD
        speed: uint8
            Actual speed
        track_num: uint16
            Actual track no
        track_offset: uint16
            Actual track position [mm]
        status: uint16
            Cart status
        alarm: uint32
            Alarms

    Methods:
        serialize: pack input data to bytes string
        Deserialize: Static, unpack bytes string to this object
    """
    def __init__(self, cart_id, direction, speed, track_num, track_offset, status, alarm):
        self.MSG_TYPE = 0
        self.cart_id = cart_id
        self.direction = direction
        self.speed = speed
        self.track_num = track_num
        self.track_offset = track_offset
        self.status = status
        self.alarm = alarm

    def __str__(self):
        output = 'MSG_TYPE: '
        output += str(self.MSG_TYPE)
        output += '\ncart_id: '
        output += str(self.cart_id)
        output += '\ndirection: '
        output += str(self.direction)
        output += '\nspeed: '
        output += str(self.speed)
        output += '\ntrack_num: '
        output += str(self.track_num)
        output += '\ntrack_offset: '
        output += str(self.track_offset)
        output += '\nstatus: '
        output += str(self.status)
        output += '\nalarm: '
        output += str(self.alarm)
        return output

    def serialize(self):
        return struct.pack('>BHBBHHHI',
                           self.MSG_TYPE,
                           self.cart_id,
                           self.direction,
                           self.speed,
                           self.track_num,
                           self.track_offset,
                           self.status,
                           self.alarm)

    @staticmethod
    def Deserialize(payload_bytes):
        MSG_TYPE, cart_id, direction, speed, track_num, track_offset, status, alarm = struct.unpack('>BHBBHHHI', payload_bytes)
        return cartInfoUDP(cart_id, direction, speed, track_num, track_offset, status, alarm)

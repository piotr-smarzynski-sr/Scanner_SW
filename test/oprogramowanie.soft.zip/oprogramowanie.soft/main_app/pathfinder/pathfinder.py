import math

class Pathfinder(object):
    def __init__(self, graph):
        self.g=graph

    def plan(self, beg, end, return_indices = False):
        """
        Finds path between two tracks.
        Returns tuple of '(path, total_cost)' , where path is list of track names 
        Optional argunment 'return_indices' when set to 'True' allows to return track indices insteadof track names
        When no path found, returns '([], float('inf'))'
        """
        #Map names to indices
        beg_idx = self.g.nodeIdToIndex(beg)
        end_idx = self.g.nodeIdToIndex(end)

        if beg_idx == None or end_idx == None:
            print("Start or stop does not exist")
            return []
        path, total_cost = self.planDjikstra(beg_idx, end_idx)
        if return_indices:
            return path,total_cost
        else:
            return [self.g.nodes[p].id for p in path], total_cost
        
    def cost(self, a, b):
        return self.g.nodes[a].length/2 + self.g.nodes[b].length/2

    def nodeNeighbors(self, node_idx):
        return self.g.nodes[node_idx].neighbors

    def planDjikstra(self, beg, end):
        #Prepare
        num = len(self.g.nodes)
        dist = [float('inf')]*num
        prev = [None]*num
        valid = [True]*num

        dist[beg] = 0
        cnt = num
        while cnt != 0:
            #Get node with smallest cost
            #Naive implementation
            u = None
            u_dist = float('inf')
            for i,d in enumerate(dist):
                if valid[i] == False:
                    continue
                if d <= u_dist:
                    u = i
                    u_dist = d
            assert u != None
            #remove u from valid set
            valid[u] = False
            cnt-=1

            if u == end: # found path, backtrace
                trace = []
                u = end
                if prev[u] != None or u == beg:
                    while u != None:
                        trace.append(u)
                        u = prev[u]
                    trace.reverse()
                    return trace, dist[end]

            #neighbors
            neighbors = self.nodeNeighbors(u)
            for neighbor_edge in neighbors:
                #print(u,n)
                n = neighbor_edge.node_b
                if valid[n] == False: # skip nodes not in Q
                    continue
                if self.g.nodes[n].disabled: # skip disabled nodes
                    continue
                if neighbor_edge.disabled: # Skip disabled edges
                    continue
                new_dst = u_dist + neighbor_edge.cost()
                if new_dst < dist[n]:
                    dist[n] = new_dst
                    prev[n] = u
        #Path not found
        return [], float('inf')
                
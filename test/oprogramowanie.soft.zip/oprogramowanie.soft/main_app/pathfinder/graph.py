import math

class Node(object):
    def __init__(self, id, length):
        self.id = id
        self.length = length
        self.disabled = False

    def toJson(self):
        return [self.id, self.length]

    def fromJson(self, json):
        self.id = json[0]
        self.length = json[1]

    @staticmethod
    def FromJson(json):
        return Node(json[0], json[1])

    def __str__(self):
        return  "Node '{}' length:'{}'".format(self.id, self.length)


class Edge(object):
    class Direction:
        NONE = 0
        FWD = 1
        BWD = 2
        ANY = 3
    def __init__(self, node_a, node_b, port_a, port_b):
        self.node_a = node_a
        self.node_b = node_b
        self.port_a = port_a
        self.port_b = port_b
        self.default_cost = 0
        self.speed_factor = 0
        self.direction_factor = 0
        self.additional_cost = 0
        self.disabled = False

    def __str__(self):
        return "{} <-> {}".format(self.node_a, self.node_b)

    def toJson(self):
        return [self.node_a, self.node_b, self.port_a, self.port_b]

    def cost(self):
        return (self.default_cost + 
            self.default_cost*self.speed_factor +
            self.default_cost*self.direction_factor +
            self.additional_cost)

    def fromJson(self, json):
        self.node_a = json[0]
        self.node_b = json[1]
        self.port_a = json[2]
        self.port_b = json[3]

    def __eq__(self, other):
        return (self.node_a == other.node_a and
                self.node_b == other.node_b and
                self.port_a == other.port_a and
                self.port_b == other.port_b)

    # Define ordering to allow edges to be sorted
    def __lt__(self, other):
        if self.node_a < other.node_a:
            return True
        if self.node_a == other.node_a and self.node_b < other.node_b:
            return True
        return False
        #Port ordering doesn't matter, no edge shall have duplicates with different ports
    
    #Define hashing method to allow usage in sets
    def __hash__(self):
        return (hash(self.node_a) ^
                hash(self.node_b) ^ 
                hash(self.port_a) ^
                hash(self.port_b))
        

    @staticmethod
    def FromJson(json):
        return Edge(json[0], json[1], json[2], json[3])

class Graph(object):
    def __init__(self, nodes, edges, duplicate_edges=True):
        self.nodes = nodes
        # Find unique edges
        self.edges = list(set(edges))

        self._extra_edges = []

        # Duplicate edges (single direction to both directions)
        for e in self.edges:
            primary = Edge(e.node_a, e.node_b, e.port_a, e.port_b)
            self._extra_edges.append(primary)
            if duplicate_edges:
                secondary = Edge(e.node_b, e.node_a, e.port_b, e.port_a)
                self._extra_edges.append(secondary)
          
        # Sort edges
        # print([str(e) for e in self._extra_edges])
        self._extra_edges.sort()
        # print([str(e) for e in self._extra_edges])

    @staticmethod
    def FromJson(json):
        nodes = [Node.FromJson(n) for n in json['nodes']]
        edges = [Edge.FromJson(e) for e in json['edges']]
        #TODO Validation
        return Graph(nodes, edges)

    def setEdgeHardDirection(self, track_from, track_to, dir):
        nfrom = self.nodeIdToIndex(track_from)
        nto = self.nodeIdToIndex(track_to)

        #Backward edge
        for e in self.nodes[nto].neighbors:
            if e.node_b == nfrom:
                if dir == Edge.Direction.FWD or dir == Edge.Direction.NONE:
                    e.disabled = True
                else:
                    e.disabled = False

        #Forward edge
        for e in self.nodes[nfrom].neighbors:
            if e.node_b == nto:
                if dir == Edge.Direction.BWD or dir == Edge.Direction.NONE:
                    e.disabled = True
                else:
                    e.disabled = False
        

    def setEdgeSoftDirection(self, track_from, track_to, strength, dir):
        nfrom = self.nodeIdToIndex(track_from)
        nto = self.nodeIdToIndex(track_to)
        assert strength >=0
        assert strength <=1

        #Backward edge
        for e in self.nodes[nto].neighbors:
            if e.node_b == nfrom:
                if dir == Edge.Direction.FWD or dir == Edge.Direction.NONE:
                    e.direction_factor = strength
                else:
                    e.direction_factor = 1.0-strength

        #Forward edge
        for e in self.nodes[nfrom].neighbors:
            if e.node_b == nto:
                if dir == Edge.Direction.BWD or dir == Edge.Direction.NONE:
                    e.direction_factor = strength
                else:
                    e.direction_factor = 1.0-strength

    def setEdgeExtraCost(self, track_from, track_to, cost):
        nfrom = self.nodeIdToIndex(track_from)
        nto = self.nodeIdToIndex(track_to)
        for e in self.nodes[nfrom].neighbors:
            if e.node_b == nto:
                e.additional_cost = cost
        
    def disableTrack(self, track):
        node = self.nodeIdToIndex(track)
        self.nodes[i].disabled = True

    def enableTrack(self, track):
        node = self.nodeIdToIndex(track)
        self.nodes[i].disabled = False

    @staticmethod
    def FromTrackList(track_list):
        # nodes = [Node(t.name, t.length_mm) for t in track_list]
        nodes = [Node(t.no, t.length_mm) for t in track_list]
        edges = []
        # Graph hasn't been constructed yet, we have to rewrite id -> idx mapping from scratch
        def findNodeIdx(nodes, name):
            for i,n in enumerate(nodes):
                 if name==n.id:
                     return i
            return None
        
        # Find first edge port
        for a, track in enumerate(track_list):
            for prev_track in track.prev_track_all:
                b = findNodeIdx(nodes, prev_track)
                edges.append(Edge(a,b,0, None))
            for next_track in track.next_track_all:
                b = findNodeIdx(nodes, next_track)
                edges.append(Edge(a,b,1, None))
    
        #Determine second edge port
        for e in edges:
            aname = track_list[e.node_a].name

            if aname in track_list[e.node_b].prev_track_all:
                e.port_b = 0
            if aname in track_list[e.node_b].next_track_all:
                e.port_b = 1

        return Graph(nodes, edges, duplicate_edges=False)

    @staticmethod
    def FromTrackListDB():
        '''
        TODO
        import db_communication from above level, (.) changes nothing, (..) raises exception: ValueError: attempted relative import beyond top-level package
        it might not be possible
        '''
        from db_communication import getAllTracks # works for now, but only with local copy of module
        # from .. import db_communication
        getAll_ok, track_list = getAllTracks()
        if getAll_ok == False:
            print('FromTrackListDB ERROR: Cannot get tracks map from DB!')
        if getAll_ok == True:
            nodes = [Node(t['no'], t['length_mm']) for t in track_list]
            edges = []
            # Graph hasn't been constructed yet, we have to rewrite id -> idx mapping from scratch
            def findNodeIdx(nodes, name):
                for i,n in enumerate(nodes):
                    if name==n.id:
                        return i
                return None
            
            # Find first edge port
            for a, track in enumerate(track_list):
                for prev_no in track['prev_no_all']:
                    b = findNodeIdx(nodes, prev_no)
                    edges.append(Edge(a,b,0, None))
                for next_no in track['next_no_all']:
                    b = findNodeIdx(nodes, next_no)
                    edges.append(Edge(a,b,1, None))
        
            #Determine second edge port
            for e in edges:
                aname = track_list[e.node_a]['no']

                if aname in track_list[e.node_b]['prev_no_all']:
                    e.port_b = 0
                if aname in track_list[e.node_b]['next_no_all']:
                    e.port_b = 1

            return Graph(nodes, edges, duplicate_edges=False)

    def toJson(self):
        ret = {}
        ret['nodes'] = [n.toJson() for n in self.nodes]
        ret['edges'] = [e.toJson() for e in self.edges]
        return ret

    def nodeIdToIndex(self, id):
        for i,n in enumerate(self.nodes):
            if id == n.id:
                return i

    def buildNeighborhood(self):
        for node in self.nodes:
            node.neighbors = []
        for edge in self._extra_edges:
            edge.default_cost = self.nodes[edge.node_a].length/2 + self.nodes[edge.node_b].length/2
            self.nodes[edge.node_a].neighbors.append(edge)

    def getEdgePorts(self, node_from, node_to):
        for edge in self.edges:
            if edge.node_a == node_from and edge.node_b == node_to:
                return (edge.port_a, edge.port_b)
            if edge.node_b == node_from and edge.node_a == node_to:
                return (edge.port_b, edge.port_a)

    def __str__(self):
        ret = 'Nodes\n'
        for n in self.nodes:
            ret += str(n) + '\n'
        ret += 'Edges\n'
        for e in self.edges:
            ret += str(e) + '\n'
        ret += 'ExtraEdges\n'
        for e in self._extra_edges:
            ret += str(e)+'\n'
        return ret
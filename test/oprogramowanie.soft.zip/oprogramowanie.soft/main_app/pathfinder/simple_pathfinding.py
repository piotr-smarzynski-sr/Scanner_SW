import json
from .graph import Graph, Edge
from .pathfinder import Pathfinder



def simplePathfinding(pathfinder, start_point, end_point):
    #CALCULATE
    route, cost = pathfinder.plan(start_point, end_point)
    return route, cost

def pathfinderInit():
    # CONFIG
    g = Graph.FromTrackListDB()
    g.buildNeighborhood()
    pf = Pathfinder(g)

    return g, pf

"""
Module mqtt_communication - interface beetween this application and MQTT broker

Classes:
    MQTTConnect: Class that holds default MQTT credentials.
    newClient: Class that holds MQTT client, inherits from paho.Client.

Functions:
    on_message_subscribed: Event on new MQTT message.
    on_log: Event on new MQTT log.
    on_connect: Event on new MQTT connection.
    createClient: Create new MQTT client and hook event functions
    clientStop: Disconnects and stops selected client
    subscribe: Client subscribes selected topic and starts MQTT loop
    unsubscribe: Client unsubscribes selected topic
    publish: Client publishes message in selected topic
    save_message_to_frame: Converts MQTT message into internal frame format

"""

import paho.mqtt.client as paho
import random as r
import string
import base64
from time import sleep
from time import time as now
from struct import pack
from thread_print import s_print
from colorama import init, Fore

import other

"""
TODO CONSIDER
Same encryption and usage as in db_communication
add user and password in MQTT
poszukać komend sterujących do MQTT
"""
init(convert=True) #COLORAMA

# BROKER = "192.168.130.43"
# BROKER = 'test.mosquitto.org'
LOGGING = False
MQTT_DEBUG = False
MQTT_DEBUG_LEVEL = 0

class MQTTConnect():
    """
    Class that holds default MQTT credentials.

    Parameters:
        BROKER: str
            IP address of MQTT broker e.g 'localhost' or '192.168.1.134 or 'test.mosquitto.org'
        PORT: int
            list of UDP clients
    """
    def __init__(self):
        self.BROKER = 'localhost'
        self.PORT = 1883

class newClient(paho.Client):
    """
    Class that holds MQTT client, inherits from paho.Client.

    Parameters:
        ACTUAL_MESSAGE: str
            Newest message got from MQTT
        LAST_MESSAGE: str
            One before newest message got from MQTT
        connection: MQTTConnect
            Broker connection credentials
    """
    def __init__(self, name):
        paho.Client.__init__(self, client_id =name)
        self.ACTUAL_MESSAGE = ''
        self.LAST_MESSAGE = ''
        self.connection = MQTTConnect()


def on_message_subscribed(client, userdata, message):
    """
    Event on new MQTT message.

    Args:
        client: newClient
            MQTT client, instance of newClient class
        userdata: str
        message: str
            Message received from MQTT

    Returns:
        None

    Raises:
        None
    """
    RECEIVED_RAW = message.payload
    message_b85_decoded = base64.b85decode(message.payload) # decode from Base85
    # message_b85_decoded = base64.b64decode(RECEIVED_RAW)
    client.LAST_MESSAGE = client.ACTUAL_MESSAGE # copy actual message to last message
    client.ACTUAL_MESSAGE = message_b85_decoded

    if MQTT_DEBUG and False: # print info
        s_print('RECEIVED_RAW: ', RECEIVED_RAW,
         '\tLength(raw): ', len(RECEIVED_RAW),
         '\tLength(decoded): ', len(message_b85_decoded),
         '\tOverhead: ', round((len(RECEIVED_RAW)/len(message_b85_decoded)), 2))
        s_print('message_b85_decoded: ', message_b85_decoded)

    # split_message(message_b85_decoded, DEBUG=False)



def on_log(client, userdata, level, buf):
    """
    Event on new MQTT log.

    Args:
        client: newClient
            MQTT client, instance of newClient class
        userdata: str
        level: int
            level of log
        buf: str
            log message

    Returns:
        None

    Raises:
        None
    """
    if LOGGING and MQTT_DEBUG_LEVEL >= 1:
        s_print("log: ",buf, userdata, level)

def on_connect(client, userdata, flags, rc):
    """
    Event on new MQTT connection.

    Args:
        client: newClient
            MQTT client, instance of newClient class
        userdata: str
        flags: ?
        rc: int
            returned code

    Returns:
        None

    Raises:
        None
    """
    if rc != 0:
        s_print("Bad connection Returned code=",rc)
    else:
        # s_print('connected', userdata, flags, rc)
        pass



def createClient(name_input, sub_topic='', DEBUG = False):
    """
    Create new MQTT client and hook event functions

    Args:
        name_input: str
            name of new client
        sub_topic: str
            name of topic to subscribe
        DEBUG: bool
            Default: False, switches on additional debug printing

    Returns:
        client: newClient

    Raises:
        None
    """
    
    if name_input == '':
        name_input = other.randomString(5)        
    client = newClient(name_input)
    client.on_message = on_message_subscribed   # hook event functions
    client.on_log = on_log
    client.on_connect = on_connect
    # client.connect(BROKER, port=PORT)
    client.connect(host=client.connection.BROKER, port=client.connection.PORT)
    client.loop_start() # mqtt loop runs as separate thread
    if sub_topic != '':
        if DEBUG:
            s_print('Subscribed topic: ', sub_topic)
        subscribe(client, sub_topic, QoS=0, DEBUG = MQTT_DEBUG)
    if DEBUG:
        s_print('Created client: ', name_input)

    return client


def clientStop(client):
    """
    Disconnects and stops selected client

    Args:
        client: newClient
            client to be stopped

    Returns:
        None

    Raises:
        None
    """
    client.disconnect()  # disconnect
    client.loop_stop()  # stop loop


def subscribe(client, topic, QoS=0, DEBUG = MQTT_DEBUG):
    """
    Client subscribes selected topic and starts MQTT loop

    Args:
        client: newClient
            client to be stopped
        topic: str
            name of topic to subscribe
        QoS: int
            Quality of service for selected topic
        DEBUG: bool
            Switches on additional debug printing

    Returns:
        None

    Raises:
        None
    """
    # client.on_message = on_message_subscribed
    # # client.connect(host=BROKER, port=PORT)  # connect
    # client.connect(host=client.connection.BROKER, port=client.connection.PORT)  # connect
    # sleep(0.2)
    if DEBUG:
        s_print(client.is_connected)
    client.loop_start() # mqtt loop runs as separate thread
    sleep(0.2)
    client.subscribe(topic, qos=QoS)
    #     return True
    # else:
    #     return False

# def subscribe_loop(client):
#     while(1):
#         # client.connect(host=BROKER, port=PORT)  # connect
#         client.connect(host=client.connection.BROKER, port=client.connection.PORT)
#         client.on_message = on_message_subscribed
#         if client.is_connected:
#             client.loop_start()
#             ret = client.subscribe("#", qos=0)
#             sleep(0.00000001)
#             client.disconnect()  # disconnect
#             client.loop_stop()  # stop loop
#         else:
#             s_print("Client not connected")
#             sleep(1)


def unsubscribe(client, topic):
    """
    Client unsubscribes selected topic

    Args:
        client: newClient
            client to be stopped
        topic: str
            name of topic to unsubscribe

    Returns:
        None

    Raises:
        None
    """
    client.unsubscribe(topic)


def publish(client, topic, message, QoS=0, DEBUG=False):
    """
    Client publishes message in selected topic

    Args:
        client: newClient
            client to be stopped
        topic: str
            name of topic to unsubscribe
        message: str
            message to publish
        QoS: int
            Quality of service for selected topic
        DEBUG: bool
            Switches on additional debug printing

    Returns:
        True if published / False if not published

    Raises:
        None
    """

    client.connect(host=client.connection.BROKER, port=client.connection.PORT)
    if client.is_connected:
        client.loop_start() # mqtt loop runs as separate thread, also it probably should be started only for subscribing
        message_encoded = base64.b85encode(message)
        not_published_counter = 0
        loop_start_time = now()
        stucked = False
        while (1):
            ret = client.publish(topic=topic, payload=message_encoded, qos=QoS) 
            sleep(0.00000001)
            if ret.is_published() == True:      # check if data was published
                if not_published_counter > 0 and DEBUG:
                    s_print('Not published: ', not_published_counter)
                break
            else:
                not_published_counter += 1
                break
            if now() - loop_start_time > 1:
                s_print(Fore.YELLOW ,'Stuck in sending, not published ', not_published_counter, Fore.RESET)
                stucked = True
                # break
            ret = None

        client.disconnect()  # disconnect
        client.loop_stop()  # stop loop
        if DEBUG:
            s_print('MQTT Publish message encoded: ', message_encoded)
    else:
        s_print('Client not connected to broker')

    if ret.is_published() == True:      # if message published
        client.LAST_MESSAGE = client.ACTUAL_MESSAGE
        client.ACTUAL_MESSAGE = message
        return True
    else:
        return False

def save_message_to_frame(message, frame, DEBUG = False): 
    """
    Obsolete. Converts MQTT message into internal frame format

    Args:
        frame: dict
            dictionary that holds other dictionaries in format {'param': {'value_name': value}}
        message: str
            message convert
        DEBUG: bool
            Switches on additional debug printing

    Returns:
        None

    Raises:
        None
    """
    coursor_recv_mgs = 0
    splitted = []
    for localdict in frame:
        if localdict['type'] == 'h':
            converted = int.from_bytes(message[coursor_recv_mgs:coursor_recv_mgs+1], byteorder='big')
            splitted.append(converted)
            localdict['value'] = converted
            coursor_recv_mgs += 2
            
        if localdict['type'][-1] == 's':
            length = int(localdict['type'][: -1])
            converted = message[coursor_recv_mgs:coursor_recv_mgs+length]
            splitted.append(converted)
            coursor_recv_mgs += length

    localdict['value'] = converted

    if DEBUG == True and MQTT_DEBUG_LEVEL >= 0:
        s_print('splitted: ', splitted)


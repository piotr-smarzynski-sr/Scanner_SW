"""
Module tcp_communication - interface with TCP sockets

Functions:
    socketCreatorTCP2: Thread awaits for new connections 
        and passes them to new threads of subCartController

    macToCartID: Assign ID to cart basing on MAC address
"""

import socket
import struct
import sys
from time import sleep
from queue import Queue
from threading import Thread

from colorama import init, Fore

from db_communication import cartCheckExistence, cartInsertDefault
from msg.communication_payloads import CartHello, CartHelloResp
from msg.messages import buildMessage
import msg.messages
import orders_queued
from thread_print import s_print

init(convert=True) # COLORAMA
queues = []

class RawMessage(object):
    def __init__(self, payload_type, cart_id, payload_bytes):
        self.payload_type = payload_type
        self.cart_id = cart_id
        self.payload_bytes = payload_bytes

class TCPMessagingConnection(object):
    """
    Class for handling TCP connection

    Attributes:
        cart_id: int
            Cart no
        client_socket: socket
            Communication socket
        client_addr: tuple
            (IP address, Port)
        buffer: bytearray
            Incoming message buffer

    Methods:
        bufferToRaw:
        sendMessage:
        tryReceive:
        receiveMessages:
        receiveMessageBlocking:
        connectionClose:
    """
    def __init__(self, client_socket, addr):
        """
        Args:

        Returns:
            None

        Raises:
            None
        """
        #Cart possibly not addressed yet
        self.cart_id = 0xFFFF
        self.client_socket = client_socket
        self.client_addr = addr
        # Set client socket non-blocking
        self.client_socket.setblocking(False)
        # TODO LEARN check if setting/resetting blocking is cheap and has no side effects
        self.buffer = bytearray()

    def bufferToRaw(self, length, headersize, payload_type, cart_id):
        message_bytes = self.buffer[0:length]
        self.buffer = self.buffer[length:]
        payload_bytes = message_bytes[headersize:]
        msg = RawMessage(payload_type, cart_id, payload_bytes)
        return msg

    def sendMessage(self, message):
        message_tx_bytes = msg.messages.buildMessage(message, self.cart_id)
        self.client_socket.send(message_tx_bytes)

    def tryReceive(self):
        BLOCKSIZE = 256 # Maximal number of bytes received in 1 call
        try:
            rxdata = self.client_socket.recv(BLOCKSIZE)
            self.buffer = self.buffer + rxdata

        except socket.error as e:
            if e.errno == socket.errno.EWOULDBLOCK:
                pass
            # elif e.errno == socket.errno.WSAECONNRESET:
            #     pass
            else:
                # if e.errno == socket.errno.WSAECONNRESET:
                # s_print('tryReceive: Socket errno:', e.errno)
                raise e

    def receiveMessages(self):
        """
        Receives messages
        If message was compelelty received, returns empty array ([])
        If multiple messages were compelelty received, they are returned in array
        """
        HEADERSIZE = 7 # Size of header

        # Try to receive some bytes, if bytes received: append to buffer
        self.tryReceive()
        messages = []
        while len(self.buffer) >= HEADERSIZE:
            #Header will always be at the front of buffer
            length, payload_type, cart_id = struct.unpack('>BIH', self.buffer[0:7])
            payload_length = length - HEADERSIZE
            # Check if whole payload was received
            if len(self.buffer) >= length:
                msg = self.bufferToRaw(length, HEADERSIZE, payload_type, cart_id)
                messages.append(msg)
            else:
                break

        return messages

    def receiveMessageBlocking(self):
        HEADERSIZE = 7 # Size of header
        while True:
            self.tryReceive()
            if len(self.buffer) >= HEADERSIZE:
                #Header will always be at the front of buffer
                length, payload_type, cart_id = struct.unpack('>BIH', self.buffer[0:7])
                payload_length = length - HEADERSIZE
                # Check if whole payload was received
                if len(self.buffer) >= length:
                    msg = self.bufferToRaw(length, HEADERSIZE, payload_type, cart_id)
                    return msg

    def connectionClose(self):
        self.client_socket.close()
        self.buffer = None
        self.cart_id = None
        self.client_addr = None
        self.client_socket = None

def acceptNewConnection(host, port):
    sock = socket.socket()
    sock.bind((host, port))
    s_print(Fore.LIGHTGREEN_EX+ 'TCP waiting for next client on port', port, Fore.RESET)
    sock.listen(1)    # Now wait for client connection.
    client_socket, addr = sock.accept()    # Establish connection with client - blocking command
    conn = TCPMessagingConnection(client_socket, addr)
    return conn



def socketCreatorTCP2(threads, interface, port):
    """
    Wait for new connection and pass them to new threads

    Args:
        threads: list
            list of active threads
        interface: str
            IP address of server e.g '0.0.0.0'
        port: int
            port on which server waits for connection.
            50000 - carts, 40000 - stations, 30000 - junctions
    Returns:
        None

    Raises:
        None
    """
    # TODO expand functionality to handle station and junction connection
    # Junction simulator can be simplified to simple DB check
    function_name = Fore.LIGHTCYAN_EX+"socketCreatorTCP:"+Fore.RESET
    while True:
        conn = acceptNewConnection(interface, port) # blocking command
        s_print('Accepted connection from', conn.client_addr)
        hello_message = conn.receiveMessageBlocking()
        if hello_message.payload_type != CartHello.MSG_TYPE:
            s_print(function_name, Fore.LIGHTRED_EX, 'Wrong hello message type!', Fore.RESET, hello_message.payload_type)
        elif hello_message.payload_type == CartHello.MSG_TYPE:
            # --------------------- INITIAL MESSAGE PARSE AND ANSWER --------------------
            hello = CartHello.Deserialize(hello_message.payload_bytes)
            cart_id = macToCartID(hello.mac_address)
            db_ok, exists = cartCheckExistence(cart_id)
            if exists is False:
                print('Creating cart '+str(cart_id)+' in DB')
                cartInsertDefault(cart_id)

            s_print(function_name, 'Connected from MAC address: ', hello.mac_address, 'assigned ID:', cart_id)
            resp = CartHelloResp(cart_id)
            conn.sendMessage(resp)
            conn.cart_id = cart_id
            conn.client_addr
            client_name = cart_id
            queue_index = 0
            queue_found = False

            for queue_index, queue in enumerate(queues):
                if queue[0] == client_name:
                    queue_found = True
                    s_print(function_name, "Found queue for connection", conn.client_addr)
                    break

            if queue_found == False:
                queues.append((client_name, Queue()))
                s_print(function_name, "Creating queue for Cart ID", cart_id)
                queue_index = -1

            s_print(function_name, 'Assigning queue', queues[queue_index][0], 'for', 'C'+str(client_name))
            threads.append(Thread(target=orders_queued.subCartController,
                                name='C'+str(client_name),
                                kwargs={'connection': conn,
                                        'tracked_cart_name' : client_name,
                                        'queue_input':queues[queue_index],
                                        'queue_output' : orders_queued.cart_dispatcher_from_sub_cart_controller_q},
                                daemon=True))

            for thread in threads:
                if thread.name == 'C'+str(client_name): # and thread.is_alive() == False:
                    thread.start()
                    s_print(function_name, 'Thread', thread.name, 'started')
                    break

def macToCartID(mac_address):
    """
    Assign ID to cart basing on MAC address

    Args:
        mac_address: list
            6 bytes MAC address
    Returns:
        cart_id: int

    Raises:
        None
    """
    '''
    TODO
    check this in DB
    '''
    if mac_address[:5] == (252, 119, 116, 101, 200):
        cart_id = mac_address[5]

    # REAL EVALUATION BOARD MAC
    elif mac_address == (48, 132, 216, 5, 240, 248):
        cart_id = 1

    return cart_id

from keyboard import is_pressed
from colorama import Fore
import db_communication
from thread_print import s_print
from orders_queued import cart_dispatcher_from_sub_cart_controller_q
from other import print_dict, Timer


hotkeys_dict = {
    'Order and cart prepare': 'o+1',
    'Orders get available'  : 'o+2',
    'Carts get available'   : 'o+3',
    'hotkey_list'           : 'h+1',
    'GetIP'                 : 'f+1',
    'GetRSSI'               : 'f+2',
    'GetSSID'               : 'f+3',
    'GetWiFiChannel'        : 'f+4',
    'GetWiFiStatus'         : 'f+5'
    }

def keyboardHandler():
    """
    Thread for handling keyboard shortcuts.

    Args:
        None

    Returns:
        None

    Raises:
        None
    """
    '''
    TODO
    przerobić to na keyboard.add_hotkey
    https://pypi.org/project/keyboard/
    '''
    keyboard_timer = Timer()
    test_order_count = 0
    print_dict(hotkeys_dict, prefix='# HOTKEYS #', suffix='-----------------')
    while True:
        if keyboard_timer.fromStart() > 0.2:
            keyboard_timer.reset()

            if is_pressed(hotkeys_dict['Order and cart prepare']):
                db_ok = db_communication.addNewOrder(2, 5, 0, 7, 0, cargo_type=6, status=1, text_status='Test_'+str(test_order_count), DEBUG=True)
                s_print('save ok: ', db_ok)
                db_ok = db_communication.cartUpdateOrder(96, 0)
                if db_ok is True:
                    s_print('cart update order: ', db_ok)
                elif db_ok is False:
                    s_print('cart update order:', Fore.LIGHTRED_EX, db_ok, Fore.RESET)
                test_order_count += 1

            elif is_pressed(hotkeys_dict['Orders get available']):
                s_print('\n', 'Orders get available, ', hotkeys_dict['Orders get available'], 'shortcut')
                db_ok, output = db_communication.getAvailableOrder()
                s_print('output: ', output)

            elif is_pressed(hotkeys_dict['Carts get available']):
                s_print('\n', 'Carts get available, ', hotkeys_dict['Carts get available'], 'shortcut')
                db_ok, output = db_communication.getAvailableCarts()
                s_print('output: ', output)

            elif is_pressed(hotkeys_dict['hotkey_list']):
                print_dict(hotkeys_dict, prefix='################', suffix='-----------------')
            
            elif is_pressed(hotkeys_dict['GetIP']):
                cart_dispatcher_from_sub_cart_controller_q.put({'ID': 0, 'command': 'GetIP', 'parameter': ''})
            elif is_pressed(hotkeys_dict['GetRSSI']):
                cart_dispatcher_from_sub_cart_controller_q.put({'ID': 0, 'command': 'GetRSSI', 'parameter': ''})
            elif is_pressed(hotkeys_dict['GetSSID']):
                cart_dispatcher_from_sub_cart_controller_q.put({'ID': 0, 'command': 'GetSSID', 'parameter': ''})
            elif is_pressed(hotkeys_dict['GetWiFiChannel']):
                cart_dispatcher_from_sub_cart_controller_q.put({'ID': 0, 'command': 'GetWiFiChannel', 'parameter': ''})
            elif is_pressed(hotkeys_dict['GetWiFiStatus']):
                cart_dispatcher_from_sub_cart_controller_q.put({'ID': 0, 'command': 'GetWiFiStatus', 'parameter': ''})
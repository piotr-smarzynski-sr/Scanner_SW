'''
search and replace regex \x1b\[[0-9;]*m to nothing to make logs more readable
'''



import re
filename = 'main_app_20200618_070644.log'
escapes = "\x1b\[[0-9;]*m"


with open(filename, 'w') as f:
    for line in f:
        line = re.sub(r"\x1b\[[0-9;]*m", "", line)

f.close()

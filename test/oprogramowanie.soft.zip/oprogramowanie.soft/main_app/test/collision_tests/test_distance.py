import psycopg2

from other import print_dict
"""
TODO
save passwords to json and encrypt them
Decrypt passwords in every DB operation
"""

# credentials for DB
USER = "piotr"
PASSWORD = "admin"
HOST = "127.0.0.1"
PORT = "5432"
DATABASE = "rollercoaster"

DETECTION_DISTANCE = 50

def cartsOnTrack(track_name):
    """Return carts numbers occupying specific track.

    Args:
        track_name: int
            track_name is  e.g. 4

    Returns:
        True if input data type is ok / False if input data type is wrong
        If first return is True:
            List with cart numbers
        If first return is False:
            {}

    Raises:
        None
    """
    assert isinstance(track_name, int), "Bad track_name"
    select_output = {}
    output_dict = {}
    connection = psycopg2.connect(user=USER,
                                  password=PASSWORD,
                                  host=HOST,
                                  port=PORT,
                                  database=DATABASE)

    dbCoursor = connection.cursor()
    sql_query = "SELECT no, track_position FROM carts WHERE track_actual = %s"
    params = (track_name, )
    dbCoursor.execute(sql_query, params)
    connection.commit()
    select_output = dbCoursor.fetchall()
    dbCoursor.close()
    connection.close()
    return True, select_output


def detectCollisions(cart_location, direction, range, DEBUG=False):
    """Detect collision in given range
        FUTURE FEATURE
        basing on cart location and direction, route is set to next junction/station
        route is iterated from start to end, if first cart is found which name is different than 
        cart detecting for collision, iteration stops
        distance to collision is calculated basing on this algoritm:
           if direction == FWD:
              if len(route_to_junction) == 1:
                distance = colliding_cart_pos_mm - cart_pos_mm
              if len(route_to_junction) == 2:
                distance = cart_actual_track_length - cart_pos_mm
                distance += colliding_cart_pos_mm
              if len(route_to_junction) > 2:
                distance = cart_actual_track_length - cart_pos_mm
                distance += route[2].length_mm
                distance += route[3].length_mm
                distance += route[4].length_mm
                ...
                distance += route[-2].length_mm
                distance += colliding_cart_pos_mm
           if direction == BWD:
              if len(route_to_junction) == 1:
                distance = cart_pos_mm - colliding_cart_pos_mm
              if len(route_to_junction) == 2:
                distance = cart_pos_mm
                distance += route[2].length_mm - colliding_cart_pos_mm
              if len(route_to_junction) > 2:
                distance = cart_pos_mm
                distance += route[2].length_mm
                distance += route[3].length_mm
                distance += route[4].length_mm
                ...
                distance += route[-2].length_mm
                distance += route[-1].length_mm - colliding_cart_pos_mm



    Args:
        cart_location: tuple (int, int)
            location of cart in map (track_no, track_pos_mm)
        direction: int
            1 - FWD, 2 - BWD
        range: int
            range of collision detection in mm

    Returns:
        collision_detected: bool
            if collision was detected within range
        distance_to_collision: int
            distance to closest collision

    Raises:
        None
    """
    distance_to_collision = range
    collision_detected = False
    if DEBUG:
        print('cart_location: ', cart_location)
        print('direction: ', direction)
        print('range: ', range)

    if DEBUG:
        print('distance_to_collision: ', distance_to_collision)
        print('collision_detected: ', collision_detected)

    return collision_detected, distance_to_collision

db_ok, output = cartsOnTrack(2)

if isinstance(output, dict):
    print_dict(output)
else:
    print('output: ', output)

detectCollisions(output[0], 1, 50, DEBUG=True)
from queue import Queue
from orders_functions import queueToStr

myQ = Queue()
myQ2 = Queue()

myArr = [1, 2, 3, 4, 5, 6, 7, 8, 9]

for index, value in enumerate(myArr):
    myQ.put(value)
    myQ2.put(value)

print('Qsize myQ: ', myQ.qsize())
print('Qsize myQ2: ', myQ2.qsize())
myQ_list = queueToStr(myQ)
print('myQ_list: ', myQ_list)

print('Qsize myQ: ', myQ.qsize())


while (myQ.empty() is False):
    print('q1: ', myQ.get())

print()

while (myQ2.empty() is False):
    print('q2: ', myQ2.get())
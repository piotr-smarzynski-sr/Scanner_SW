from threading import Thread
import socket
from time import sleep
import cart_updater_udp
from thread_print import s_print

#---------------- GLOBAL ---------------------
UDP_LISTENER_IP = "0.0.0.0"
RX_PORT = 60000     # UDP RX port

# ---------------- UDP SOCKET CONFIG-----------------------
socket_receive = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
socket_receive.bind((UDP_LISTENER_IP, RX_PORT))

threads = [] # list holding all threads
# threads receives cart data over udp and updates it in DB
threads.append(Thread(target=cart_updater_udp.cartUpdaterUDP2,
                      name="cartUpdaterUDP2",
                      kwargs={'socket_receive':socket_receive},
                      daemon=True))

# ----- Threads start and print names -------------------------
if len(threads) > 0:
    output = ''
    for thread in threads:
        if not thread.name.startswith('C'):
            thread.start()
            output += "Starting thread "
            output += thread.getName()
            output += ', alive: '
            output += str(thread.is_alive())
            output += '\n'

    s_print(output)

while True:
    sleep(1)
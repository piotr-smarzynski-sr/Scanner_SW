from msg.travel_payloads import GoDist

from msg.messages import buildMessage, parseMessage

def correctMessageTypes():
    import msg.travel_payloads as travel_payloads
    classes = dict([(MSG_TYPE, cls) for MSG_TYPE, cls in travel_payloads.__dict__.items() if isinstance(cls, type)])
    # print('classes: ', classes)
    correct_msg_types = []
    for key in classes:
        correct_msg_types.append(classes[key].MSG_TYPE)

    return correct_msg_types

correct_msg_types = correctMessageTypes()

# msg1 = GoDist(134, 2)
msg1 = GoDist(distance=164, direction=1)

cart_id= 0x235
message_bytes = buildMessage(msg1, cart_id)

# "Transmit" message
received_bytes = b''

# # starting noise
# received_bytes += b'DUPA12345'

# main message
received_bytes += message_bytes

# possible message concatenate
msg2 = GoDist(distance=99, direction=2)
cart_id= 0x235
message_bytes2 = buildMessage(msg2, cart_id)
received_bytes += message_bytes2

# # middle noise
# received_bytes += b'DUPA12345'

# second concatenate
msg3 = GoDist(distance=14, direction=1)
cart_id= 0x235
message_bytes3 = buildMessage(msg3, cart_id)
received_bytes += message_bytes3

# # end noise
# received_bytes += b'DUPA541231'

print('-------- MESSAGE PARSING --------------')
while (1):
    rejected = b''
    while type not in correct_msg_types:
        try:
            type, rx_cart_id, payload_bytes, length = parseMessage(received_bytes)
        except:
            print("Invalid header")
            break
        rejected += received_bytes[0].to_bytes(1, 'big')
        received_bytes = received_bytes[1:]

    if len(rejected) > 0:
        print('rejected: ', rejected)

    
    if length < len(payload_bytes):
        print('expected length: ', length)
        print('len(payload_bytes): ', len(payload_bytes))
        rx_bytes_buffer = payload_bytes[length:]
        payload_bytes = payload_bytes[:length]
        print('rx_bytes_buffer: ', rx_bytes_buffer)

    if type == GoDist.MSG_TYPE:
        received_message = GoDist.Deserialize(payload_bytes)
        payload_bytes = b''
        print("RX: Cart id:",hex(rx_cart_id), "dir:", received_message.direction, 'dist:' ,received_message.distance)

    if len(payload_bytes) == 0:
        if  len(rx_bytes_buffer) != 0:
            received_bytes = rx_bytes_buffer
            rx_bytes_buffer = b''
            type = 0

        elif len(rx_bytes_buffer) == 0:
            print('Parsing END')
            break


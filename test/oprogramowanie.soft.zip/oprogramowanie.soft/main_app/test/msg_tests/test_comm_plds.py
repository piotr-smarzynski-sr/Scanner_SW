from msg.communication_payloads import GetWiFiStatusResp

def testCode():
    message_tx = GetWiFiStatusResp((192,168,0,1), 'siec_001', (16,8,35,124,65,2), -7, 4)
    message_bytes = message_tx.serialize()

    message_rx = GetWiFiStatusResp.Deserialize(message_bytes)
    print('message_rx.MSG_TYPE: ', hex(message_rx.MSG_TYPE))
    print('message_rx.ip_addr: ', message_rx.ip_addr)
    print('message_rx.ssid: ', message_rx.ssid)
    print('message_rx.bssid: ', message_rx.bssid)
    print('message_rx.rssi: ', message_rx.rssi)
    print('message_rx.channel: ', message_rx.channel)

testCode()
from thread_print import s_print
from colorama import init as colorama_init
from colorama import Fore

colorama_init(convert=True)

def testCode():
    function_name = Fore.YELLOW+' testCode: '+Fore.RESET
    s_print(function_name, "Hello")

testCode()
import json
from pathfinder.graph import Graph, Edge
from pathfinder.pathfinder import Pathfinder

class Track:
    def __init__(self, name_input, no_input, length_mm_input, stopper_start_input, stopper_end_input, prev_track_input, prev_track_all_input, next_track_input, next_track_all_input, prev_track_connects_with_start_input, next_track_connects_with_start_input, is_station_input, is_crossroad_input, max_speed_input, max_carts_input):
        self.name = name_input                   # nazwa toru
        self.no = no_input                       # numer toru
        self.length_mm = length_mm_input         # długość toru, jednostka umowna
        self.stopper_start = stopper_start_input       # Czy na początku (pozycja 0 mm) znajduje się zakończenie toru/element nieprzejezdny/przeszkoda
        self.stopper_end = stopper_end_input           # Czy na końcu (pozycja length_mm_input mm) znajduje się zakończenie toru/element nieprzejezdny/przeszkoda
        self.prev_track = prev_track_input             # aktualnie połączony odcinek z początkiem toru. Musi się znajdować na liście prev_track_all_input
        self.prev_track_all = prev_track_all_input     # lista torów połączonych z początkiem odcinka. Zwrotnica może posiadać 2 i więcej
        self.next_track = next_track_input             # aktualnie połączony odcinek z końcem toru. Musi się znajdować na liście next_track_all_input
        self.next_track_all = next_track_all_input     # lista torów połączonych z końcem odcinka. Zwrotnica może posiadać 2 i więcej
        self.prev_track_connects_with_start = prev_track_connects_with_start_input # czy poprzedni odcinek łączy się początkiem czy końcem
        self.next_track_connects_with_start = next_track_connects_with_start_input # czy kolejny odcinek łączy się początkiem czy końcem
        self.is_station = is_station_input       # wiadomo
        self.is_crossroad = is_crossroad_input   # wiadomo
        self.max_speed = max_speed_input         # wiadomo
        self.max_carts = max_carts_input         # wiadomo

track_system = []
#HACK

#True, false
STP_BEGIN_ON = None
STP_BEGIN_OFF = None

STP_END_ON = None
STP_END_OFF = None

#Czy poprzedni tor łączy się ostatnim mm do (o.P1->o.P0)
PRV_CONN_END = None

#Następny tor zaczyna się początkiem do obecnego końca (P1->P0)
NEXT_CONN_BEGIN = None

NOT_STATION = None
NOT_CROSSROAD = None

# track_system.append(Track("T0", 0, 20, STP_BEGIN_ON, STP_END_OFF, "T5", ["T5"], "T1", ["T1"], [PRV_CONN_END], [NEXT_CONN_BEGIN], NOT_STATION, NOT_CROSSROAD, 3, 1))
# track_system.append(Track("T1", 1, 40, STP_BEGIN_OFF, STP_END_OFF, "T0", ["T0"], "T2", ["T2"], [PRV_CONN_END], [NEXT_CONN_BEGIN], NOT_STATION, NOT_CROSSROAD, 3, 1))
# track_system.append(Track("T2", 2, 30, STP_BEGIN_OFF, STP_END_OFF, "T1", ["T1"], "T6", ["T3"], [PRV_CONN_END], [NEXT_CONN_BEGIN], NOT_STATION, NOT_CROSSROAD, 3, 1))
# track_system.append(Track("T3", 3, 30, STP_BEGIN_OFF, STP_END_OFF, "T2", ["T2"], "T4", ["T4"], [PRV_CONN_END], [NEXT_CONN_BEGIN], NOT_STATION, NOT_CROSSROAD, 3, 1))
# track_system.append(Track("T4", 4, 40, STP_BEGIN_OFF, STP_END_OFF, "T3", ["T3"],  "T5", ["T5"], [PRV_CONN_END], [NEXT_CONN_BEGIN], NOT_STATION, NOT_CROSSROAD, 3, 1))
# track_system.append(Track("T5", 5, 50, STP_BEGIN_OFF, STP_END_ON, "T4", ["T4"], "T0", ["T0"], [PRV_CONN_END], [NEXT_CONN_BEGIN], NOT_STATION, NOT_CROSSROAD, 3, 1))
# track_system.append(Track("T6", 6, 50, STP_BEGIN_OFF, STP_END_ON, "T8", ["T8"], "T7", ["T7"], [PRV_CONN_END], [NEXT_CONN_BEGIN], NOT_STATION, NOT_CROSSROAD, 3, 1))
# track_system.append(Track("T7", 7, 50, STP_BEGIN_OFF, STP_END_ON, "T6", ["T6"], "T8", ["T8"], [PRV_CONN_END], [NEXT_CONN_BEGIN], NOT_STATION, NOT_CROSSROAD, 3, 1))
# track_system.append(Track("T8", 8, 50, STP_BEGIN_OFF, STP_END_ON, "T7", ["T7"], "T6", ["T6"], [PRV_CONN_END], [NEXT_CONN_BEGIN], NOT_STATION, NOT_CROSSROAD, 3, 1))

track_system.append(Track(0, 0, 20, STP_BEGIN_ON, STP_END_OFF, 5, [5], 1, [1], [PRV_CONN_END], [NEXT_CONN_BEGIN], NOT_STATION, NOT_CROSSROAD, 3, 1))
track_system.append(Track(1, 1, 40, STP_BEGIN_OFF, STP_END_OFF, 0, [0], 2, [2], [PRV_CONN_END], [NEXT_CONN_BEGIN], NOT_STATION, NOT_CROSSROAD, 3, 1))
track_system.append(Track(2, 2, 30, STP_BEGIN_OFF, STP_END_OFF, 1, [1], 6, [3], [PRV_CONN_END], [NEXT_CONN_BEGIN], NOT_STATION, NOT_CROSSROAD, 3, 1))
track_system.append(Track(3, 3, 30, STP_BEGIN_OFF, STP_END_OFF, 2, [2], 4, [4], [PRV_CONN_END], [NEXT_CONN_BEGIN], NOT_STATION, NOT_CROSSROAD, 3, 1))
track_system.append(Track(4, 4, 40, STP_BEGIN_OFF, STP_END_OFF, 3, [3],  5, [5], [PRV_CONN_END], [NEXT_CONN_BEGIN], NOT_STATION, NOT_CROSSROAD, 3, 1))
track_system.append(Track(5, 5, 50, STP_BEGIN_OFF, STP_END_ON, 4, [4], 0, [0], [PRV_CONN_END], [NEXT_CONN_BEGIN], NOT_STATION, NOT_CROSSROAD, 3, 1))
track_system.append(Track(6, 6, 50, STP_BEGIN_OFF, STP_END_ON, 8, [8], 7, [7], [PRV_CONN_END], [NEXT_CONN_BEGIN], NOT_STATION, NOT_CROSSROAD, 3, 1))
track_system.append(Track(7, 7, 50, STP_BEGIN_OFF, STP_END_ON, 6, [6], 8, [8], [PRV_CONN_END], [NEXT_CONN_BEGIN], NOT_STATION, NOT_CROSSROAD, 3, 1))
track_system.append(Track(8, 8, 50, STP_BEGIN_OFF, STP_END_ON, 7, [7], 6, [6], [PRV_CONN_END], [NEXT_CONN_BEGIN], NOT_STATION, NOT_CROSSROAD, 3, 1))
#---------------------------------------------------------------------#

#Uwagi
# 1. Podczas tworzenia grafu ignoruję 
#   a) stopery
#   b) domyślne ustawienie rozjazdu
#   c) to czy węzeł jest rozjazdem, czy jest stacją
# 2. To, czy węzeł łączy się 'początkiem do końca' czy 'początkiem do początka' itp. ustalam na podstawie
#    samych list połączeń. Zapisuje to w grafie, ale nie wykorzysuje tego do samego wyszukiwania trasy.


g = Graph.FromTrackList(track_system)
# g = Graph.FromTrackListDB()
g.buildNeighborhood()

#Alternatywnie, wczytywanie z pliku, aczkolwiek dane wczytywane z pliku to tylko podstawowe informacje o grafie
#f = open('basic1.track.json')
#root = json.load(f)
#g = Graph.FromJson(root['graph'])
#g.buildNeighborhood()


print(g)
pf = Pathfinder(g)
g.setEdgeHardDirection(2, 1, Edge.Direction.NONE) # Disallow moving between T2 and T1
g.setEdgeHardDirection(4, 3, Edge.Direction.FWD) # Only allow rides from T4 to T3
print("Track from T0 to T5:")
print(pf.plan(0, 5))

g.setEdgeHardDirection(2,1, Edge.Direction.ANY) # Allow moving between T2 and T1 in any direction
print("Track from T0 to T2:")
print(pf.plan(0, 2))

g.setEdgeExtraCost(1,2, 500) # Add additional cost of traveling from track T1 to T2

print("Track from T0 to T2:")
print(pf.plan(0, 2))

g.setEdgeHardDirection(5,0, Edge.Direction.NONE) # Disallow moving between T5 and T0

print("Track from T0 to T2:")
print(pf.plan(0, 2))




import json
from pathfinder.graph import Graph, Edge
from pathfinder.pathfinder import Pathfinder
from pathfinder.simple_pathfinding import pathfinderInit, simplePathfinding

def testCode():
    tracks_map, pathfinder = pathfinderInit()
    route, cost = simplePathfinding(pathfinder, 2, 4)
    print('cost: ', cost)
    print('route: ', route)



def testCode1():
    tracks_map, pathfinder = pathfinderInit()
    route, cost = simplePathfinding(pathfinder, 2, 2)
    print('cost: ', cost)
    print('route: ', route)



testCode()
testCode1()
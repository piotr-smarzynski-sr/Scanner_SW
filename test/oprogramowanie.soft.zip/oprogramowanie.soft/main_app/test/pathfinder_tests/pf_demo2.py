import json
from pathfinder.graph import Graph, Edge
from pathfinder.pathfinder import Pathfinder

# CONFIG
g = Graph.FromTrackListDB()
g.buildNeighborhood()
pf = Pathfinder(g)

# ADDITIONAL SETTINGS
g.setEdgeHardDirection(2, 1, Edge.Direction.NONE) # Disallow moving between T2 and T1
g.setEdgeHardDirection(4, 3, Edge.Direction.FWD) # Only allow rides from T4 to T3
g.setEdgeExtraCost(1,2, 500) # Add additional cost of traveling from track T1 to T2

#CALCULATE
print("Track from T0 to T2:")
print(pf.plan(0, 2))
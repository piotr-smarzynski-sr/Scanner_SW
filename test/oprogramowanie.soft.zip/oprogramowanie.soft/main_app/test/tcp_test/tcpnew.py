import socket
import colorama
import struct

import msg.messages
from msg.communication_payloads import CartHello
from msg.communication_payloads import CartHelloResp

colorama.init(convert=True)

class RawMessage(object):
    def __init__(self, payload_type, cart_id, payload_bytes):
        self.payload_type = payload_type
        self.cart_id = cart_id
        self.payload_bytes = payload_bytes

class CartMessagingConnection(object):
    def __init__(self, client_socket, addr):
        #Cart possibly not addressed yet
        self.cart_id = 0xFFFF
        self.client_socket = client_socket
        self.client_addr = addr
        # Set client socket non-blocking
        self.client_socket.setblocking(False)
        # TODO LEARN check if setting/resetting blocking is cheap and has no side effects
        self.buffer = bytearray()

    def bufferToRaw(self, length, headersize, payload_type):
        message_bytes = self.buffer[0:length]
        self.buffer  = self.buffer[length:]
        payload_bytes = message_bytes[headersize:]
        msg = RawMessage(payload_type, cart_id, payload_bytes)
        return msg

    def sendMessage(self,message):
        message_tx_bytes = msg.messages.buildMessage(message, self.cart_id)
        self.client_socket.send(message_tx_bytes)

    def tryReceive(self):
        BLOCKSIZE = 256 # Maximal number of bytes received in 1 call
        try:
            rxdata  = self.client_socket.recv(BLOCKSIZE)
            self.buffer = self.buffer + rxdata

        except socket.error as e:
            if e.errno == socket.errno.EWOULDBLOCK:
                pass
            else:
                raise e
        
    def receiveMessages(self):
        """
        Receives messages
        If message was compelelty received, returns empty array ([])
        If multiple messages were compelelty received, they are returned in array
        """
        HEADERSIZE=7 # Size of header
        # Try to receive some bytes, if bytes received: append to buffer
        self.tryReceive()
        messages = []
        while len(self.buffer) >= HEADERSIZE:
            #Header will always be at the front of buffer
            length, payload_type, cart_id = struct.unpack('>BIH', self.buffer[0:7])
            payload_length = length - HEADERSIZE
            # Check if whole payload was received
            if len(self.buffer)  >= length:
                msg = self.bufferToRaw(length, HEADERSIZE, payload_type)
                messages.append(msg)
            else:
                break

        return messages

    def receiveMessageBlocking(self):
        HEADERSIZE=7 # Size of header
        while True:
            self.tryReceive()
            if len(self.buffer) >= HEADERSIZE:
                #Header will always be at the front of buffer
                length, payload_type, cart_id = struct.unpack('>BIH', self.buffer[0:7])
                payload_length = length - HEADERSIZE
                # Check if whole payload was received
                if len(self.buffer)  >= length:
                    # message_bytes = self.buffer[0:length]
                    # self.buffer  = self.buffer[length:]
                    # payload_bytes = message_bytes[HEADERSIZE:]
                    # msg = RawMessage(payload_type, cart_id, payload_bytes)
                    msg = self.bufferToRaw(length, HEADERSIZE, payload_type)
                    return msg

def acceptNewConnection(host, port):
    sock = socket.socket()
    sock.bind((host, port))
    print(colorama.Fore.LIGHTGREEN_EX+ 'TCP waiting for next client on port', port, colorama.Fore.RESET)
    sock.listen(1)    # Now wait for client connection.
    client_socket, addr = sock.accept()    # Establish connection with client - blocking command
    conn = CartMessagingConnection(client_socket, addr)
    return conn

# TEST
conn = acceptNewConnection("0.0.0.0", 50000) # blocking command
print('Accepted connection from', conn.client_addr)
hello_message = conn.receiveMessageBlocking()
print(hex(hello_message.payload_type))
if hello_message.payload_type == CartHello.MSG_TYPE:
    hello = CartHello.Deserialize(hello_message.payload_bytes)
    print(hello)
    # zakładamy, że stały adres zawsze
    # cart_id = macToIP(hello.mac_address)
    cart_id = 96
    resp = CartHelloResp(cart_id)
    conn.cart_id = cart_id
    conn.sendMessage(resp)

while True:
    conn.receiveMessages()
# credentials for DB
USER = "piotr"
PASSWORD = "admin"
HOST = "127.0.0.1"
PORT = "5432"
DATABASE = "rollercoaster"

def testCode2():
    import psycopg2
    import psycopg2.extras

    conn = psycopg2.connect(user=USER,
                            password=PASSWORD,
                            host=HOST,
                            port=PORT,
                            database=DATABASE)
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    cur.execute("""select *
                from information_schema.columns
                where table_schema NOT IN ('information_schema', 'pg_catalog')
                order by table_schema, table_name, column_name""")

    table_actual = ''
    table_last = ''
    for row in cur:
        # for key in row:
        #     print(key, ':', row[key])
        # print(row)
        # print()
        table_actual = row['table_name']
        if table_actual != table_last:
            print()
        # print("schema: {schema}, table: {table}, column: {col}, type: {type}".format(
        #     schema = row['table_schema'], table = row['table_name'],
        #     col = row['column_name'], type = row['data_type']))
        print("table: {table}, column: {col}, type: {type}".format(
            table = row['table_name'], col = row['column_name'], type = row['data_type']))
        table_last = table_actual


print('\ntestCode2:')
testCode2()
import psycopg2

from other import print_dict
"""
TODO
save passwords to json and encrypt them
Decrypt passwords in every DB operation
"""

# credentials for DB
USER = "piotr"
PASSWORD = "admin"
HOST = "127.0.0.1"
PORT = "5432"
DATABASE = "rollercoaster"

def isTrackOccupied2(track_name):
    """
    Return carts numbers occupying specific track.

    Args:
        track_name: int
            track_name is  e.g. 4

    Returns:
        True if input data type is ok / False if input data type is wrong
        If first return is True:
            List with cart numbers
        If first return is False:
            {}

    Raises:
        None
    """
    assert isinstance(track_name, int), "Bad track_name"
    select_output = {}
    output_dict = {}
    connection = psycopg2.connect(user=USER,
                                  password=PASSWORD,
                                  host=HOST,
                                  port=PORT,
                                  database=DATABASE)

    dbCoursor = connection.cursor()
    sql_query = "SELECT no, track_position FROM carts WHERE track_actual = %s"
    params = (track_name, )
    dbCoursor.execute(sql_query, params)
    connection.commit()
    select_output = dbCoursor.fetchall()
    dbCoursor.close()
    connection.close()    
    for cart in select_output:
        output_dict['no'] = cart[0]
        output_dict['position_mm'] = cart[1]

    return True, output_dict

db_ok, output = isTrackOccupied2(2)

if isinstance(output, dict):
    print_dict(output)
else:
    print('output: ', output)

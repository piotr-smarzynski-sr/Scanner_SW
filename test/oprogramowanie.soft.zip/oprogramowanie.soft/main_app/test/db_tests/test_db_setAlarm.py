import argparse

from db_communication import setAlarm
from other import Timer

#------------------ RUN ARGUMENTS HANDLE BEGIN ----------------
parser = argparse.ArgumentParser()
parser.add_argument("subsystem",
                    help='Single-letter name of subsystem: C/S/J/M',
                    choices=['C', 'S', 'J', 'M']
                    )

parser.add_argument("device_no",
                    help='Number of device in subsystem',
                    type=int)

parser.add_argument("code",
                    help='Error code to raise',
                    type=int)

parser.add_argument("-d", "--DEBUG", 
                    help='Turn debug printing on',
                    action="store_true")

args = parser.parse_args()
print('args: ', args)

#------------------ RUN ARGUMENTS HANDLE END ------------------
def testCode(subsystem, device_no, code, DEBUG=False):
    t1 = Timer()
    setAlarm(subsystem, device_no, code, DEBUG)
    print('run time:', t1.fromStart())

testCode(args.subsystem, args.device_no, args.code, args.DEBUG)
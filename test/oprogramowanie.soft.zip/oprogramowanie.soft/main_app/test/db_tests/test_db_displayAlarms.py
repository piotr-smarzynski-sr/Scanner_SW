import argparse

from db_communication import displayAlarmsCurrent
from other import Timer, print_dict

#------------------ RUN ARGUMENTS HANDLE BEGIN ----------------
parser = argparse.ArgumentParser()

parser.add_argument('language',
                    help='Set language of alarm description',
                    choices=['PL', 'EN', 'DE']
                    )

parser.add_argument("-d", "--DEBUG", 
                    help='Turn debug printing on',
                    action="store_true")

args = parser.parse_args()
print('args: ', args)

#------------------ RUN ARGUMENTS HANDLE END ------------------
def testCode(language, DEBUG=False):
    t1 = Timer()
    db_ok, output = displayAlarmsCurrent(language)
    print('run time:', t1.fromStart(), '\n')
    for record in output:
        output = ""
        output += str(record[0])    #subsystem
        output += str(record[1])    #device_no 
        output += "."
        output += str(record[2])    #code
        output += "\t"
        output += record[3]         #description in choosen language
        output += ". Cause:"
        output += str(record[4])    #cause active
        output += "\tRaised: "
        if record[5].hour < 10:
            output += "0"
        output += str(record[5].hour)   #raise time
        output += ":"
        if record[5].minute < 10:
            output += "0"
        output += str(record[5].minute)
        output += ":"
        if record[5].second < 10:
            output += "0"
        output += str(record[5].second)
        if record[6] is not None:
            output += "\t Gone: "
            if record[6].hour < 10:
                output += "0"
            output += str(record[6].hour)   #cause gone time
            output += ":"
            if record[6].minute < 10:
                output += "0"
            output += str(record[6].minute)
            output += ":"
            if record[6].second < 10:
                output += "0"
            output += str(record[6].second)

        print(output)

testCode(args.language, args.DEBUG)
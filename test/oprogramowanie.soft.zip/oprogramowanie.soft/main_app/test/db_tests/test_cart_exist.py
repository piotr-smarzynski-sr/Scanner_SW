from db_communication import cartCheckExistence, cartInsertDefault

cart_no = 90
db_ok, exists = cartCheckExistence(cart_no)
print('Cart '+str(cart_no)+' exists:', exists)

cart_no = 45
db_ok, exists = cartCheckExistence(cart_no)
print('Cart '+str(cart_no)+' exists:', exists)

cart_no = 51
db_ok, exists = cartCheckExistence(cart_no)
print('Cart '+str(cart_no)+' exists:', exists)
if exists is False:
    cartInsertDefault(cart_no)

cart_no = 98
db_ok, exists = cartCheckExistence(cart_no)
print('Cart '+str(cart_no)+' exists:', exists)

cart_no = 102
db_ok, exists = cartCheckExistence(cart_no)
print('Cart '+str(cart_no)+' exists:', exists)

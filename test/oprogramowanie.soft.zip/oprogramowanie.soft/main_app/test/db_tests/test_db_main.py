from db_communication import getAllTracks

def test_code():
    from functions.print_dict import print_dict
    # db_ok, output = getAvailableOrder()
    # s_print('db_ok: ', db_ok)
    # s_print('output: ', output)
    # s_print('len(output): ', len(output))

    # db_ok, output = getAvailableCarts()
    # s_print('db_ok: ', db_ok)
    # s_print('output: ', output)
    # s_print('len(output): ', len(output))

    # db_ok = orderUpdateStatus(342, 4, 'NG TEST')
    # s_print('db_ok: ', db_ok)

    # db_ok = addNewOrder(1, 'T0', 'T5', 2, 0, 3, 4, 'NG_TEST')
    # s_print('db_ok: ', db_ok)

    # db_ok, output = getCart('C96')
    # s_print('output: ', output)

    # db_ok, output = getOrder(418)
    # s_print('output: ', output)

    # db_ok, output = getTrack('T2')
    # s_print('output: ', output)

    db_ok, allTracks = getAllTracks()
    # print('allTracks: ', allTracks)
    output = ''
    for track in allTracks:
        for key in track:
            output += str(key)
            output += ': '
            output += str(track[key])
            output += '\n'

        print(output)
        output = ''

    # print(allTracks[0])
    # print(allTracks[0]['prev_no'])
    # print(allTracks[0]['prev_no_all'])
    # if allTracks[0]['prev_no'] in allTracks[0]['prev_no_all']:
    #     print('OK')

print('\ntestCode:')
test_code()
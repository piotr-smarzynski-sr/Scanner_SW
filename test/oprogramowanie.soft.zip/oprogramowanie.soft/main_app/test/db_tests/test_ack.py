from db_communication import acknowledgeAllAlarms
from other import Timer, print_dict

def testCode():
    t1 = Timer()
    db_ok = acknowledgeAllAlarms()
    print('run time:', t1.fromStart(), '\n')
    
testCode()
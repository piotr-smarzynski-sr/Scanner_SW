# target = __import__("db_communication.py")
# db_communication = target.db_communication


from db_communication import isTrackOccupied
from db_communication import getAllTracks # works for now, but only with local copy of module

# getAll_ok, track_list = getAllTracks()

def testCode3():   
    print('isTrackOccupied(2): ', isTrackOccupied(2))
    print('isTrackOccupied(3): ', isTrackOccupied(3))
    print('isTrackOccupied(4): ', isTrackOccupied(4))


print('\ntestCode3:')
testCode3()
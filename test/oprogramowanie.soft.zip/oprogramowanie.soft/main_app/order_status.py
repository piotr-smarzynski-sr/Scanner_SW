"""
Module order_status - holds order status number and corresponding texts
"""

NG = 0

READY = 1
PASSED_TO_SERVER = 2
CART_ASSIGNED_TO_ORDER = 3
ROUTE_TO_START_POINT_PASSED_TO_CART = 4
CART_EXECUTING_ROUTE_TO_START_POINT = 5
CART_FINISHED_ROUTE_TO_START_POINT = 6
ROUTE_TO_END_POINT_PASSED_TO_CART = 7
CART_EXECUTING_ROUTE_TO_END_POINT = 8
CART_FINISHED_ROUTE_TO_END_POINT = 9
CART_LOCKED_IN_STATION_OPERATOR_WORKING = 10


CART_ENCOUTERED_OBSTACLES_ON_ROUTE_TO_START_POINT = 30
CART_ENCOUTERED_OBSTACLES_ON_ROUTE_TO_END_POINT = 31

ORDER_CANNOT_BE_EXECUTED_START_STATION_UNAVAILABLE = 40
ORDER_CANNOT_BE_EXECUTED_END_STATION_UNAVAILABLE = 41
ORDER_CANNOT_BE_EXECUTED_NO_AVAILABLE_ROUTE_TO_START_POINT = 42

ORDER_DELAYED = 50
NO_CART_FOUND = 51
ORDER_TIMEOUT = 52

DONE = 99

ORDER_STARUS_DICT = {
    NG: 'NG',

    READY: 'Ready',
    PASSED_TO_SERVER: 'Passed to server',
    CART_ASSIGNED_TO_ORDER: '%s assigned to order',
    ROUTE_TO_START_POINT_PASSED_TO_CART: 'Route to start point passed to %s',
    CART_EXECUTING_ROUTE_TO_START_POINT: '%s executing route to start point',
    CART_FINISHED_ROUTE_TO_START_POINT: '%s finished route to start point',
    ROUTE_TO_END_POINT_PASSED_TO_CART: 'Route to end point passed to %s',
    CART_EXECUTING_ROUTE_TO_END_POINT: '%s executing route to end point',
    CART_FINISHED_ROUTE_TO_END_POINT: 'C%s finished route to end point',
    CART_LOCKED_IN_STATION_OPERATOR_WORKING: '%s locked in station, operator working',

    CART_ENCOUTERED_OBSTACLES_ON_ROUTE_TO_START_POINT: '%s encoutered obstacles on route to start point',
    CART_ENCOUTERED_OBSTACLES_ON_ROUTE_TO_END_POINT: '%s encoutered obstacles on route to end point',

    ORDER_CANNOT_BE_EXECUTED_START_STATION_UNAVAILABLE: 'Order cannot be executed: start station unavailable',
    ORDER_CANNOT_BE_EXECUTED_END_STATION_UNAVAILABLE: 'Order cannot be executed: end station unavailable',
    ORDER_CANNOT_BE_EXECUTED_NO_AVAILABLE_ROUTE_TO_START_POINT: 'Order cannot be executed: no available route to start point',

    ORDER_DELAYED: 'Order delayed',
    NO_CART_FOUND: 'No cart found',
    ORDER_TIMEOUT: 'Order timeout',

    DONE: 'Done'
}

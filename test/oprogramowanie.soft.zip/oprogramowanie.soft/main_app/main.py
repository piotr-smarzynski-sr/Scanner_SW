'''
Zasady pisania kodu w projekcie:
Nazewnictwo:
zmienne - moja_zmienna
obiekty - Moj_Obiekt
funkcje/wątki - mojaFunkcja
moduły - moj_modul

Odstępy:
jedna linijka po zakończeniu wcięcia, wyłączając else i elif
jedna linijka przed każdą sekcją opatrzoną kometarzem --------- SEKCJA ----------
jedna linijka po każdym imporcie zewnętrznym
jedna linijka pomiędzy importami modułów własnych i wbudowanych
jedna linijka przed obsługą sys.argv
jedna linijka po tej sekcji
jedna linijka przed def
jedna linijka przed return
'''
from thread_print import s_print, getDate
import logging
# #---------- LOGGING SETUP ---------------
# filename = '/logs/main_app_'+getDate()+'.log'
# logging.basicConfig(filename=filename, level=logging.DEBUG)


from time import sleep
from sys import argv
from threading import Thread
import sys
import socket

import colorama
from colorama import Fore

import cart_updater_udp
from db_communication import connection
import keyboard_handler
import orders_queued
import mqtt_communication
import other
import tcp_communication

# FUTURE FEATURE
# import gui
# import safety

#--------- SYS ARGV ------------------
if len(argv) > 1:
    s_print('argv: ', argv)

if '-mqtt_log' in argv or '-l' in argv:
    mqtt_communication.LOGGING = True
    s_print('mqtt logging enabled')

if  '-debug' in argv or '-d' in argv:
    mqtt_communication.MQTT_DEBUG = True
    s_print('mqtt debug enabled')

# #---------- LOGGING SETUP ---------------
# filename = '/logs/main_app_'+getDate()+'.log'
# # f= open(filename,"w+")
# # f.close()
# logging.basicConfig(filename=filename, level=logging.DEBUG)

#---------------- COLORAMA -------------------
colorama.init(convert=True)
s_print(Fore.RESET)

#---------------- GLOBAL ---------------------
running = True          # flag for stopping threads
UDP_LISTENER_IP = "0.0.0.0"
RX_PORT = 60000     # UDP RX port
udp_clients = []    # list holding udp clients
CLIENT_TIMEOUT = 10  # UDP client timeout [seconds]
Alive_Check_Enabler = other.RunEnabler(False)

# ---------------- UDP SOCKET CONFIG-----------------------
socket_receive = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
socket_receive.bind((UDP_LISTENER_IP, RX_PORT))

# -------------- MQTT  CONFIG------------------------
mqtt_clients = []
# # DO NOT CREATE CLIENTS WITH NAMES : sub_00
# # mqtt_clients.append(
# #     (mqtt_communication.createClient('sub00', subscribe='cartCount'), 'sub_00'))
# mqtt_clients.append(
#     (mqtt_communication.createClient('sub_carts2main', sub_topic='carts2main'), 'sub_carts2main'))

# -------------- THREADS DEFINITIONS----------------------
threads = [] # list holding all threads
# threads receives cart data over udp and updates it in DB
# threads.append(Thread(target=cart_updater_udp.cartUpdaterUDP2,
#                       name="cartUpdaterUDP2",
#                       kwargs={'socket_receive':socket_receive},
#                       daemon=True))

threads.append(Thread(target=cart_updater_udp.cartUpdaterUDP3,
                      name="cartUpdaterUDP3",
                      kwargs={'socket_receive':socket_receive,
                              'queue_db': cart_updater_udp.db_messages_q,
                              'queue_timeout': cart_updater_udp.timeout_q,
                              'queue_alarms': orders_queued.alarm_handler_sql_q,
                              'DEBUG': True},
                      daemon=True))

threads.append(Thread(target=orders_queued.alarmHandlerSQL,
                      name="alarmHandlerSQL",
                      kwargs={'queue_input': orders_queued.alarm_handler_sql_q,},
                      daemon=True))

threads.append(Thread(target=cart_updater_udp.cartUpdaterThreadDB,
                      name="cartUpdaterThreadDB",
                      kwargs={'queue_input': cart_updater_udp.db_messages_q,
                              'DEBUG': True},
                      daemon=True))

# thread periodically checks list of UDP clients and removes ones after timeout
threads.append(Thread(target=cart_updater_udp.cartTimeoutUDP,
                name="cartTimeoutUDP",
                kwargs={'queue_input': cart_updater_udp.timeout_q},
                daemon=True))

# thread waits for new connections over TCP
threads.append(Thread(target=tcp_communication.socketCreatorTCP2,
                      name="socketCreatorTCP",
                      kwargs={'threads':threads,
                              'interface': '0.0.0.0',
                              'port': 50000},
                      daemon=True))

# thread checks periodically for dead threads
threads.append(Thread(target=other.aliveThreadsChecker,
                      name="aliveThreadsChecker",
                      kwargs={'threads':threads,
                              'run_enable': Alive_Check_Enabler},
                      daemon=True))

# thread periodically chech for new orders in DB
threads.append(Thread(target=orders_queued.ordersCheck,
                      name="ordersCheck",
                      kwargs={'queue_for_cart_dispatcher' : orders_queued.cart_dispatcher_from_orders_check_q,
                              'queue_for_orders_handler_sql' : orders_queued.orders_handler_sql_q},
                      daemon=True))

# thread receives updates for orders in DB and commits them
threads.append(Thread(target=orders_queued.ordersHandlerSQL,
                      name="ordersHandlerSQL",
                      kwargs={'queue_input' : orders_queued.orders_handler_sql_q},
                      daemon=True))

# thread receives updates for carts in DB and commits them
threads.append(Thread(target=orders_queued.cartHandlerSQL,
                      name="cartHandlerSQL",
                      kwargs={'queue_input' : orders_queued.cart_handler_sql_from_cart_dispatcher_q},
                      daemon=True))

# thread receives updates for stations in DB and commits them
threads.append(Thread(target=orders_queued.stationHandlerSQL,
                      name="stationHandlerSQL",
                      kwargs={'queue_input' : orders_queued.station_handler_sql_from_sub_station_controller_q},
                      daemon=True))

# threads manages orders, dispatches them to carts maps routes, and handles other events on route
threads.append(Thread(target=orders_queued.cartDispatcher,
                      name="cartDispatcher",
                      kwargs={'queue_from_orders_check' : orders_queued.cart_dispatcher_from_orders_check_q,
                              'queue_from_station_check' : orders_queued.cart_dispatcher_from_station_check_q,
                              'queue_for_cart_handler_sql' : orders_queued.cart_handler_sql_from_cart_dispatcher_q,
                              'queue_from_sub_cart_controller' : orders_queued.cart_dispatcher_from_sub_cart_controller_q,
                              'queue_for_order_handler_sql' : orders_queued.orders_handler_sql_q},
                      daemon=True))

# thread waits for keyboard shortcuts to handle
threads.append(Thread(target=keyboard_handler.keyboardHandler,
                      name="keyboardHandler",
                      kwargs={},
                      daemon=True))

# ----- Threads start and print names -------------------------
if len(threads) > 0:
    output = ''
    for thread in threads:
        if not thread.name.startswith('C'):
            thread.start()
            output += "Starting thread "
            output += thread.getName()
            output += ', alive: '
            output += str(thread.is_alive())
            output += '\n'

    s_print(output)
    Alive_Check_Enabler.enable = True

# timer1 = other.Timer()
s_print("Main loop start")
try:
# --------------- MAIN LOOP -------------------
    while True:
        sleep(1)

# ------------- CLOSING APP AND WRAPUP
except KeyboardInterrupt:
    running = False
    s_print("\n"+ Fore.RESET +"Exiting via CTRL + C")

    # ----------- Killing MQTT ----------------------------------------
    if len(mqtt_clients) > 0:
        for client in mqtt_clients:
            if client[1].startswith('sub'):
                mqtt_communication.unsubscribe(client[0], '#')
            mqtt_communication.clientStop(client[0])
            s_print("Killing MQTT client ", client[1])

    # ----------- List of threads to kill ------------
    if len(threads) > 0:
        for thread in threads:
            s_print("Killing thread ", thread.getName())

    # ----------- killing DB connection --------------
    s_print("Killing DB connection")
    connection.close()

    print(Fore.RESET + 'Program end.')
    sys.exit(0)
